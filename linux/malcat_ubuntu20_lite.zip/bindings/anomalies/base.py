import bindings

class Anomaly:
    TRACE = bindings.Anomaly.TRACE
    ODD = bindings.Anomaly.ODD
    WARNING = bindings.Anomaly.WARNING
    ERROR = bindings.Anomaly.ERROR

    level = TRACE
    category = "generic"
    filetype = None
    architecture = None

