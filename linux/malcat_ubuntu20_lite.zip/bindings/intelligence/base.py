import enum
import functools

class OnlineChecker:
    name = None

    def __init__(self, **options):
        self.options = options

    def check(self, malcat):
        raise NotImplementedError

    @property
    def name(self):
        if hasattr(self.__class__, "name"):
            return self.__class__.name
        else:
            return self.__class__.__name__

    def __repr__(self):
        return self.name


class DetectionLevel(enum.IntEnum):
    CLEAN = 0
    UNKNOWN = 1
    ENCRYPTED = 2
    PACKED = 5
    APPL = 8
    PUA = 10
    SPR = 20
    SUSPECT = 30
    HACKTOOL = 50
    ADWARE = 80
    MALWARE = 100

    @staticmethod
    def from_number(number, maximum_number=100):
        if number is None:
            return DetectionLevel.UNKNOWN
        if number > maximum_number / 2:
            return DetectionLevel.MALWARE
        elif number > maximum_number / 5:
            return DetectionLevel.SUSPECT
        else:
            return DetectionLevel.UNKNOWN

    @staticmethod
    def from_text(text):
        words = {
                "malicious": DetectionLevel.MALWARE,
                "trj": DetectionLevel.MALWARE,
                "trojan": DetectionLevel.MALWARE,
                "virus": DetectionLevel.MALWARE,
                "apt": DetectionLevel.MALWARE,
                "malware": DetectionLevel.MALWARE,
                "malware2": DetectionLevel.MALWARE,
                "adware": DetectionLevel.ADWARE,
                "adload": DetectionLevel.ADWARE,
                "pua": DetectionLevel.PUA,
                "pup": DetectionLevel.PUA,
                "unwanted": DetectionLevel.PUA,
                "suspicious": DetectionLevel.SUSPECT,
                "clean": DetectionLevel.CLEAN,
                "cleanware": DetectionLevel.CLEAN,
                "clean1": DetectionLevel.CLEAN,
                "harmless": DetectionLevel.CLEAN,
                "legit file": DetectionLevel.CLEAN,
        }
        for word in text.split(" "):
            cat = words.get(word.lower(), None)
            if cat is not None:
                return cat
        return DetectionLevel.UNKNOWN


@functools.total_ordering
class OnlineDetection:

    def __init__(self, level=DetectionLevel.UNKNOWN, name=""):
        self.level = level
        self.name = name

    def __eq__(self, o):
        return self.level == o.level and self.name == o.name

    def __lt__(self, o):
        return self.level < o.level or self.level == o.level and self.name < o.name


class CheckStatus(enum.IntEnum):
    OK = 0
    DEACTIVATED = 1
    NOTFOUND = 2
    TIMEOUT = 3
    ERROR = 4


class OnlineResult:

    def __init__(self, status=CheckStatus.OK, message="", url="", detections={}):
        self.status = status
        self.message = message
        self.detections = detections
        self.url = url

