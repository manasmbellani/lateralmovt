import requests
import json
import datetime
import random

URL = "https://www.virustotal.com/api/v3/intelligence/search"


def vtgrep(apikey, pattern, limit=10):
    result = []
    if not apikey:
        raise KeyError("No VirusTotal API key set")
    elif not pattern:
        return result
    session = requests.Session( )
    session.headers.updsession = requests.Session( )
    session.headers.update({'x-apikey': apikey})
    session.headers.update({"Accept": "application/json"})
    response = session.get(URL, params = {
        "query": "content:" + pattern,
        "limit": limit,
        "descriptors_only": "false",
    })
    if response.status_code == 404:
        return result
    elif response.status_code == 401:
        return KeyError("Bad API key")
    elif not response.ok:
        error = response.json().get("error", {}).get("message", "<no error code>")
        code = response.json().get("error", {}).get("code", "<no error code>")
        raise ValueError("Error while performing VTGrep search ({}:{}): {}".format(response.status_code, code, error))
    data = response.json().get("data", [])
    for hit in data:
        attributes = hit.get("attributes", {})
        type = attributes.get("type_description", "???")
        size = attributes.get("size", 0)
        sha256 = attributes.get("sha256", "")
        last_sub = datetime.datetime.fromtimestamp(attributes.get("last_submission_date", 0)).strftime("%Y-%m-%d %H:%M:%S")
        stats = attributes.get("last_analysis_stats", {})
        av_malicious = stats.get("malicious", 0)
        av_clean = stats.get("undetected", 0) + stats.get("harmless", 0)
        names = attributes.get("names", [])
        if not names:
            name = "<unnamed>"
        else:
            name = names[0]
        result.append((name, type, size, last_sub, av_malicious, av_clean, "https://www.virustotal.com/gui/file/" + sha256))
    return result

