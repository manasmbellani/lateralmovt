import bindings
import traceback
from collections import OrderedDict
import sys

from .types import *

class ParsingError(ValueError) : pass
class FatalError(ParsingError): pass            # fatal error, raised by file parser: result should be discarded
class OutOfBoundError(ParsingError): pass       # tried to read out of file bound: keep result iff oob_soft mode is set
class SuperposingError(ParsingError): pass      # tried to map the same file space to two different structures, keep result but abort parsing

   

###################################################################        

class FileTypeAnalyzer:
    name = None
    regexp = ""
    category = None
    priority = 0


    def __init__(self):
        self.architecture = bindings.FileType.NONE
        self.imagebase = 0
        self.files = []         # list of bindings.VirtualFile
        self.symbols = []       # list of bindings.FileSymbol
        self.sections = []      # list of bindings.Section
        self.metadata = OrderedDict()      # an ordered dict { category -> ordered dict { key (str) -> value (str) } }

    def parse(self):
        """
        Main parsing method
        """
        raise NotImplementedError

    def run(self, file, hint="", confirmed=False):
        """
        Do the complete parsing and return the cpp structure
        To be called from malcat only
        """
        try:
            for _ in self._run(file, hint, confirmed):
                pass #print("{} -> {:x}".format(element.name, self._offset))
        except FatalError as e:
            if not self._confirmed:
                raise
            else:
                print(e)
        except OutOfBoundError as e:
            if not self._confirmed:
                raise
            else:
                print(e)
        except SuperposingError as e:
            print(e)    # abort parsing
            if not self._confirmed:
                raise
        self._parsed.set_architecture(self.architecture)
        self._parsed.set_imagebase(self.imagebase)
        for s in self.files:
            self._parsed.add_file(s)
        for s in self.symbols:
            self._parsed.add_symbol(s)
        for s in self.sections:
            self._parsed.add_section(s)
        for cat, meta in self.metadata.items():
            if type(meta) == str:
                self._parsed.add_metadata("", cat, meta)
            else:
                for key, value in meta.items():
                    self._parsed.add_metadata(cat, key, value)
        return self._parsed

    def subparse(self, analyzer, size=None, hint="", confirmed=False):
        """
        parse current position using a different analyzer, for a maximum of <size> bytes read
        Returns all the structures parsed by this analyzer
        To be called from another analyser, wanting to parse a subfile for instance
        """
        if size is None:
            size = self.remaining()
        res = list(analyzer._run(bindings.FileSnippet(self._file, self._offset, size, ""), hint, confirmed))    
        for el, fa in res:
            el.is_parsed = True
            yield el, fa
        #return res

    def jump(self, foffs):
        """
        Jump to another offset so that the next yield XXX put the structure at this address.
        Only works from within the Analyzer parse() method
        """
        if foffs is None:
            raise ValueError("Attempting to jump to None address")
        if foffs > self._stop:
            raise OutOfBoundError("Jumping to invalid offset #{:x}".format(foffs))
        self._offset = foffs
        self._remaining = self._stop - foffs

    def tell(self):
        return self._offset

    def size(self):
        return self._stop

    def remaining(self):
        return self._remaining

    def eof(self):
        return self._remaining <= 0

    def confirm(self):
        """
        call this method to confirm that the file you are parsing is what you are expecting
        After his call, exceptions raised by the parser will be changed to warnings (parsing 
        will still be interrupted, but result is kept) 
        """
        self._confirmed = True

    def is_confirmed(self):
        return self._confirmed

    def search(self, regexp, start=0, size=None):
        """
        returns (absolute offset of match, size of match).
        If no match, size is 0
        """
        if size is None or start + size > self._stop:
            size = self._stop - start
        if size < 0:
            raise ValueError("Invalid search range")
        off, sz = self._file.search(regexp, start, size)
        if sz == 0:
            off = None
        return off, sz

    def read(self, where=None, size=1):
        if where is None:
            where = self.tell()
        if where + size > self._stop:
            raise OutOfBoundError("Reading beyond end of buffer at {:x}-{:x}".format(where, where + size))
        return self._file.read(where, size)

    def read_cstring_ascii(self, where=None, max_bytes=512):
        if where is None:
            where = self.tell()
        if where >= self._stop:
            raise OutOfBoundError("Reading beyond end of buffer at {:x}".format(where))
        return self._file.read_cstring_ascii(where, max_bytes)

    def read_cstring_utf8(self, where=None, max_bytes=512):
        if where is None:
            where = self.tell()
        if where >= self._stop:
            raise OutOfBoundError("Reading beyond end of buffer at {:x}".format(where))
        return self._file.read_cstring_utf8(where, max_bytes)

    def read_cstring_utf16le(self, where=None, max_bytes=512):
        if where is None:
            where = self.tell()
        if where >= self._stop:
            raise OutOfBoundError("Reading beyond end of buffer at {:x}".format(where))
        try:
            return self._file.read_cstring_utf16le(where, max_bytes)
        except UnicodeDecodeError:
            return "invalid ut16-le"

    def find(self, off, what, stop=None, step=1):
        if stop is None:
            stop = self._stop
        stop = min(stop, self._stop)
        while off + len(what) <= stop:
            dat = self._file.read(off, len(what))
            if dat == what:
                return off
            off += step
        return None
    
    def __iter__(self):
        for i in range(self._parsed.number_of_structures):
            yield self._parsed[i]
    
    def at(self, key):
        return self._parsed.at(key)

    def __getitem__(self, key):
        return self._parsed[key]

    def __contains__(self, key):
        return key in self._parsed

    def _run(self, file, hint, confirmed=False):
        self._parsed = bindings.FileType(file, self.__class__.name, self.__class__.category)
        self._offset = 0
        self._stop = file.size
        self._remaining = self._stop
        self._file = file
        self._confirmed = confirmed
        iterator = self._iterate(self.parse(hint))
        try:
            element = iterator.send(None)
            struc_index = 0
            while True:
                struc = bindings.Structure(element.category, element.name, element.native)
                try:
                    res = self._parsed.add_structure(self._offset, struc)
                except BaseException as e:
                    # forward field errors to structure creation location
                    element = iterator.throw(OutOfBoundError("structure {} has invalid offset {:x}-{:x}".format(element.name, self._offset, self._offset + element.native.size)))
                    continue
                if not res:
                    element = iterator.throw(SuperposingError, "structure {} at offset {:x}-{:x} would overwrite an existing structure".format(element.name, self._offset, self._offset + element.native.size))
                    continue
                if element.parent is not None:
                    struc.set_parent_hint(element.parent)
                fa = self._parsed.at(struc_index)
                yield element, fa
                element = iterator.send(fa.value)
                struc_index += 1
        except StopIteration:
            pass    
       

    def _iterate(self, iterator, virtual=False):
        """
        Ugly coroutine stuff to make every field be accessible immediately
        """
        #for element in iterator:
        element = None
        try:
            while True:
                try:
                    if element is None:
                        element = iterator.send(None)

                    if isinstance(element, Struct):
                        element.offset = self._offset
                        fa = yield element
                        element.analyzer = self
                        if not hasattr(element, "is_parsed"):
                            subiterator = self._iterate(element.parse(), virtual)
                            i = 0
                            prev = None
                            while True:
                                try:
                                    sub = subiterator.send(prev)
                                except StopIteration:
                                    break
                                except:
                                    sub = subiterator.throw(*sys.exc_info())
                                element.native.add(sub.name, sub.native)
                                if not virtual:
                                    prev = fa[i]
                                i += 1
                        else:
                            self._offset += element.native.size
                    elif isinstance(element, Array):
                        old_loc = self._offset
                        if not hasattr(element, "is_parsed"):
                            def dummyiter(l):
                                yield l
                            subiterator = self._iterate(dummyiter(element.subtype), virtual=True)
                            while True:
                                try:
                                    sub = subiterator.send(None)
                                except StopIteration:
                                    break
                                except:
                                    sub = subiterator.throw(*sys.exc_info())
                                native_subtype = sub.native
                            size_element = self._offset - old_loc
                            self._offset = old_loc
                            element.native = bindings.ArrayField(native_subtype, element.count, element.comment)
                        if self._offset + element.native.size > self._stop:
                            element = iterator.throw(OutOfBoundError, "Parsing beyond EOB for {} at {:x} on {:x} bytes ({} remaining)".format(element, self._offset, element.native.size, self._remaining))
                            continue
                        fa = yield element
                        self._offset += element.native.size
                        self._remaining = self._stop - self._offset
                    elif isinstance(element, DynamicArray):
                        old_loc = self._offset
                        if not hasattr(element, "is_parsed"):
                            def dummyiter(l):
                                yield l
                            subiterator = self._iterate(dummyiter(element.subtype), virtual=True)
                            while True:
                                try:
                                    sub = subiterator.send(None)
                                except StopIteration:
                                    break
                                except:
                                    sub = subiterator.throw(*sys.exc_info())
                                native_subtype = sub.native
                            size_element = self._offset - old_loc
                            self._offset = old_loc
                            element.native = bindings.ArrayField(native_subtype, 1, element.comment)
                        if self._offset + element.native.size > self._stop:
                            element = iterator.throw(OutOfBoundError, "Parsing beyond EOB for {} at {:x} on {:x} bytes ({} remaining)".format(element, self._offset, element.native.size, self._remaining))
                            continue
                        fa = yield element
                        count = 1
                        error_thrown = False
                        while True:
                            last = fa[count - 1]
                            if element.fn_terminator(last, count):
                                break
                            if element.max_elements is not None and count >= element.max_elements:
                                break
                            if old_loc + size_element * (count + 1) > self._stop:
                                element = iterator.throw(OutOfBoundError, "Reached EOB before termination condition at 0x{:x} ({})".format(old_loc + size_element * (count + 1), native_subtype)) 
                                error_thrown = True
                                break
                            count += 1
                            element.native.resize(count)
                        if error_thrown:
                            continue
                        self._offset += element.native.size
                        self._remaining = self._stop - self._offset
                    else:
                        if isinstance(element, DelayedType):
                            try:
                                element.build(self)
                            except:
                                type, value, _ = sys.exc_info()
                                element = iterator.throw(type, value)
                                continue
                            if element.native is None:
                                element = iterator.send(None)
                                continue
                        if self._offset + element.native.size > self._stop:
                            element = iterator.throw(OutOfBoundError, "Parsing beyond EOB for {} at {:x} on {:x} bytes ({} remaining)".format(element, self._offset, element.native.size, self._remaining))
                            continue
                        fa = yield element
                        self._offset += element.native.size
                        self._remaining = self._stop - self._offset
                    element = iterator.send(fa)
                except StopIteration:
                    break
                except:
                    # forward field errors to structure creation location
                    element = iterator.throw(*sys.exc_info())
                    continue
        except StopIteration:
            pass

