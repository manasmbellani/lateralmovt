"""

This file contains suggar coating over Malcat's CPP types

"""
import bindings



######################################## BASIC TYPES

class Type:
    HEADER = bindings.Structure.HEADER
    FUNCTION = bindings.Structure.CODE
    DEBUG = bindings.Structure.DEBUG
    FIXUP = bindings.Structure.FIXUP
    DATA = bindings.Structure.DATA
    RESOURCE = bindings.Structure.RESOURCE
    META = bindings.Structure.METADATA
    ANOMALY = bindings.Structure.ANOMALY

    def __init__(self, name="", category=HEADER, comment="", parent=None, values=[]):
        self.name = name
        self.category = category
        self.comment = comment
        self.parent = parent

    def __repr__(self):
        return "{}({})".format(self.name, self.__class__.__name__)


class Unused(Type):
    def __init__(self, size, **kwargs):
        if not "name" in kwargs:
            kwargs["name"] = "Unused"
        Type.__init__(self, **kwargs)
        self.native = bindings.Unspecified(size, kwargs.get("comment", ""))


# TODO: remove all this proxy thing and use native bindings directly ?

class BasicType(Type):
    def __init__(self, binding, **kwargs):
        Type.__init__(self, **kwargs)
        self.native = binding(kwargs.get("comment", ""), kwargs.get("values", []))


class UInt8(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt8, **kwargs)


class UInt8Xor(Type):
    def __init__(self, key, **kwargs):
        Type.__init__(self, **kwargs)
        self.native =  bindings.UInt8Xor(key, kwargs.get("comment", ""), kwargs.get("values", []))

class Int8(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.Int8, **kwargs)        


class UInt16(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt16, **kwargs)


class UInt16Xor(Type):
    def __init__(self, key, **kwargs):
        Type.__init__(self, **kwargs)
        self.native =  bindings.UInt16Xor(key, kwargs.get("comment", ""), kwargs.get("values", []))


class Int16(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.Int16, **kwargs)        


class UInt16BE(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt16BE, **kwargs)


class Int16BE(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.Int16BE, **kwargs)                


class UInt24(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt24, **kwargs)


class UInt24BE(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt24BE, **kwargs)        


class UInt32(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt32, **kwargs)


class UInt32Xor(Type):
    def __init__(self, key, **kwargs):
        Type.__init__(self, **kwargs)
        self.native =  bindings.UInt32Xor(key, kwargs.get("comment", ""), kwargs.get("values", []))


class Int32(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.Int32, **kwargs)        


class UInt32BE(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt32BE, **kwargs)


class Int32BE(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.Int32BE, **kwargs)        


class UInt64(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt64, **kwargs)


class Int64(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.Int64, **kwargs)        


class UInt64BE(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.UInt64BE, **kwargs)


class Int64BE(BasicType):
    def __init__(self, **kwargs):
        BasicType.__init__(self, bindings.Int64BE, **kwargs)                


class Filetime(Type):
    def __init__(self, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.Filetime(kwargs.get("comment", ""), [])        
        
class Timestamp(Type):
    def __init__(self, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.Timestamp(kwargs.get("comment", ""), [])


class DosDateTime(Type):
    def __init__(self, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.DosDateTime(kwargs.get("comment", ""), [])        


class DosDate(Type):
    def __init__(self, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.DosDate(kwargs.get("comment", ""), [])


class DosTime(Type):
    def __init__(self, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.DosTime(kwargs.get("comment", ""), [])        


class String(Type):
    def __init__(self, size, zero_terminated=False, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.String(size, zero_terminated, kwargs.get("comment", ""))


class Bytes(Type):
    def __init__(self, size, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.Bytes(size, kwargs.get("comment", ""))        


class StringUtf8(Type):
    def __init__(self, size, zero_terminated=False, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.U8String(size, zero_terminated, kwargs.get("comment", ""))


class StringUtf16le(Type):
    def __init__(self, size, zero_terminated=False, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.U16String(size, zero_terminated, kwargs.get("comment", ""), True)


class StringUtf16be(Type):
    def __init__(self, size, zero_terminated=False, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.U16String(size, zero_terminated, kwargs.get("comment", ""), False)


class GUID(Type):
    def __init__(self, microsoft_order=True, **kwargs):
        Type.__init__(self, **kwargs)        
        self.native = bindings.GUID(microsoft_order, kwargs.get("comment", ""), [(x, y.upper()) for x, y in kwargs.get("values", [])])


class Bit(Type):
    def __init__(self, **kwargs):
        Type.__init__(self, **kwargs)
        self.native = bindings.SingleBitField(kwargs.get("comment", ""))


class NullBits:     # convenience/macro class for BitField
    def __init__(self, count):
        self.count = count


########################################## AGGREGATES


class BitsField(Type):
    def __init__(self, *bits, **kwargs):
        Type.__init__(self, **kwargs)
        size = 0
        self.native = bindings.BitsField(kwargs.get("comment", ""))
        for bit in bits:
            if isinstance(bit, NullBits):
                for i in range(bit.count):
                    size += 1
                    self.native.add("", bindings.SingleBitField("<null>"))
            elif isinstance(bit, Bit):
                size += 1
                self.native.add(bit.name, bit.native)
            else:
                raise ValueError("Invalid type for a BitsField {}".format(bit.__class__.__name__))
        while (size % 8) != 0:
            size += 1
            self.native.add("", bindings.SingleBitField("<null>"))


class Struct(Type):

    def __init__(self, **kwargs):
        if not "name" in kwargs:
            kwargs["name"] = self.__class__.__name__
        Type.__init__(self, **kwargs)
        self.native = bindings.StructField(self.comment)
        self.analyzer = None
        self.offset = None

    def parse(self):
        raise NotImplementedError

    def __len__(self):
        """
        return the current size in bytes of the structure
        """
        return self.native.size

    def look_ahead(self, num_bytes=1):
        """
        return the next <num_bytes> bytes that would need to be parsed
        can only be called from within the parse method
        """
        if self.analyzer is None:
            raise ValueError("method can only be called from within the parse() method")
        return self.analyzer.read(size=num_bytes)

    def remaining(self):
        """
        return how many bytes there is to parse
        can only be called from within the parse method
        """
        if self.analyzer is None:
            raise ValueError("method can only be called from within the parse() method")
        return self.analyzer.remaining()


class Array(Type):
    """
    Array of fixed size. Note that all cells must have the same size. To construct the array, only the first cell is actually parsed(), and the rest of the cells are assumed to have the same size.
    If the cell type is a Struct(), you won't be able to do the same things as usual,
    like reading field
    """
    def __init__(self, count, subtype, **kwargs):
        Type.__init__(self, **kwargs)
        self.subtype = subtype
        self.count = count


class DynamicArray(Type):
    """
    An array, but the size of the array is given by the predicate: fn_terminator(cell) == True
    """

    def __init__(self, fn_terminator, subtype, max_elements=None, **kwargs):
        Type.__init__(self, **kwargs)
        self.subtype = subtype
        self.fn_terminator = fn_terminator
        self.max_elements = max_elements

########################################## POINTERS


class Rva(Type):
    def __init__(self, hint=None, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Rva(hint, kwargs.get("comment", ""))

class Rva64(Type):
    def __init__(self, hint=None, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Rva64(hint, kwargs.get("comment", ""))

class Va32(Type):
    def __init__(self, hint=None, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Va32(hint, kwargs.get("comment", ""))

class Va32BE(Type):
    def __init__(self, hint=None, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Va32BE(hint, kwargs.get("comment", ""))        

class Va64(Type):
    def __init__(self, hint=None, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Va64(hint, kwargs.get("comment", ""))

class Va64BE(Type):
    def __init__(self, hint=None, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Va64BE(hint, kwargs.get("comment", ""))        


class Offset16(Type):
    def __init__(self, hint=None, base=0, zero_is_invalid=False, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Offset16(hint, base, zero_is_invalid, kwargs.get("comment", ""))

class Offset32(Type):
    def __init__(self, hint=None, base=0, zero_is_invalid=False, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Offset32(hint, base, zero_is_invalid, kwargs.get("comment", ""))

class Offset32BE(Type):
    def __init__(self, hint=None, base=0, zero_is_invalid=False, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Offset32BE(hint, base, zero_is_invalid, kwargs.get("comment", ""))        

class Offset64(Type):
    def __init__(self, hint=None, base=0, zero_is_invalid=False, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Offset64(hint, base, zero_is_invalid, kwargs.get("comment", ""))

class Offset64BE(Type):
    def __init__(self, hint=None, base=0, zero_is_invalid=False, **kwargs):
        Type.__init__(self, **kwargs)        
        if not hasattr(hint, "native"):
            hint = None
        else:
            hint = hint.native
        self.native = bindings.Offset64BE(hint, base, zero_is_invalid, kwargs.get("comment", ""))        


########################################## CUSTOM STRUCTS

class PascalString(Struct):

    def parse(self):
        sz = yield UInt32(name="Size", comment="string size")
        if sz:
            yield String(sz, zero_terminated=True, name="String")

class PascalString8(Struct):

    def parse(self):
        sz = yield UInt8(name="Size", comment="string size")
        if sz:
            yield String(sz, zero_terminated=True, name="String")            

class PascalBytes(Struct):

    def parse(self):
        sz = yield UInt32(name="Size", comment="buffer size")
        if sz:
            yield Bytes(sz, name="Bytes")

class UnicodeString(Struct):

    def parse(self):
        sz = yield UInt32(name="Size", comment="string size")
        if sz:
            yield StringUtf16le(sz, zero_terminated=True, name="String")        


########################################## DYNAMIC TYPES

class DelayedType(Type):
    """
    non-aggregate types where the type size depends on the actual data
    """

    def build(self, analyzer):
        raise NotImplementedError


class VarUInt64(DelayedType):
    """
    variable uint64 where first bit (0x80) tells if there is more data to come
    """
    def __init__(self, **kwargs):
        DelayedType.__init__(self, **kwargs)
        
    def build(self, analyzer):
        self.native = bindings.VarUInt64(analyzer._file, analyzer.tell(), self.comment)

    @staticmethod
    def parse(analyzer, where):
        return bindings.VarUInt64.parse(analyzer._file, where)


class Align(DelayedType):
    """
    0 or more unused bytes depending on file offset
    """
    def __init__(self, alignment=4, **kwargs):
        DelayedType.__init__(self, name="Padding", **kwargs)
        self.alignment = alignment
        
    def build(self, analyzer):
        align = analyzer.tell() % self.alignment
        if align:
            self.native = bindings.Unspecified(self.alignment - align, self.comment or "Padding on {}-bytes boundaries".format(self.alignment))
        else:
            self.native = None  # yield nothing


class CString(DelayedType):
    """
    a zero-terminated ascii string
    """
    def __init__(self, max_size=512, **kwargs):
        DelayedType.__init__(self, **kwargs)
        self.max_size = max_size
        
    def build(self, analyzer):
        string = analyzer.read_cstring_ascii(max_bytes=self.max_size)
        self.native = bindings.String(len(string) + 1, True, self.comment)


class CStringUtf8(DelayedType):
    """
    a zero-terminated ascii string
    """
    def __init__(self, max_size=512, **kwargs):
        DelayedType.__init__(self, **kwargs)
        self.max_size = max_size
        
    def build(self, analyzer):
        string = analyzer.read_cstring_utf8(max_bytes=self.max_size)
        self.native = bindings.U8String(len(string.encode("utf8")) + 1, True, self.comment)


class CStringUtf16le(DelayedType):
    """
    a zero-terminated ascii string
    """
    def __init__(self, max_size=512, **kwargs):
        DelayedType.__init__(self, **kwargs)
        self.max_size = max_size
        
    def build(self, analyzer):
        string = analyzer.read_cstring_utf16le(max_bytes=self.max_size)
        self.native = bindings.U16String(len(string) + 1, True, self.comment, True)


class CStringUtf16be(DelayedType):
    """
    a zero-terminated ascii string
    """
    def __init__(self, max_size=512, **kwargs):
        DelayedType.__init__(self, **kwargs)
        self.max_size = max_size
        
    def build(self, analyzer):
        string = analyzer.read_cstring_utf16be(max_bytes=self.max_size)
        self.native = bindings.U16String(len(string) + 1, True, self.comment, False)
