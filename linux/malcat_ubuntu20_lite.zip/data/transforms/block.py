from transforms.base import *
from Cryptodome.Cipher import AES, Blowfish, DES, DES3
from Cryptodome.Util import Padding


class AesDecrypt(Transform):
    """
    AES cipher decryption
    """
    category = "crypto (block)"
    name = "aes decrypt"

    def run(self, data:bytes, mode:("ecb","cbc","cfb")="ecb", key:bytes=b"aaaaaaaaaaaaaaaa", iv:bytes=b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00", unpad:bool=False):
        if mode == "ecb":
            decryptor = AES.new(key, AES.MODE_ECB)
        elif mode == "cbc":
            decryptor = AES.new(key, AES.MODE_CBC, iv=iv)
        elif mode == "cfb":
            decryptor = AES.new(key, AES.MODE_CFB, iv=iv)
        data = decryptor.decrypt(data)
        if unpad:
            data = Padding.unpad(data, 16)
        return data


class AesEncrypt(Transform):
    """
    AES cipher encryption
    """
    category = "crypto (block)"
    name = "aes encrypt"

    def run(self, data:bytes, mode:("ecb","cbc","cfb")="ecb", key:bytes=b"aaaaaaaaaaaaaaaa", iv:bytes=b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00", pad:bool=False):
        if pad:
            data = Padding.pad(data, 16)
        if mode == "ecb":
            cryptor = AES.new(key, AES.MODE_ECB)
        elif mode == "cbc":
            cryptor = AES.new(key, AES.MODE_CBC, iv=iv)
        elif mode == "cfb":
            cryptor = AES.new(key, AES.MODE_CFB, iv=iv)
        return cryptor.encrypt(data)


class BlowfishDecrypt(Transform):
    """
    Blowfish cipher decryption
    """
    category = "crypto (block)"
    name = "blowfish decrypt"

    def run(self, data:bytes, mode:("ecb","cbc","cfb")="ecb", key:bytes=b"\x00\x00\x00\x00", iv:bytes=b"\x00\x00\x00\x00\x00\x00\x00\x00", unpad:bool=False):
        if mode == "ecb":
            decryptor = Blowfish.new(key, Blowfish.MODE_ECB)
        elif mode == "cbc":
            decryptor = Blowfish.new(key, Blowfish.MODE_CBC, iv=iv)
        elif mode == "cfb":
            decryptor = Blowfish.new(key, Blowfish.MODE_CFB, iv=iv)
        data = decryptor.decrypt(data)
        if unpad:
            data = Padding.unpad(data, 8)
        return data    


class BlowfishEncrypt(Transform):
    """
    Blowfish cipher encryption
    """
    category = "crypto (block)"
    name = "blowfish encrypt"

    def run(self, data:bytes, mode:("ecb","cbc","cfb")="ecb", key:bytes=b"\x00\x00\x00\x00", iv:bytes=b"\x00\x00\x00\x00\x00\x00\x00\x00", pad:bool=False):
        if pad:
            data = Padding.pad(data, 8)
        if mode == "ecb":
            cryptor = Blowfish.new(key, Blowfish.MODE_ECB)
        elif mode == "cbc":
            cryptor = Blowfish.new(key, Blowfish.MODE_CBC, iv=iv)
        elif mode == "cfb":
            cryptor = Blowfish.new(key, Blowfish.MODE_CFB, iv=iv)
        return cryptor.encrypt(data)    


class DesDecrypt(Transform):
    """
    DES cipher decryption
    """
    category = "crypto (block)"
    name = "des decrypt"

    def run(self, data:bytes, mode:("ecb","cbc","cfb")="ecb", key:bytes=b"aaaaaaaa", iv:bytes=b"\x00\x00\x00\x00\x00\x00\x00\x00", unpad:bool=False):
        if mode == "ecb":
            decryptor = DES.new(key, DES.MODE_ECB)
        elif mode == "cbc":
            decryptor = DES.new(key, DES.MODE_CBC, iv=iv)
        elif mode == "cfb":
            decryptor = DES.new(key, DES.MODE_CFB, iv=iv)
        data = decryptor.decrypt(data)
        if unpad:
            data = Padding.unpad(data, 8)
        return data    


class DesEncrypt(Transform):
    """
    DES cipher encryption
    """
    category = "crypto (block)"
    name = "des encrypt"

    def run(self, data:bytes, mode:("ecb","cbc","cfb")="ecb", key:bytes=b"aaaaaaaa", iv:bytes=b"\x00\x00\x00\x00\x00\x00\x00\x00", pad:bool=False):
        if pad:
            data = Padding.pad(data, 8)
        if mode == "ecb":
            cryptor = DES.new(key, DES.MODE_ECB)
        elif mode == "cbc":
            cryptor = DES.new(key, DES.MODE_CBC, iv=iv)
        elif mode == "cfb":
            cryptor = DES.new(key, DES.MODE_CFB, iv=iv)
        return cryptor.encrypt(data)        

class Des3Decrypt(Transform):
    """
    3DES cipher decryption
    key must be 16 or 24 bytes
    """
    category = "crypto (block)"
    name = "3des decrypt"

    def run(self, data:bytes, mode:("ecb","cbc","cfb")="ecb", key:bytes=b"0123456789abcdef", iv:bytes=b"\x00\x00\x00\x00\x00\x00\x00\x00", unpad:bool=False):
        if mode == "ecb":
            decryptor = DES3.new(key, DES.MODE_ECB)
        elif mode == "cbc":
            decryptor = DES3.new(key, DES.MODE_CBC, iv=iv)
        elif mode == "cfb":
            decryptor = DES3.new(key, DES.MODE_CFB, iv=iv)
        data = decryptor.decrypt(data)
        if unpad:
            data = Padding.unpad(data, 8)
        return data    


class Des3Encrypt(Transform):
    """
    3DES cipher encryption
    key must be 16 or 24 bytes
    """
    category = "crypto (block)"
    name = "3des encrypt"

    def run(self, data:bytes, mode:("ecb","cbc","cfb")="ecb", key:bytes=b"0123456789abcdef", iv:bytes=b"\x00\x00\x00\x00\x00\x00\x00\x00", pad:bool=False):
        if pad:
            data = Padding.pad(data, 8)
        if mode == "ecb":
            cryptor = DES3.new(key, DES3.MODE_ECB)
        elif mode == "cbc":
            cryptor = DES3.new(key, DES3.MODE_CBC, iv=iv)
        elif mode == "cfb":
            cryptor = DES3.new(key, DES3.MODE_CFB, iv=iv)
        return cryptor.encrypt(data)           
