from transforms.base import *
import base64
import re
import codecs
import struct

STANDARD_CODECS = ("utf-8","utf-16le", "utf-16-be", "utf-32le", "utf-32be", "cp437", "cp850", "cp866", "cp1252", "latin1", "gb2312")

class Base64Decode(Transform):
    """
    base64 decoding
    """
    category = "encoding"
    name = "base64 decode"

    def run(self, data:bytes, automatically_add_padding:bool=False, ignore_invalid_characters:bool=False):
        if ignore_invalid_characters:
            data = re.sub(b"[^a-zA-Z0-9+/=]", b"", data)
        if automatically_add_padding and (len(data) % 4):
            data += b"=" * (4 - len(data) % 4)
        return base64.b64decode(data)


class Base64Encode(Transform):
    """
    base64 encoding
    """
    category = "encoding"
    name = "base64 encode"

    def run(self, data:bytes):
        return base64.b64encode(data)

class TextTranscode(Transform):
    """
    change text encoding
    """
    category = "encoding"
    name = "text encoding"

    def run(self, data:bytes, source:STANDARD_CODECS="utf-16le", dest:STANDARD_CODECS="utf-8"):
        return data.decode(source).encode(dest)


class Rot13(Transform):
    """
    rot13 encoding/decoding
    """
    category = "encoding"
    name = "rot13"

    def run(self, data:bytes, encoding:STANDARD_CODECS=STANDARD_CODECS[0]):
        return codecs.encode(data.decode(encoding), "rot-13").encode(encoding)


class HexDecode(Transform):
    """
    hex decoding
    """
    category = "encoding"
    name = "hex decode"

    def run(self, data:bytes, ignore_nonhexa_characters:bool=False):
        if ignore_nonhexa_characters:
            data = re.sub(b"[^a-fA-F0-9]", b"", data)
        if len(data) % 2:
            data += b"0"
        return bytes.fromhex(data.decode("ascii"))


class HexEncode(Transform):
    """
    hex encoding
    """
    category = "encoding"
    name = "hex encode"

    def run(self, data:bytes, uppercase:bool=False):
        data = data.hex()
        if uppercase:
            data = data.upper()
        return data.encode("ascii")


class ListDecode(Transform):
    """
    convert a list (with separators) of numbers in range [0-256[ to an array of bytes

    "1, 32, 128" -> { 01 20 80 }
    """
    category = "encoding"
    name = "list decode"

    def run(self, data:bytes, base:("binary", "octal", "decimal", "hexadecimal", "base64")="decimal", ignore_errors:bool=False):
        res = bytearray()
        interval, decode = {
            "binary": ("01", lambda x: int(x, base=2)),
            "octal": ("0-7", lambda x: int(x, base=8)),
            "decimal": ("0-9", lambda x: int(x, base=10)),
            "hexadecimal": ("0-9a-fA-F", lambda x: int(x, base=16)),
            "base64": ("a-zA-Z0-9+/=", lambda x: struct.unpack_from("<B", base64.b64decode(x))[0]),
        }[base]
        try:
            for m in re.finditer("[{}]+".format(interval).encode("ascii"), data):
                number = decode(m.group(0))
                if number < 0 or number > 255:
                    raise ValueError("Number not in range: {}".format(m.group(0)))
                res.append(number)
        except BaseException:
            if not ignore_errors:
                raise
        return res


class ListEncode(Transform):
    """
    convert a byte array to a list of numbers (one number for each byte) in the chosen base and with the chosen separator
    
    { 01 20 80 } -> "1, 32, 128"
    """
    category = "encoding"
    name = "list encode"

    def run(self, data:bytes, base:("binary", "octal", "decimal", "hexadecimal", "base64")="decimal", separator:bytes=b","):
        res = []
        encode = {
            "binary": lambda x: "{:b}".format(x).encode("ascii"),
            "octal": lambda x: "{:o}".format(x).encode("ascii"),
            "decimal": lambda x: "{:d}".format(x).encode("ascii"),
            "hexadecimal": lambda x: "{:x}".format(x).encode("ascii"),
            "base64": lambda x: base64.b64encode(struct.pack("<B", x)),
        }[base]
        for c in data:
            res.append(encode(c))
        return separator.join(res)
