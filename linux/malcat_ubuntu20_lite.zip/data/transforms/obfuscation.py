import re
from transforms.base import *

class Chr(Transform):
    """
    Replace occurence of Chr(xxx) calls by their value: Chr(65) -> A
    if <quote> is true, character will be enclosed in quotation marks: Chr(65) -> "A"
    """
    category = "obfuscation"
    name = "chr"

    def run(self, data:bytes, quote:bool=False):
        def rep(m):
            c = chr(int(m.group(1))).encode("utf8")
            if quote:
                c = b'"' + c + b'"'
            return c
        return re.sub(rb"chr\((\d+)\)", rep, data, flags=re.I)


class VbObfuscation(Transform):
    """
    Remove classical obfuscation found in VB code like
    """
    category = "obfuscation"
    name = "visual basic"

    def run(self, data:bytes):
        data = Chr().run(data, True)
        for r in (
                b"\"\\s*&\\s*\"",
                ):
            data = re.sub(r, b"", data, flags=re.I)   
        return data


class EscapingObfuscation(Transform):
    """
    Remove classical character escaping obfuscation like \\uCCCC or \\xCC or \\CCC when it's in the ascii range by the actual character.
    """
    category = "obfuscation"
    name = "escaping"

    def run(self, data:bytes):
        def replace(m, base=16):
            num = int(m.group(1), base=base)
            if num >= 0x20 and num < 0x80 or num in (7, 10, 13):
                return num.to_bytes(1, byteorder="little")
            return m.group(0)
        for r, b in (
                (b"\\\\u([0-9a-fA-F]{2,4})", 16),
                (b"\\\\x([0-9a-fA-F]{2})", 16),
                (b"\\\\([0-9]{1,3})", 8),
                ):
            data = re.sub(r, lambda x: replace(x, b), data, flags=re.I)   
        return data
