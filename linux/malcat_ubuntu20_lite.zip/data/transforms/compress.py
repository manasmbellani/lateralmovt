from transforms.base import *
import zlib
import lzma
import bz2
import struct
import math


class Deflate(Transform):
    """
    Deflate -> pack a stream
    window_size: base-two logarithm of window size, must be >= 8 and <= 15, defaults to 15
    """
    category = "compress"
    name = "deflate"

    def run(self, data:bytes, window_size:int=15):
        if window_size < 8 or window_size > 15:
            raise ValueError("Invalid window_size value")
        o = zlib.compressobj(wbits=-window_size)
        return o.compress(data) + o.flush()

class Inflate(Transform):
    """
    Inflate -> unpack an deflated stream
    window_size: base-two logarithm of window size, must be >= 8 and <= 15, defaults to 15
    """
    category = "compress"
    name = "inflate"

    def run(self, data:bytes, window_size:int=15):
        if window_size < 8 or window_size > 15:
            raise ValueError("Invalid window_size value")
        return zlib.decompress(data, wbits=-window_size)


class ZlibCompress(Transform):
    """
    Compress a stream using zlib
    window_size: base-two logarithm of window size, must be >= 8 and <= 15, defaults to 15
    """
    category = "compress"
    name = "zlib compress"

    def run(self, data:bytes, window_size:int=15):
        if window_size < 8 or window_size > 15:
            raise ValueError("Invalid window_size value")
        o = zlib.compressobj(wbits=window_size)
        return o.compress(data) + o.flush()

class ZlibDecompress(Transform):
    """
    """
    category = "compress"
    name = "zlib decompress"

    def run(self, data:bytes):
        return zlib.decompress(data)    


class LzmaCompress(Transform):
    """
    """
    category = "compress"
    name = "lzma compress"

    def run(self, data:bytes, format:["XZ", "ALONE"]="ALONE", compression:int=6):
        if format == "ALONE":
            format = lzma.FORMAT_ALONE
        else:
            format = lzma.FORMAT_XZ
        return lzma.compress(data, format=format, preset=compression)

class LzmaDecompress(Transform):
    """
    """
    category = "compress"
    name = "lzma decompress"

    def run(self, data:bytes, raw_mode:bool=False):
        if raw_mode:
            props = lzma._decode_filter_properties(lzma.FILTER_LZMA1, data[0:5])
            return lzma.decompress(data[5:], lzma.FORMAT_RAW, filters=[props]) 
        return lzma.decompress(data)        


class Bzip2Compress(Transform):
    """
    Compress a stream using bzip2
    level: compression level between 1 and 9
    """
    category = "compress"
    name = "bz2 compress"

    def run(self, data:bytes, level:int=9):
        if level < 1 or level > 9:
            raise ValueError("Invalid level value")
        return bz2.compress(data, level)


class Bzip2Decompress(Transform):
    """
    Decompress a stream using bzip2
    """
    category = "compress"
    name = "bz2 decompress"

    def run(self, data:bytes):
        return bz2.decompress(data)


class LzoCompress(Transform):
    """
    Compress using LZO
    level: compression level between 1 (default) and 9
    header: include metadata header for decompression in the output (default: True)
    """
    category = "compress"
    name = "lzo compress"

    def run(self, data:bytes, level:int=1, header:bool=True):
        try:
            import lzo
        except ImportError:
            raise ImportError("You need to install python-lzo library first. On WIndows I suggest that you use some pre-compiled wheel")
        if level < 1 or level > 9:
            raise ValueError("Invalid level value")
        return lzo.compress(data, level, header)

class LzoDecompress(Transform):
    """
    Compress using LZO
    header: header is included in input (default: True)
    buflen: if header is False, a buffer length in bytes must be given that will fit the output
    """
    category = "compress"
    name = "lzo decompress"

    def run(self, data:bytes, header:bool=True, buflen:int=0):
        try:
            import lzo
        except ImportError:
            raise ImportError("You need to install python-lzo library first. On WIndows I suggest that you use some pre-compiled wheel")
        return lzo.decompress(data, header, buflen)            


class OfficeRleUnpack(Transform):
    """
    RLE decoding as used in office documents
    """
    category = "compress"
    name = "Office RLE"

    def run(self, data:bytes):
        result = bytearray()
        if len(data) <= 1 or data[0] != 1:
            raise ValueError("Invalid data")
        ptr = 1
        while ptr < len(data):
            block_ptr = ptr
            header, = struct.unpack("<H", data[ptr:ptr+2])
            block_size = min((header & 0xFFF) + 3, len(data) - ptr)
            sig = (header >> 12) & 0x07
            if sig != 3 and False:
                raise ValueError("Invalid header signature at {}: 0x{:x}".format(ptr, sig))
            is_compressed = (header >> 15) != 0
            ptr += 2
            if not is_compressed:
                # uncompressed chunk
                result.extend(data[ptr:ptr+4096])
                ptr += 4096
            else:
                # comrpessed chunk
                dptr = len(result)
                while ptr < block_ptr + block_size and ptr < len(data):
                    flagbyte = data[ptr]
                    ptr += 1
                    for i in range(8):
                        if ptr >= block_ptr + block_size:
                            break
                        is_copy = (flagbyte & 1) == 1
                        flagbyte = flagbyte >> 1
                        if not is_copy:
                            # literal token
                            result.append(data[ptr])
                            ptr += 1
                        else:
                            # copy token
                            token, = struct.unpack("<H", data[ptr:ptr+2])
                            ptr += 2
                            bit_count = max(4, int(math.ceil(math.log(len(result) - dptr, 2))))
                            length_mask = 0xFFFF >> bit_count
                            offset_mask = ~length_mask
                            length = (token & length_mask) + 3
                            temp1 = token & offset_mask
                            temp2 = 16 - bit_count
                            offset = (temp1 >> temp2) + 1
                            start_point = len(result) - offset
                            for i in range(start_point, start_point + length):
                                result.append(result[i])
        return bytes(result)

