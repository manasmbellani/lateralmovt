from transforms.base import *

class Reverse(Transform):
    """
    Reverse bytes, aka: 00 01 02 03 04 05 -> 05 04 03 02 01 00
    """
    category = "misc"
    name = "reverse"

    def run(self, data:bytes):
        return data[::-1]


class Skip(Transform):
    """
    skip some bytes, aka: 00 01 02 03 04 05 06 07 08 09 -> 00 02 04 06 08

    offset: how many initial bytes to skip
    step: keep every nth byte
    """
    category = "misc"
    name = "skip"

    def run(self, data:bytes, offset:int=0, step:int=2):
        return data[offset::step]    
