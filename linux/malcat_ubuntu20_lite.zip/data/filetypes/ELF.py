from filetypes.base import *
import bindings
import datetime
import struct



class Region:

    def __init__(self, va, vsize, foff, fsize, name, segment, section):
        self.va = va
        self.vsize = vsize
        self.foff = foff
        self.fsize = fsize
        self.segment = segment
        self.section = section
        self.name = name


class ElfHeader(Struct):

    def parse(self):
        yield Bytes(4, name="Magic")
        cls = yield UInt8(name="Class", values=[
            ("ELFCLASS32", 1),
            ("ELFCLASS64", 2),
            ])
        lsb = yield UInt8(name="DataEncoding", values=[
            ("LSB", 1),
            ("MSB", 2),
            ])
        yield UInt8(name="Version", comment="should be set to EV_CURRENT(1)")
        yield Unused(9, name="Reserved")
        if lsb == 1:
            uint16 = UInt16
            uint32 = UInt32
            if cls == 1:
                offset = Offset32
                va = Va32
            else:
                offset = Offset64
                va = Va64
        else:
            uint16 = UInt16BE
            uint32 = UInt32BE
            if cls == 1:
                offset = Offset32BE
                va = Va32BE
            else:
                offset = Offset64BE
                va = Va64BE
        yield uint16(name="Type", comment="executable type", values=[
            ("NONE",        0),
            ("REL",         1),
            ("EXEC",        2),
            ("DYN",         3),
            ("CORE",        4),
            ])
        yield uint16(name="Machine", comment="required architecture", values=[
            ("NONE",                0),
            ("M32",                 1),
            ("SPARC",               2),
            ("Intel 386",           3),
            ("Motorola 68000",      4),
            ("Motorola 88000",      5),
            ("Intel 486",           6),
            ("Intel 860",           7),
            ("MIPS 1",              8),
            ("Amdahl System/370",   9),
            ("MIPS RS3000",        10),
            ("IBM RS6000",         11),
            ("HP PA-RISC",         15),
            ("Fujitsu VPP500",     17),
            ("Enhanced SPARC", 18),
            ("Intel 80960", 19),
            ("PowerPC", 20),
            ("64-bit PowerPC", 21),
            ("IBM System/390", 22),
            ("NEC V800", 36),
            ("Fujitsu FR20", 37),
            ("TRW RH-32", 38),
            ("Motorola RCE", 39),
            ("Advanced RISC", 40),
            ("Digital Alpha", 41),
            ("Hitachi SH", 42),
            ("SPARC Version 9", 43),
            ("Siemens TriCore", 44),
            ("Argonaut RISC Core", 45),
            ("Hitachi H8/300", 46),
            ("Hitachi H8/300H", 47),
            ("Hitachi H8S", 48),
            ("Hitachi H8/500", 49),
            ("Intel IA-64", 50),
            ("Stanford MIPS-X", 51),
            ("Motorola ColdFire", 52),
            ("Motorola M68HC12", 53),
            ("Fujitsu MMA", 54),
            ("Siemens PCP", 55),
            ("Sony nCPU", 56),
            ("Denso NDR1", 57),
            ("Motorola Star*Core", 58),
            ("Toyota ME16", 59),
            ("STMicroelectronics ST100", 60),
            ("TinyJ", 61),
            ("AMD x86-64", 62),
            ("Sony DSP", 63),
            ("PDP-10", 64),
            ("PDP-11", 65),
            ("Siemens FX66", 66),
            ("ST9+", 67),
            ("ST7", 68),
            ("MC68HC16", 69),
            ("MC68HC11", 70),
            ("MC68HC08", 71),
            ("MC68HC05", 72),
            ("Graphics SVx", 73),
            ("ST19", 74),
            ("VAX", 75),
            ("Axis Communications", 76),
            ("Infineon Technologies", 77),
            ("Element 14", 78),
            ("LSI Logic", 79),
            ("Donald Knuth's educational 64-bit processor", 80),
            ("Harvard University machine-independent object files", 81),
            ("SiTera Prism", 82),
            ("Atmel AVR", 83),
            ("Fujitsu FR30", 84),
            ("Mitsubishi D10V", 85),
            ("Mitsubishi D30V", 86),
            ("NEC v850", 87),
            ("Mitsubishi M32R", 88),
            ("Matsushita MN10300", 89),
            ("Matsushita MN10200", 90),
            ("picoJava", 91),
            ("OpenRISC", 92),
            ("Tangent-A5", 93),
            ("Tensilica Xtensa", 94),
            ("Alphamosaic VideoCore", 95),
            ("Thompson Multimedia", 96),
            ("National Semiconductor 32000", 97),
            ("Tenor Network TPC", 98),
            ("Trebia SNP 1000", 99),
            ("ST200", 100),
            ])
        yield uint32(name="Version", comment="should be 1")
        yield va(name="Entry", comment="program entry point")
        yield offset(name="ProgramHeaderOffset", comment="program header table’s file offset in bytes")
        yield offset(name="SectionHeaderOffset", comment="section header table’s file offset in bytes")
        yield uint32(name="Flags", comment="processor-specific flags associated with the file")
        yield uint16(name="ElfHeaderSize", comment="this header's size") 
        yield uint16(name="ProgramHeaderEntrySize", comment="size in bytes of one entry in the file’s program header table; all entries are the same size") 
        yield uint16(name="ProgramHeaderNum", comment="number of entries in the program header table")
        yield uint16(name="SectionHeaderEntrySize", comment="size in bytes of one entry in the file’s program section table; all entries are the same size") 
        yield uint16(name="SectionHeaderNum", comment="number of entries in the section header table")
        yield uint16(name="SectionHeaderStringIndex", comment="section header table index of the entry associated with the section name string table. If the file has no section name string table, this member holds the value SHN_UNDEF")



class SectionHeader(Struct):

    def parse(self):
        yield self.analyzer.offset32(name="Name", base=self.analyzer.strings_base, hint=String(0, zero_terminated=True), comment="index into the section header string table section")
        yield self.analyzer.uint32(name="Type", values=[
            ("NULL",        0),
            ("PROGBITS",    1),
            ("SYMTAB",      2),
            ("STRTAB",      3),
            ("RELA",        4),
            ("HASH",        5),
            ("DYNAMIC",     6),
            ("NOTE",        7),
            ("NOBITS",      8),
            ("REL",         9),
            ("SHLIB",       10),
            ("DYNSYM",      11),
            ("INIT_ARRAY",  14),
            ("FINI_ARRAY",  15),
            ("PREINIT_ARRAY",  16),
            ("GROUP",       17),
            ("SYMTAB_SHNDX",18),
            ])
        bits = [
                Bit(name="Write", comment="section contains data that should be writable during process execution"),
                Bit(name="Alloc", comment="section occupies memory during process execution"),
                Bit(name="Execute", comment="section contains executable machine instructions"),
                NullBits(1),
                Bit(name="Merged", comment="section may be merged"),
                Bit(name="Strings", comment="section contains strings"),
                Bit(name="InfoLink", comment="Info field is valid"),
                Bit(name="PreserveLinkOrder", comment="requires special ordering for linker"),
                Bit(name="OsSpecific", comment="os-specific processing"),
                Bit(name="GroupMember", comment="section is a member of a section group"),
                Bit(name="Tls", comment="section contains TLS data"),
                Bit(name="Compressed", comment="section contains compressed data"),
            ]
        if self.analyzer.is64:
            bits.append(NullBits(52))
        else:
            bits.append(NullBits(20))
        yield BitsField(*bits, name="Flags")
        yield self.analyzer.va(name="Address", comment="if the section will appear in the memory image of a process, this member gives the address at which the section's first byte should reside")
        yield self.analyzer.offset(name="Offset", comment="byte offset from the beginning of the file to the first byte in the section. One section type, SHT_NOBITS described below, occupies no space in the file, and this member locates the conceptual placement in the file")
        yield self.analyzer.uint(name="Size", comment="section's size in bytes")
        yield self.analyzer.uint32(name="Link", comment="section header table index link, whose interpretation depends on the section type")
        yield self.analyzer.uint32(name="Info", comment="extra information, whose interpretation depends on the section type")
        yield self.analyzer.uint(name="Align", comment="section virtual alignment. only 0 and positive integral powers of two are allowed")
        yield self.analyzer.uint(name="EntrySize", comment="some sections hold a table of fixed-size entries, such as a symbol table. For such a section, this member gives the size in bytes of each entry. The member contains 0 if the section does not hold a table of fixed-size entries")


class ProgramHeader(Struct):

    def parse(self):
        yield self.analyzer.uint32(name="Type", values=[
            ("UNUSED",      0),
            ("LOAD",        1),
            ("DYNAMIC",     2),
            ("INTERP",      3),
            ("NOTE",        4),
            ("SHLIB",       5),
            ("PHDR",        6),
            ("TLS",         7),
            ("GNU_EH_FRAME",0x6474e550),
            ("GNU_STACK",   0x6474e551),
            ("GNU_UNWIND",  0x6464e550),
            ("TLS",         7),
            ("TLS",         7),
            ])
        flags = BitsField(
                Bit(name="Execute", comment="segment is executable"),
                Bit(name="Write", comment="segment is writable"),
                Bit(name="Read", comment="segment is executable"),
                NullBits(29),
                name="Flags")
        if self.analyzer.is64:
            yield flags
        yield self.analyzer.offset(name="Offset", comment="offset from the beginning of the file at which the first byte of the segment resides")
        yield self.analyzer.va(name="Vaddress", comment="virtual address at which the first byte of the segment resides in memory")
        yield self.analyzer.va(name="Paddress", comment="on systems for which physical addressing is relevant, this member is reserved for the segment's physical address")
        yield self.analyzer.uint(name="FileSize", comment="number of bytes in the file image of the segment")
        yield self.analyzer.uint(name="VirtualSize", comment="number of bytes in the memory image of the segment")
        if not self.analyzer.is64:
            yield flags
        yield self.analyzer.uint(name="Align", comment="if the section will appear in the memory image of a process, this member gives the address at which the section's first byte should reside")



class SymbolEntry(Struct):

    def __init__(self, string_base, *args, **kwargs):
        Struct.__init__(self, *args, **kwargs)
        self.string_base = string_base

    def parse(self):
        yield self.analyzer.offset32(name="Name", base=self.string_base, hint=String(0, zero_terminated=True), comment="index into the object file's symbol string table")
        yield self.analyzer.va(name="Value", comment="value of the associated symbol. Depending on the context, this may be an absolute value, an address, and so on")
        yield self.analyzer.uint(name="Size", comment="many symbols have associated sizes. For example, a data object's size is the number of bytes contained in the object. This member holds 0 if the symbol has no size or an unknown size")
        yield UInt8(name="Info", comment="additional symbol info")
        yield UInt8(name="Other", comment="currently holds 0 and has no defined meaning")
        yield UInt16(name="SectionIndex", comment="holds the relevant section header table index")


class SymbolEntry64(Struct):

    def __init__(self, string_base, *args, **kwargs):
        Struct.__init__(self, *args, **kwargs)
        self.string_base = string_base

    def parse(self):
        yield self.analyzer.offset32(name="Name", base=self.string_base, hint=String(0, zero_terminated=True), comment="index into the object file's symbol string table")
        yield UInt8(name="Info", comment="additional symbol info")
        yield UInt8(name="Other", comment="currently holds 0 and has no defined meaning")
        yield UInt16(name="SectionIndex", comment="holds the relevant section header table index")        
        yield self.analyzer.va(name="Value", comment="value of the associated symbol. Depending on the context, this may be an absolute value, an address, and so on")
        yield self.analyzer.uint(name="Size", comment="many symbols have associated sizes. For example, a data object's size is the number of bytes contained in the object. This member holds 0 if the symbol has no size or an unknown size")


class Reloc(Struct):

    VALUES_X86 = [
        ("NONE",                0),
        ("386_32",              1),
        ("386_PC32",            2),
        ("386_GOT32",           3),
        ("386_PLT32",           4),
        ("386_COPY",            5),
        ("386_GLOB_DAT",        6),
        ("386_JUMP_SLOT",       7),
        ("386_RELATIVE",        8),
        ("386_GOT_OFF",         9),
        ("386_GOT_PC",         10),
        ("386_32PLT",          11),
        ("386_16",             20),
        ("386_PC16",           21),
        ("386_8",              22),
        ("386_PC8",            23),
        ("386_SIZE32",         38),
    ]

    VALUES_X64 = [
        ("NONE",                  0),
        ("AMD64_64",              1),
        ("AMD64_PC32",            2),
        ("AMD64_GOT32",           3),
        ("AMD64_PLT32",           4),
        ("AMD64_COPY",            5),
        ("AMD64_GLOB_DAT",        6),
        ("AMD64_JUMP_SLOT",       7),
        ("AMD64_RELATIVE",        8),
        ("AMD64_GOTPCREL",        9),
        ("AMD64_32",             10),
        ("AMD64_32S",            11),
        ("AMD64_16",             12),
        ("AMD64_PC16",           13),
        ("AMD64_8",              14),
        ("AMD64_PC8",            15),
        ("AMD64_PC64",           24),
        ("AMD64_GOTOFF64",       25),
        ("AMD64_GOTPC32",        26),
        ("AMD64_SIZE32",         32),
        ("AMD64_SIZE64",         33),
    ]

    def __init__(self, addend, *args, **kwargs):
        Struct.__init__(self, *args, **kwargs)
        self.addend = addend

    def parse(self):
        yield self.analyzer.va(name="Address", comment="virtual address of the storage unit affected by the relocation")
        if self.analyzer.is64:
            if self.analyzer.lsb:
                yield self.analyzer.uint32(name="Type", values=Reloc.VALUES_X64)
                yield self.analyzer.uint32(name="Symbol")
            else:
                yield self.analyzer.uint32(name="Symbol")
                yield self.analyzer.uint32(name="Type", values=Reloc.VALUES_X64)
        else:
            if self.analyzer.lsb:
                yield UInt8(name="Type", values=Reloc.VALUES_X86)
                yield self.analyzer.uint24(name="Symbol")
            else:
                yield self.analyzer.uint24(name="Symbol")
                yield UInt8(name="Type", values=Reloc.VALUES_X86)
        if self.addend:
            yield self.analyzer.int(name="Addend")


class DynEntry(Struct):

    def parse(self):
        yield self.analyzer.uint(name="Tag", values=[
            ("NULL",        0),
            ("NEEDED",      1),
            ("PLTRELSZ",    2),
            ("PLTGOT",      3),
            ("HASH",        4),
            ("STRTAB",      5),
            ("SYMTAB",      6),
            ("RELA",        7),
            ("RELASZ",      8),
            ("RELAENT",     9),
            ("STRSZ",       10),
            ("SYMENT",      11),
            ("INIT",        12),
            ("FINI",        13),
            ("SONAME",      14),
            ("RPATH",       15),
            ("SYMBOLIC",    16),
            ("REL",         17),
            ("RELSZ",       18),
            ("RELENT",      19),
            ("PLTREL",      20),
            ("DEBUG",       21),
            ("TEXTREL",     22),
            ("JMPREL",      23),
            ("BIND_NOW",    24),
            ("INIT_ARRAY",  25),
            ("FINI_ARRAY",  26),
            ("INIT_ARRAYSZ",27),
            ("FINI_ARRAYSZ",28),
            ("RUN_PATH",    29),
            ("FLAGS",       30),
            ("ENCODING",    32),
            ("MOVETAB",     0x6ffffffe),
            ("VERNEEDNUM",  0x6fffffff),
            ])
        yield self.analyzer.uint(name="Value")


class ELFAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.PROGRAM
    name = "ELF"
    regexp = r"\x7fELF[\x01\x02]{2}\x01.\x00\x00"


    def __init__(self):
        FileTypeAnalyzer.__init__(self)
        for cat in ("", "VersionInfo"):
            self.metadata[cat] = {}
        self.regions = []
        self.imagebase = 0
        self.is64 = False
        self.architecture = bindings.FileType.X86


    def va2off(self, va):
        if not va:
            return None
        for s in self.regions:
            if va >= s.va and va < s.va + s.vsize:
                delta = va - s.va
                if delta < s.fsize:
                    return s.foff + delta
        return None

    def off2va(self, off):
        for s in self.regions:
            if off >= s.foff and off < s.foff + s.fsize:
                delta = off - s.foff
                if delta < s.fsize:
                    return s.va + delta
        return None


    def read_string(self, a):
        if a == 0 or a >= self.strings_size:
            return ""
        else:
            return self.read_cstring_ascii(self.strings_base + a, self.strings_size - a)


    def parse_relocs(self):
        for section in self.elf_sections:
            if section["Type"] not in (4,9):
                continue
            addend = section["Type"] == 4
            sname = self.read_string(section["Name"])
            self.jump(section["Offset"])
            ar = yield Array(section["Size"] // section["EntrySize"], Reloc(addend), name="Relocations{}".format(sname), category=Type.FIXUP)
            symbol_section = self.elf_sections[section["Link"]]
            symbol_table = self.symbols_tables.get(symbol_section["Offset"], None)
            if symbol_table is None:
                raise FatalError("No symbol table found for {} linked section".format(sname))
            symbol_section_string_base = self.elf_sections[symbol_section["Link"]]["Offset"]
            for rel in ar:
                if rel["Type"] != 7 or rel["Address"] == 0:
                    continue
                symbol = symbol_table[rel["Symbol"]]
                symbol_name = self.read_cstring_ascii(symbol["Name"] + symbol_section_string_base)
                self.symbols.append(bindings.FileSymbol(
                        rel["Address"],
                        bindings.FileSymbol.IMPORT,
                        symbol_name))



    def parse_dynamic(self):
         for seg in self.segments:
            if seg["Type"] != 2:
                continue
            if self.is64:
                ssize = 16
            else:
                ssize = 8
            self.jump(seg["Offset"])
            yield Array(seg["FileSize"] // ssize, DynEntry(), name="Dynamic", category=Type.HEADER)
            

    def parse_symbols(self):
        for section in self.elf_sections:
            if section["Type"] not in (11, 2):
                continue
            if section["Link"] == 0 or section["Link"] >= len(self.elf_sections):
                raise ParsingError("Symbol section without link") 
            symbols_strings_section = self.elf_sections[section["Link"]]
            section_name = self.read_string(section["Name"])
            self.jump(section["Offset"])
            if self.is64:
                clas = SymbolEntry64
            else:
                clas = SymbolEntry
            ar = yield Array(section["Size"] // section["EntrySize"], clas(symbols_strings_section["Offset"]), name="Symbols{}".format(section_name), category=Type.DEBUG)
            self.symbols_tables[ar.offset] = ar
            for symbol in ar:
                if symbol["Name"] and (symbol["Info"] & 0x0F) == 2 and symbol["Value"] != 0:
                    # function
                    symbol_name = self.read_cstring_ascii(symbol["Name"] + symbols_strings_section["Offset"])
                    self.symbols.append(bindings.FileSymbol(
                        symbol["Value"],
                        bindings.FileSymbol.FUNCTION,
                        symbol_name))
            self.jump(symbols_strings_section["Offset"])
            yield Bytes(symbols_strings_section["Size"], name="Strings{}".format(section_name), category=Type.DATA)


    def parse_ctors_dtors(self):
        for section in self.elf_sections:
            name = self.read_string(section["Name"])
            self.jump(section["Offset"])
            if name in (".ctors", ".dtors"):
                data = self.read(section["Offset"], section["Size"])
                first = True
                start = None
                stop = None
                for i, element in enumerate(struct.iter_unpack(self.fmtptr, data)):
                    element = element[0]
                    if first and element in (0xffffffff, 0xffffffffffffffff):
                        continue
                    first = False
                    if not element or self.va2off(element) is None:
                        break
                    cur = self.tell() + i * struct.calcsize(self.fmtptr)
                    if start is None:
                        start = cur
                    stop = cur + struct.calcsize(self.fmtptr)
                    self.symbols.append(bindings.FileSymbol(
                        element,
                        bindings.FileSymbol.ENTRY,
                        "{}_#{:d}".format(name[1:], i)))
                if start and start < stop:
                    self.jump(start)
                    yield Array((stop - start) // struct.calcsize(self.fmtptr), self.va(), name=(name==".ctors" and "Constructors" or "Destructors"), category=Type.HEADER)


    def parse_comments(self):
        for section in self.elf_sections:
            name = self.read_string(section["Name"])
            if name in (".comment",):
                try:
                    data = self.read(section["Offset"], section["Size"]).decode("ascii")
                except: break
                self.jump(section["Offset"])
                yield Bytes(section["Size"], name="Comment", category=Type.META)
                self.metadata["Comments"] = {}
                for l in data.replace("\x00", "\n").splitlines():
                    splitted = l.split(":")
                    key = splitted[0].strip()
                    value = ":".join(splitted[1:]).strip()
                    i = 1
                    while key in self.metadata["Comments"]:
                        i += 1
                        key = "{}#{:d}".format(splitted[0].strip(), i)
                    if key and value:
                        self.metadata["Comments"][key] = value
                        





    def parse(self, hint):
        eh = yield ElfHeader(name="ELF", category=Type.HEADER)
        if eh["Class"] == 2:
            self.is64 = True
            self.architecture = bindings.FileType.X64
        if eh["DataEncoding"] == 1:
            self.lsb = True
            self.uint16 = UInt16
            self.uint24 = UInt24
            self.uint32 = UInt32
            self.int32 = Int32
            self.uint64 = UInt64
            self.int64 = Int64
            self.offset32 = Offset32
            if not self.is64:
                self.offset = Offset32
                self.va = Va32
                self.fmtptr = "<I"
            else:
                self.offset = Offset64
                self.va = Va64
                self.fmtptr = "<Q"
            self.fmtendian = "<"
        else:
            self.lsb = False
            self.uint16 = UInt16BE
            self.uint24 = UInt24BE
            self.uint32 = UInt32BE
            self.int32 = Int32BE
            self.uint64 = UInt64BE
            self.int64 = Int64BE
            self.offset32 = Offset32BE
            if not self.is64:
                self.offset = Offset32BE
                self.va = Va32BE
                self.fmtptr = ">I"
            else:
                self.offset = Offset64BE
                self.va = Va64BE
                self.fmtptr = ">Q"
            self.fmtendian = ">"
        if self.is64:
            self.uint = self.uint64
            self.int = self.int64
        else:
            self.uint = self.uint32
            self.int = self.int32
        self.strings_base = 0
        self.strings_size = 0
        self.symbols.append(bindings.FileSymbol(
                        eh["Entry"],
                        bindings.FileSymbol.ENTRY,
                        "EntryPoint"))

        self.elf_sections = []
        self.segments = []
        if eh["SectionHeaderNum"] and eh["SectionHeaderOffset"]:
            self.jump(eh["SectionHeaderOffset"])
            # we have to read string table base before parsing sections
            if eh["SectionHeaderStringIndex"] and eh["SectionHeaderStringIndex"] < eh["SectionHeaderNum"]:
                if self.is64:
                    self.strings_base, self.strings_size = struct.unpack("{}QQ".format(self.fmtendian), self.read(self.tell() + 64*eh["SectionHeaderStringIndex"] + 24, 16))
                else:
                    self.strings_base, self.strings_size = struct.unpack("{}II".format(self.fmtendian), self.read(self.tell() + 40*eh["SectionHeaderStringIndex"] + 16, 8))
                if self.strings_base >= self.size():
                    raise FatalError("Invalid section strings base")
            self.elf_sections = yield Array(eh["SectionHeaderNum"], SectionHeader(), name="Sections", category=Type.HEADER)
        if self.strings_size:
            self.jump(self.strings_base)
            yield Bytes(self.strings_size, name="Strings.sections", category=Type.DATA)

        if eh["ProgramHeaderNum"] and eh["ProgramHeaderOffset"]:
            self.jump(eh["ProgramHeaderOffset"])
            self.segments = yield Array(eh["ProgramHeaderNum"], ProgramHeader(), name="Segments", category=Type.HEADER)
        for segment in self.segments:
            if segment["Offset"] >= self.size():
                raise FatalError("Invalid segment offset, starts after file size")
        self.confirm()

        # map segment and sections to regions
        last_off = 0
        while last_off < self.size():
            next_region_off = self.size()
            for r in self.regions:
                if r.foff + r.fsize <= last_off:
                    continue
                next_region_off = r.foff + r.fsize
                if r.foff <= last_off:
                    last_off = next_region_off  # already mapped, skip mapped range
                    continue
            # check which segments and sections map [last_off:next_region_off[
            sections = []
            segments = []
            for section in self.elf_sections:
                if section["Type"] == 8 or section["Type"] == 0 or section["Size"] == 0:
                    continue
                if section["Offset"] > last_off:
                    next_region_off = min(next_region_off, section["Offset"])
                elif section["Offset"] + section["Size"] > last_off:
                    name = self.read_string(section["Name"])
                    next_region_off = min(next_region_off, section["Offset"] + section["Size"])
                    sections.append((name, section))
            for segi, seg in enumerate(self.segments):
                if seg["Offset"] > last_off:
                    if seg["FileSize"]:
                        next_region_off = min(next_region_off, seg["Offset"])
                elif seg["Offset"] + seg["FileSize"] > last_off:
                    next_region_off = min(next_region_off, seg["Offset"] + seg["FileSize"])
                    segments.append(("segment{:d}".format(segi), seg))
            if sections:
                section = sorted(sections, key=lambda x: x[1]["Size"])[0]
            else:
                section = None
            if segments:
                segment = sorted(segments, key=lambda x: x[1]["FileSize"])[0]
            else:
                segment = None
            if section or segment:
                name = ""
                if section:
                    # sections have name 
                    name = section[0]
                    section = section[1]
                if segment:
                    if not name:
                        name = segment[0]
                    segment = segment[1]
                if segment is not None:
                    r = segment["Flags"]["Read"]
                    w = segment["Flags"]["Write"]
                    x = segment["Flags"]["Execute"]
                    d = False
                    va = segment["Vaddress"] + (last_off - segment["Offset"])
                    vsize = segment["VirtualSize"] - (last_off - segment["Offset"])
                else:
                    r = True
                    w = section["Flags"]["Write"]
                    x = section["Flags"]["Execute"]
                    d = not section["Flags"]["Alloc"]
                    va = 0
                    vsize = 0
                # just for internal lookup
                self.regions.append(Region(va, vsize, last_off, next_region_off - last_off, name, segment, section))
                # for malcat framework
                self.sections.append(bindings.Section(last_off, next_region_off - last_off,
                    va, vsize,
                    name,
                    r, w, x, d)
                )
            last_off = next_region_off
        self.regions = sorted(self.regions, key=lambda x: x.foff)

        #for r in self.regions:
        #    print("{:x} {} #{:x} {} {} {}".format(r.va, r.vsize, r.foff, r.fsize, r.section, r.segment))


        # dynamic
        try:
            yield from self.parse_dynamic()
        except ParsingError as e:
            print(e)

        # symbols
        self.symbols_tables = {}
        try:
            yield from self.parse_symbols()
        except ParsingError as e:
            print(e)

        # relocs
        try:
            yield from self.parse_relocs()
        except ParsingError as e:
            print(e)

        # ctors
        try:
            yield from self.parse_ctors_dtors()
        except ParsingError as e:
            print(e)

        # comments
        try:
            yield from self.parse_comments()
        except ParsingError as e:
            print(e)

        # golang parsing
        try:
            from filetypes.ELF_golang import parse_golang
            yield from parse_golang(self)
        except ParsingError: pass
