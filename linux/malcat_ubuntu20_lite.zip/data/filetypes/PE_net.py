from filetypes.base import *
from filetypes.PE import Resource
import re
import struct
import math
from collections import OrderedDict

# most of the info comes from https://www.codeproject.com/Articles/12585/The-NET-File-Format


TABLES_NAMES = {
        0: "Module",
        1: "TypeRef",
        2: "TypeDef",
        3: "FieldPtr",
        4: "Field",
        5: "MethodDefPtr",
        6: "MethodDef",
        7: "ParamPtr",
        8: "Param",
        9: "InterfaceImpl",
        10: "MemberRef",
        11: "Constant",
        12: "CustomAttribute",
        13: "FieldMarshal",
        14: "DeclSecurity",
        15: "ClassLayout",
        16: "FieldLayout",
        17: "StandAloneSig",
        18: "EventMap",
        19: "EventPtr",
        20: "Event",
        21: "PropertyMap",
        22: "PropertyPtr",
        23: "Property",
        24: "MethodSemantics",
        25: "MethodImpl",
        26: "ModuleRef",
        27: "TypeSpec",
        28: "ImplMap",
        29: "FieldRVA",
        30: "EncLog",
        31: "EncMap",
        32: "Assembly",
        33: "AssemblyProcessor",
        34: "AssemblyOS",
        35: "AssemblyRef",
        36: "AssemblyRefProcessor",
        37: "AssemblyRefOS",
        38: "File",
        39: "ExportedType",
        40: "ManifestResource",
        41: "NestedClass",
        42: "GenericParam",
        43: "MethodSpec",
        44: "GenericParamConstraint",
        }

COMPOSED_INDEXES = {
        "ResolutionScope": (2, {
            "Module":0,
            "ModuleRef":1, 
            "AssemblyRef":2, 
            "TypeRef":3 }),
        "TypeDefOrRef": (2, {
            "TypeDef":0, 
            "TypeRef":1, 
            "TypeSpec":2 }),
        "MemberRefParent": (3, {
            "TypeDef":0, 
            "TypeRef":1, 
            "ModuleRef":2, 
            "MethodDef":3, 
            "TypeSpec":4 }),
        "HasConstant": (2, {
            "Field":0, 
            "ParamDef":1, 
            "Property":2 }),
        "HasCustomAttribute": (5, {
            "MethodDef":0, 
            "Field":1,
            "TypeRef":2, 
            "TypeDef":3, 
            "ParamDef":4, 
            "InterfaceImpl":5,
            "MemberRef":6, 
            "Module":7, 
            "Permission":8, 
            "Property":9, 
            "Event":10, 
            "StandAloneSig":11, 
            "ModuleRef":12,
            "TypeSpec":13, 
            "Assembly":14, 
            "AssemblyRef":15, 
            "File":16, 
            "ExportedType":17, 
            "ManifestResource":18 }),
        "CustomAttributeType": (3, {
            "MethodDef":2,
            "MemberRef":3 }),
        "HasFieldMarshal": (1, {
            "Field":0,
            "ParamDef":1 }),
        "HasDeclSecurity": (2, {
            "TypeDef":0,
            "MethodDef":1,
            "Assembly":2 }),
        "HasSemantics": (1, {
            "Event":0,
            "Property":1 }),
        "MemberForwarded": (1, {
            "Field":0,
            "MethodDef":1 }),
        "MethodDefOrRef": (1, {
            "MethodDef":0,
            "MemberRef":1 }),
        "Implementation": (2, {
            "File":0,
            "AssemblyRef":1,
            "ExportedType": 2}),
        "TypeOrMethodDef": (1, {
            "TypeDef":0,
            "MethodDef":1 }),
        }

ELEMENT_TYPE = {
        0x01: "void", 
        0x02: "bool", 
        0x03: "char", 
        0x04: "int8", 
        0x05: "uint8", 
        0x06: "int16", 
        0x07: "uint16", 
        0x08: "int32", 
        0x09: "uint32", 
        0x0a: "int64", 
        0x0b: "uint64", 
        0x0c: "float", 
        0x0d: "double", 
        0x0e: "string", 
        0x18: "System.IntPtr", 
        0x19: "System.UIntPtr", 
        0x1c: "System.Object", 
        }

def align(val, what):
    if val % what:
        val += what - (val % what)
    return val

def toprintable(s):
    return "".join([ x.isprintable() and x or "\\u{:04x}".format(ord(x)) for x in s])

class InfoDataDirectory(Struct):

    def parse(self):
        yield Rva(name="Rva")
        yield UInt32(name="Size")


class DotnetResource(Struct):

    def __init__(self, max_size, *args, **kwargs):
        Struct.__init__(self, *args, **kwargs)
        self.max_size = max_size

    def parse(self):
        # https://referencesource.microsoft.com/#mscorlib/system/resources/resourcetypecode.cs,77874335894760b1
        ti = yield UInt8(name="ResourceTypeCode", values=[
            ("Null", 0),
            ("String", 1),
            ("Boolean", 2),
            ("Char", 3),
            ("Byte", 4),
            ("SByte", 5),
            ("Int16", 6),
            ("UInt16", 7),
            ("Int32", 8),
            ("UInt32", 9),
            ("Int64", 0xa),
            ("UInt64", 0xb),
            ("Single", 0xc),
            ("Double", 0xd),
            ("Decimal", 0xe),
            ("DateTime", 0xf),
            ("TimeSpan", 0x10),
            ("BytesArray", 0x20),
            ("Stream", 0x21),
        ])
        if ti in (0x20, 0x21):
            resource_size = yield UInt32(name="ResourceSize")
            yield Bytes(resource_size, name="Data")
        else:
            yield Bytes(self.max_size - len(self), name="Data")

class CLIHeader(Struct):
    def parse(self):
        soh = yield UInt32(name="HeaderSize", comment="size of header")
        if soh != 0x48:
            raise FatalError("Invalid CLR Header size")
        yield UInt16(name="CLRMajor", comment="CLR major version")
        yield UInt16(name="CLRMinor", comment="CLR minjor version")
        yield InfoDataDirectory(name="Metadata", comment="metadata directory")
        flags = yield BitsField(
            Bit(name="ILOnly", comment="contains only IL code so that it is not required to run on a specific CPU"),
            Bit(name="32Bits", comment="may only be loaded into a 32-bit process"),
            Bit(name="ILLibrary", comment=""),
            Bit(name="StrongNamesSigned", comment=""),
            Bit(name="NativeEntryPoint", comment=""),
            NullBits(11),
            Bit(name="TrackDebugData", comment="runtime and JIT are required to track debugging information about methods"),
            NullBits(15),
            name="Flags", comment="flags")
        if flags["NativeEntryPoint"]:
            yield Rva(name="EntryPointRva", comment="native entry point")
        else:
            yield UInt32(name="EntryPointToken", comment="entry point token")
        yield InfoDataDirectory(name="Resources", comment=".net resources")
        yield InfoDataDirectory(name="StrongNameSignature", comment="strong names info")
        yield InfoDataDirectory(name="CodeManagerTable", comment="")
        yield InfoDataDirectory(name="VTableFixups", comment="")
        yield InfoDataDirectory(name="ExportAddressTableJumps", comment="")
        yield InfoDataDirectory(name="ManagedNativeHeader", comment="precompiled image info (internal use only - set to zero)")


class MetadataHeader(Struct):

    def parse(self):
        sig = yield UInt32(name="Signature", comment="always 0x424a5342")
        if sig != 0x424a5342:
            raise FatalError("Invalid MetadataHeder signature")
        yield UInt16(name="Major", comment="metadata major version")
        yield UInt16(name="Minor", comment="metadata minor version")
        yield UInt32(name="Reserved")
        vl = yield UInt32(name="VersionLength", comment="length of following field")
        yield String(vl, zero_terminated=False, name="Version")
        yield UInt16(name="Flags", comment="should be zero")
        nos = yield UInt16(name="NumberOfStreams", comment="number of streams following")
        for i in range(nos):
            yield StreamHeader(name="StreamHeader[{}]".format(i))


class StreamHeader(Struct):

    def parse(self):
        yield UInt32(name="Offset", comment="offset of stream, from metadata header")
        yield UInt32(name="Size", comment="size of stream, from metadata header")
        yield CString(name="Name", comment="stream name")
        yield Align(4)



class TablesHeader(Struct):

    def parse(self):
        res = yield UInt32(name="Reserved", comment="always 0")
        if res != 0:
            raise FatalError("Reserved1 is not 0")
        yield UInt8(name="Major", comment="tables major version")
        yield UInt8(name="Minor", comment="tables minor version")
        bf = yield BitsField(
                Bit(name="HugeStringStream", comment="size of #String stream >= 2^16"),
                Bit(name="HugeGuidStream", comment="size of #GUID stream >= 2^16"),
                Bit(name="HugeBlobStream", comment="size of #Blob stream >= 2^16"),
                NullBits(3),
                Bit(name="ExtraDword", comment="extra dword appended after Items table (Confuser)"),
                name="HeapOffsetSizes", comment="encodes how wide indexes into the various heaps are")
        res = yield UInt8(name="Reserved2", comment="always 1")
        # prepare bitfield
        bits = []
        for i in range(64):
            name = TABLES_NAMES.get(i, None)
            if name is None:
                bits.append(NullBits(1))
                #bits.append(Bit(name="Reserved.{}".format(i)))
            else:
                bits.append(Bit(name=name))
        valid = yield BitsField(
            *bits,
            name="Valid", comment="bitfield indicating which tables are present")
        yield BitsField(
            *bits,
            name="Sorted", comment="bitfield indicating which tables are sorted")
        for i in range(64):
            if valid[i]:
                if not i in TABLES_NAMES:
                    raise KeyError("Unknown table {}".format(i))
                name = TABLES_NAMES.get(i, "Reserved{}".format(i))
                yield UInt32(name="{}Items".format(name), comment="number of items in table {}".format(name))
        if bf["ExtraDword"]:
            yield Unused(4, name="ExtraDword", comment="???")


class Module(Struct):

    def parse(self):
        yield UInt16(name="Generation", comment="reserved, shall be zero")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="module name, index into the #Strings heap")
        yield self.analyzer.index_tables_net["#GUID"](name="Mvid", comment="a GUID used to distinguish between two versions of the same module")
        yield self.analyzer.index_tables_net["#GUID"](name="EncId", comment="reserved, shall be zero")
        yield self.analyzer.index_tables_net["#GUID"](name="EncBaseId", comment="reserved, shall be zero")
       

class TypeRef(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["ResolutionScope"](name="Scope", comment="index into Module, ModuleRef, AssemblyRef or TypeRef tables")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="type name")
        yield self.analyzer.index_tables_net["#Strings"](name="TypeNamespace", comment="type namespace")


class TypeDef(Struct):

    def parse(self):
        yield BitsField(
                Bit(name="Public"),
                Bit(name="Nested"),
                Bit(name="Family"),
                Bit(name="SequentialLayout", comment="class fields are laid out sequentially"),
                Bit(name="ExplicitLayout", comment="class layout is supplied explicitly"),
                Bit(name="Interface", comment="type is an interface"),
                NullBits(1),
                Bit(name="Abstract", comment="class is abstract"),
                Bit(name="Sealed", comment="class is concrete and may not be extended"),
                NullBits(1),
                Bit(name="SpecialName", comment="class name is special"),
                Bit(name="RTSpecialName", comment="Runtime should check name encoding"),
                Bit(name="Imported", comment="type/class is imported"),
                Bit(name="Serializable", comment="type/class is serializable"),
                NullBits(2),
                Bit(name="Unicode", comment="LPTSTR is interpreted as UNICODE"),
                Bit(name="Auto", comment="LPTSTR is interpreted automatically"),
                Bit(name="HasSecurity", comment="class has security associated with it"),
                NullBits(1),
                Bit(name="BeforeFieldInit", comment="initialize the class any time before first static field access"),
                Bit(name="Forwarder", comment="type is a forwarder"),
                NullBits(10),
                name="TypeAttributes", comment="type attributes")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="type name")
        yield self.analyzer.index_tables_net["#Strings"](name="TypeNamespace", comment="type namespace")
        yield self.analyzer.index_tables_net["TypeDefOrRef"](name="Extends", comment="TypeDefOrRef")
        yield self.analyzer.index_tables_net["Field"](name="FieldList", comment="index into Field table; it marks the first of a continuous run of fields owned by this type). The run continues to the smaller of 1-the last row of the Field table 2-the next run of Fields, found by inspecting the FieldList of the next row in this TypeDef table")
        yield self.analyzer.index_tables_net["MethodDef"](name="MethodList", comment="index into MethodDef table; it marks the first of a continuous run of methods owned by this type). The run continues to the smaller of 1-the last row of the MethodDef table 2-the next run of Methods, found by inspecting the MethodList of the next row in this TypeDef table")


class FieldPtr(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["Field"](name="Ref", comment="reference")


class Field(Struct):

    def parse(self):
        yield BitsField(
                Bit(name="Access1", comment="field visibility bits"),
                Bit(name="Access2", comment="field visibility bits"),
                Bit(name="Access3", comment="field visibility bits"),
                NullBits(1),
                Bit(name="Static", comment="field is static"),
                Bit(name="InitOnly", comment="may only be initialized, not written to after init"),
                Bit(name="Literal", comment="compile time constant"),
                Bit(name="NotSerialized", comment="does not have to be serialized when type is remoted"),
                Bit(name="HasRVA", comment="field has RVA"),
                Bit(name="SpecialName", comment="field is special, name describes how"),
                Bit(name="RTSpecialName", comment="Runtime(metadata internal APIs) should check name encoding"),
                NullBits(1),
                Bit(name="HasMarshal", comment="has FieldMarshal information"),
                NullBits(1),
                Bit(name="HasDefault", comment="has default"),
                name="FieldAttributes", comment="field attributes")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="field name, index into #Strings")
        yield self.analyzer.index_tables_net["#Blob"](name="Signature", comment="index into Blob heap")



class MethodDefPtr(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["MethodDef"](name="Ref", comment="reference")


class MethodDef(Struct):

    def parse(self):
        yield Rva(name="Rva", comment="method rva")
        yield BitsField(
                Bit(name="Native", comment="method is native"),
                Bit(name="OPTIL", comment="method is OPTIL"),
                Bit(name="Unmanaged", comment="method is unmanaged"),
                Bit(name="NoInlining", comment="may not be inlined"),
                Bit(name="ForwardRef", comment="method is defined; used primarily in merge scenarios"),
                Bit(name="Synchronized", comment="method is single threaded through the body"),
                NullBits(1),
                Bit(name="PreserveSig", comment="method sig is not to be mangled to do HRESULT conversion"),
                NullBits(4),
                Bit(name="InternalCall", comment="for internal use"),
                name="ImplFlags", comment="method implementation attributes")
        yield BitsField(
                Bit(name="Access1", comment="field visibility bits"),
                Bit(name="Access2", comment="field visibility bits"),
                Bit(name="Access3", comment="field visibility bits"),
                Bit(name="UnmanagedExport", comment="method exported via thunk to unmanaged code"),
                Bit(name="Static", comment="method is static"),
                Bit(name="Final", comment="may not be overridden"),
                Bit(name="Virtual", comment="method is virtual"),
                Bit(name="HideBySig", comment="method hides by name+sig"),
                Bit(name="NewSlot", comment="always gets a new slot in the vtable"),
                Bit(name="CheckAccessOnOverride", comment="Overridability is the same as the visibility"),
                Bit(name="Abstract", comment="does not provide an implementation"),
                Bit(name="SpecialName", comment="method is special, name describes how"),
                Bit(name="RTSpecialName", comment="Runtime(metadata internal APIs) should check name encoding"),
                Bit(name="PinvokeImpl", comment="implementation is forwarded through pinvoke"),
                Bit(name="HasSecurity", comment="has security associate with it"),
                Bit(name="RequireSecObject", comment="calls another method containing security code"),
                name="Flags", comment="method attributes")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="method name, index into #Strings")
        yield self.analyzer.index_tables_net["#Blob"](name="Signature", comment="index into Blob heap")
        yield self.analyzer.index_tables_net["Param"](name="ParamList", comment="index into the Param table. It marks the first of a contiguous run of Parameters owned by this method. The run continues to the smaller of 1-the last row of the Param table 2-the next run of Parameters, found by inspecting the ParamList of the next row in the MethodDef table")


class Param(Struct):

    def parse(self):
        yield BitsField(
                Bit(name="In", comment="input parameter"),
                Bit(name="Out", comment="output parameter"),
                NullBits(2),
                Bit(name="Optional", comment="optional parameter"),
                NullBits(7),
                Bit(name="HasDefault", comment="has default value"),
                Bit(name="HasMarshal", comment="has FieldMarshal infos"),
                name="Flags", comment="parameter attributes")
        yield UInt16(name="Sequence", comment="2-byte constant")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="parameter name, index into #Strings")


class ParamPtr(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["Param"](name="Ref", comment="reference")


class InterfaceImpl(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["TypeDef"](name="Class", comment="index into the TypeDef table")
        yield self.analyzer.index_tables_net["TypeDefOrRef"](name="Interface", comment="index into the TypeDef, TypeRef or TypeSpec table; more precisely, a TypeDefOrRef coded index")


class MemberRef(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["MemberRefParent"](name="Class", comment="index into the TypeRef, ModuleRef, MethodDef, TypeSpec, or TypeDef tables; more precisely, a MemberRefParent coded index")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="index into String heap")
        yield self.analyzer.index_tables_net["#Blob"](name="Signature", comment="index into Blob heap")


class Constant(Struct):

    def parse(self):
        yield UInt8(name="Type", comment="constant type")
        yield Unused(1)
        yield self.analyzer.index_tables_net["HasConstant"](name="Parent", comment="index into the Param or Field or Property table, more precisely, a HasConstant coded index")
        yield self.analyzer.index_tables_net["#Blob"](name="Value", comment="index into Blob heap")


class CustomAttribute(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["HasCustomAttribute"](name="Parent", comment="index into any metadata table, except the CustomAttribute table itself; more precisely, a HasCustomAttribute coded index")
        yield self.analyzer.index_tables_net["CustomAttributeType"](name="Type", comment="index into the MethodDef or MethodRef table; more precisely, a CustomAttributeType coded index")
        yield self.analyzer.index_tables_net["#Blob"](name="Value", comment="index into Blob heap")


class FieldMarshal(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["HasFieldMarshal"](name="Parent", comment="index into Field or Param table; more precisely, a HasFieldMarshal coded index")
        yield self.analyzer.index_tables_net["#Blob"](name="NativeType", comment="index into Blob heap")


class DeclSecurity(Struct):

    def parse(self):
        yield UInt16(name="Action", comment="")
        yield self.analyzer.index_tables_net["HasDeclSecurity"](name="Parent", comment="index into the TypeDef, MethodDef, or Assembly table; more precisely, a HasDeclSecurity coded index")
        yield self.analyzer.index_tables_net["#Blob"](name="PermissionSet", comment="index into Blob heap")


class ClassLayout(Struct):

    def parse(self):
        yield UInt16(name="PackingSize", comment="struct packing")
        yield UInt32(name="ClassSize", comment="struct size")
        yield self.analyzer.index_tables_net["TypeDef"](name="Parent", comment="index into TypeDef table")


class FieldLayout(Struct):

    def parse(self):
        yield UInt32(name="Offset", comment="field offset")
        yield self.analyzer.index_tables_net["Field"](name="Field", comment="index into Field table")


class StandAloneSig(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["#Blob"](name="Signature", comment="index into Blob heap")


class EventMap(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["TypeDef"](name="Parent", comment="index into TypeDef table")
        yield self.analyzer.index_tables_net["Event"](name="EventList", comment="index into Event table. It marks the first of a contiguous run of Events owned by this Type. The run continues to the smaller of 1- the last row of the Event table 2- the next run of Events, found by inspecting the EventList of the next row in the EventMap table")        

class EventPtr(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["Event"](name="Ref", comment="reference")        

class Event(Struct):

    def parse(self):
        yield BitsField(
                NullBits(9),
                Bit(name="SpecialName", comment="event is special. Name describes how"),
                Bit(name="RTSpecialName", comment="Runtime(metadata internal APIs) should check name encoding"),
                name="Flags", comment="event attributes")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="index into String heap")
        yield self.analyzer.index_tables_net["TypeDefOrRef"](name="EventType", comment="index into TypeDef, TypeRef, or TypeSpec tables; more precisely, a TypeDefOrRef coded index) [this corresponds to the Type of the Event; it is not the Type that owns this event]")


class PropertyMap(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["TypeDef"](name="Parent", comment="index into TypeDef table")
        yield self.analyzer.index_tables_net["Property"](name="PropertyList", comment="index into Property table. It marks the first of a contiguous run of Property owned by this Type. The run continues to the smaller of 1- the last row of the Property table 2- the next run of Properties, found by inspecting the EventList of the next row in the PropertyMap table")  


class PropertyPtr(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["Property"](name="Ref", comment="reference")        


class Property(Struct):

    def parse(self):
        yield BitsField(
                NullBits(9),
                Bit(name="SpecialName", comment="event is special. Name describes how"),
                Bit(name="RTSpecialName", comment="Runtime(metadata internal APIs) should check name encoding"),
                Bit(name="HasDefault", comment="property has default"),
                name="Flags", comment="property attributes")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="index into String heap")
        yield self.analyzer.index_tables_net["#Blob"](name="Type", comment="index into Blob heap. The name of this column is misleading. It does not index a TypeDef or TypeRef table instead it indexes the signature in the Blob heap of the Property")


class MethodSemantics(Struct):

    def parse(self):
        yield BitsField(
                Bit(name="Setter", comment="setter for property"),
                Bit(name="Getter", comment="getter for property"),
                Bit(name="Other", comment="other method for property or event"),
                Bit(name="AddOn", comment="AddOn method for event"),
                Bit(name="RemoveOn", comment="RemoveOn method for event"),
                Bit(name="Fire", comment="Fire method for event"),
                NullBits(10),
                name="Semantics", comment="method semantics")
        yield self.analyzer.index_tables_net["MethodDef"](name="Method", comment="index into the MethodDef table")
        yield self.analyzer.index_tables_net["HasSemantics"](name="Association", comment="index into the Event or Property table, more precisely, a HasSemantics coded index")


class MethodImpl(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["TypeDef"](name="Class", comment="index into the TypeDef table")
        yield self.analyzer.index_tables_net["MethodDefOrRef"](name="MethodBody", comment="index into MethodDef or MemberRef table, more precisely, a MethodDefOrRef coded index")
        yield self.analyzer.index_tables_net["MethodDefOrRef"](name="MethodDeclaration", comment="index into MethodDef or MemberRef table, more precisely, a MethodDefOrRef coded index")


class ModuleRef(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="index into String heap")


class TypeSpec(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["#Blob"](name="SpecSignature", comment="index into Blob heap")


class ImplMap(Struct):

    def parse(self):
        yield UInt16(name="Flags")  #TODO
        yield self.analyzer.index_tables_net["MemberForwarded"](name="Member", comment="index into the Field or MethodDef table; more precisely, a MemberForwarded coded index. However, it only ever indexes the MethodDef table, since Field export is not supported")
        yield self.analyzer.index_tables_net["#Strings"](name="ImportName", comment="import name")
        yield self.analyzer.index_tables_net["ModuleRef"](name="ImportScope", comment="scope")



class FieldRVA(Struct):

    def parse(self):
        yield Rva(name="Rva", comment="rva pointing to field's initial value")  
        yield self.analyzer.index_tables_net["Field"](name="Field", comment="scope")


class EncLog(Struct):

    def parse(self):
        yield UInt32(name="Token")
        yield UInt32(name="FuncCode")


class EncMap(Struct):

    def parse(self):
        yield UInt32(name="Token")


class Assembly(Struct):

    def parse(self):
        yield UInt32(name="HashAlgId", comment="a 4-byte constant of type AssemblyHashAlgorithm")  
        yield UInt16(name="MajorVersion")
        yield UInt16(name="MinorVersion")
        yield UInt16(name="BuildNumber")
        yield UInt16(name="RevisionNumber")
        yield UInt32(name="Flags")  #TODO
        yield self.analyzer.index_tables_net["#Blob"](name="PublicKey", comment="index into Blob heap")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="index into String heap")
        yield self.analyzer.index_tables_net["#Strings"](name="Culture", comment="index into String heap")


class AssemblyProcessor(Struct):

    def parse(self):
        yield UInt32(name="Processor", comment="a 4-byte constant")


class AssemblyOS(Struct):

    def parse(self):
        yield UInt32(name="OSPlatformID", comment="a 4-byte constant")                 
        yield UInt32(name="OSMajorVersion", comment="a 4-byte constant")                 
        yield UInt32(name="OSMinorVersion", comment="a 4-byte constant")                 


class AssemblyRef(Struct):

    def parse(self):
        yield UInt16(name="MajorVersion")
        yield UInt16(name="MinorVersion")
        yield UInt16(name="BuildNumber")
        yield UInt16(name="RevisionNumber")
        yield UInt32(name="Flags")  #TODO
        yield self.analyzer.index_tables_net["#Blob"](name="PublicKeyOrToken", comment="index into Blob heap – the public key or token that identifies the author of this Assembly")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="index into String heap")
        yield self.analyzer.index_tables_net["#Strings"](name="Culture", comment="index into String heap")
        yield self.analyzer.index_tables_net["#Blob"](name="HashValue", comment="index into Blob heap")


class AssemblyRefProcessor(Struct):

    def parse(self):
        yield UInt32(name="Processor", comment="constant")
        yield self.analyzer.index_tables_net["AssemblyRef"](name="Assembly", comment="index into the AssemblyRef table")


class AssemblyRefOS(Struct):

    def parse(self):
        yield UInt32(name="OSPlateformId")
        yield UInt32(name="OSMajorVersion")
        yield UInt32(name="OSMinorVersion")
        yield self.analyzer.index_tables_net["AssemblyRef"](name="Assembly", comment="index into the AssemblyRef table")


class File(Struct):

    def parse(self):
        yield BitsField(
                Bit(name="NoMetadata", comment="is a resource file or other non-metadata-containing file"),
                NullBits(31),
                name="Flags", comment="file attributes")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="index into String heap")
        yield self.analyzer.index_tables_net["#Blob"](name="HashValue", comment="index into Blob heap")


class ExportedType(Struct):

    def parse(self):
        yield BitsField(
                Bit(name="Public"),
                Bit(name="Nested"),
                Bit(name="Family"),
                Bit(name="SequentialLayout", comment="class fields are laid out sequentially"),
                Bit(name="ExplicitLayout", comment="class layout is supplied explicitly"),
                Bit(name="Interface", comment="type is an interface"),
                NullBits(1),
                Bit(name="Abstract", comment="class is abstract"),
                Bit(name="Sealed", comment="class is concrete and may not be extended"),
                NullBits(1),
                Bit(name="SpecialName", comment="class name is special"),
                Bit(name="RTSpecialName", comment="Runtime should check name encoding"),
                Bit(name="Imported", comment="type/class is imported"),
                Bit(name="Serializable", comment="type/class is serializable"),
                NullBits(2),
                Bit(name="Unicode", comment="LPTSTR is interpreted as UNICODE"),
                Bit(name="Auto", comment="LPTSTR is interpreted automatically"),
                Bit(name="HasSecurity", comment="class has security associated with it"),
                NullBits(1),
                Bit(name="BeforeFieldInit", comment="initialize the class any time before first static field access"),
                Bit(name="Forwarder", comment="type is a forwarder"),
                NullBits(10),
                name="TypeAttributes", comment="type attributes")
        yield UInt32(name="TypeDefId", comment="(4-byte index into a TypeDef table of another module in this Assembly). This field is used as a hint only. If the entry in the target TypeDef table matches the TypeName and TypeNamespace entries in this table, resolution has succeeded. But if there is a mismatch, the CLI shall fall back to a search of the target TypeDef table")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="type name")
        yield self.analyzer.index_tables_net["#Strings"](name="TypeNamespace", comment="type namespace")
        yield self.analyzer.index_tables_net["Implementation"](name="Implementation", comment="implementation")


class ManifestResource(Struct):

    def parse(self):
        off_rsrc = self.analyzer.rva2off(self.analyzer["CLR.Header"]["Resources"]["Rva"]) or 0
        yield Offset32(name="Offset", base=off_rsrc, comment="offset of resource")
        yield BitsField(
                Bit(name="Public", comment="resource is exported"),
                Bit(name="Private", comment="resource is private"),
                NullBits(30),
                name="Flags", comment="resource attributes")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="index into String heap")
        yield self.analyzer.index_tables_net["Implementation"](name="Implementation", comment="implementation")


class NestedClass(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["TypeDef"](name="NestedClass", comment="index into the TypeDef table")
        yield self.analyzer.index_tables_net["TypeDef"](name="EnclosingClass", comment="index into the TypeDef table of the enclosing class")


class GenericParam(Struct):

    def parse(self):
        yield UInt16(name="Number", comment="the 2-byte index of the generic parameter, numbered left-to-right, from zero")
        yield BitsField(
                Bit(name="Covariant"),
                Bit(name="Contravariant"),
                Bit(name="ReferenceType", comment="generic parameter has the class special constraint"),
                Bit(name="NotNullableValueType", comment="generic parameter has the valuetype special constraint"),
                Bit(name="DefaultConstructor", comment="generic parameter has the .ctor special constraint"),
                NullBits(11),
                name="Flags")
        yield self.analyzer.index_tables_net["TypeOrMethodDef"](name="Owner", comment="index into the TypeDef or MethodDef table, specifying the Type or Method to which this generic parameter applies")
        yield self.analyzer.index_tables_net["#Strings"](name="Name", comment="parameter name")
        

class MethodSpec(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["MethodDefOrRef"](name="Method", comment="index into the MethodDef or MemberRef table, specifying to which generic method this row refers; that is, which generic method this row is an instantiation of")
        yield self.analyzer.index_tables_net["#Blob"](name="Instantiation", comment="index into Blob heap holding the signature of this instantiation")


class GenericParamConstraint(Struct):

    def parse(self):
        yield self.analyzer.index_tables_net["GenericParam"](name="Owner", comment="index into the GenericParam table, specifying to which generic parameter this row refers")
        yield self.analyzer.index_tables_net["TypeDefOrRef"](name="Constraint", comment="index into the TypeDef, TypeRef, or TypeSpec tables, specifying from which class this generic parameter is constrained to derive; or which interface this generic parameter is constrained to implement")


class MethodHeader(Struct):

    def parse(self):
        d, = struct.unpack("<B", self.look_ahead(1))
        if (d & 3) == 3:
            # fat header
            f = yield BitsField(
                Bit(name="FatHeader", comment="should be one"),
                Bit(name="MethodHeader", comment="should be one"),
                NullBits(1),
                Bit(name="HasExtraSections", comment="sections follow after the method body"),
                Bit(name="InitLocals", comment="call default constructor on all local variables"),
                name="Flags", comment="Method Flags")
            hs = yield UInt8(name="FlagsAndHeaderSize", comment="should be 0x30")
            if hs != 0x30:
                raise FatalError("Invalid FlagsAndHeaderSize value")
            yield UInt16(name="MaxStack", comment="maximum number of items on the operand stack")
            cs = yield UInt32(name="CodeSize", comment="size in byte of the method body")
            yield UInt32(name="LocalVarSigTok", comment="metadata token for a signature describing the layout of the local variables for the method. 0 means there are no local variables present. This field references a stand-alone signature in the MetaData tables, which references an entry in the #Blob stream")
        elif (d & 3) == 2:
            # tiny header
            val = yield UInt8(name="FlagsAndCodeSize", comment="the high 6 bits are the code size, the two low bits should be 10 (2)")
        else:
            raise FatalError


class MethodExtraSection(Struct):

    def parse(self):
        typ = yield BitsField(
                Bit(name="ExceptionHandlingData", comment="should be one"),
                Bit(name="OptILTable", comment="reserved, should be 0"),
                NullBits(4),
                Bit(name="FatSection", comment="sections uses fat format"),
                Bit(name="MoreSections", comment="another data section occurs after this current section"),
                name="Flags", comment="MethodSection Flags")
        if typ["FatSection"]:
            ds = yield UInt24(name="DataSize", comment="size of section")
        else:
            ds = yield UInt8(name="DataSize", comment="size of section")
            yield UInt16(name="Padding", comment="should be 0")
        todo = ds - len(self)
        if todo <= 0:
            raise FatalError("Invalid section size")
        if typ["ExceptionHandlingData"]:
            if typ["FatSection"]:
                yield Array(todo // 24, MethodExceptionDataFat(), name="Clauses", comment="exception clauses")
            else:
                yield Array(todo // 12, MethodExceptionDataSmall(), name="Clauses", comment="exception clauses")
        else:
            raise FatalError("unsupported extra section type")


class MethodExceptionDataSmall(Struct):

    def parse(self):
        flags = yield UInt16(name="Flags", comment="type", values=[
            ("Exception", 0x0),
            ("Filter", 0x1),
            ("Finally", 0x2),
            ("Fault", 0x4),
            ])
        yield UInt16(name="TryOffset", comment="offset in bytes of try block from the start of the header")
        yield UInt8(name="TryLength", comment="length in bytes of the try block")
        yield UInt16(name="HandlerOffset", comment="Location of the handler for this try block")
        yield UInt8(name="HandlerLength", comment="size of the handler code in bytes")
        yield UInt32(name="FilterOffsetOrClassToken", comment="offset in method body for filter-based exception handler or metadata token of exception class for exception entry")


class MethodExceptionDataFat(Struct):

    def parse(self):
        flags = yield UInt32(name="Flags", comment="type", values=[
            ("Exception", 0x0),
            ("Filter", 0x1),
            ("Finally", 0x2),
            ("Fault", 0x4),
            ])
        yield UInt32(name="TryOffset", comment="offset in bytes of try block from the start of the header")
        yield UInt32(name="TryLength", comment="length in bytes of the try block")
        yield UInt32(name="HandlerOffset", comment="Location of the handler for this try block")
        yield UInt32(name="HandlerLength", comment="size of the handler code in bytes")
        yield UInt32(name="FilterOffsetOrClassToken", comment="offset in method body for filter-based exception handler or metadata token of exception class")



class CompiledResourceHeader(Struct):

    def parse(self):
        yield UInt32(name="Signature", comment="should be 0xBEEFCACE")
        yield UInt32(name="NumberOfReaderTypes", comment="")        
        sz = yield UInt32(name="SizeOfReaderTypes", comment="")        
        yield String(sz, zero_terminated=False, name="ReaderTypes")
        yield UInt32(name="Version", comment="either 1 or 2")        
        numres = yield UInt32(name="NumberOfResources", comment="number of actual resources in the entry")
        numtypes = yield UInt32(name="NumberOfResourcesTypes", comment="number of different resources typesmm")
        for i in range(numtypes):
            sizelen, size = get_var_int(self.analyzer)
            if sizelen == 1:
                t = UInt8
            elif sizelen == 2:
                t = UInt16
            else:
                t = UInt32
            yield t(name="Type[{}].size".format(i), comment="varint")
            yield String(size, zero_terminated=False,  name="Type[{}]".format(i))
        modulo = len(self) % 8
        if modulo:
            yield Unused(8 - modulo)
        if numres:
            yield Array(numres, UInt32(), name="ResourcesHash", comment="hash of resources")
            yield Array(numres, Offset32(base=self.offset + len(self) + 4 * numres + 4), name="ResourcesInfos", comment="infos on the resource (name + offset)")
        yield Offset32(name="DataSection", base=self.offset)
         


def get_composed_row(value, index_name, pe):
    table_bits, table_map = COMPOSED_INDEXES[index_name]
    p2tb = pow(2, table_bits)
    table = value & (p2tb - 1)
    index = value // p2tb
    table_name = None
    for name, bit in table_map.items():
        if bit == table:
            table_name = name + "Table"
            break
    if table_name is None or not table_name in pe:
        raise FatalError("Unknown table {}".format(table_name))
    if index == 0:
        return None
    index -= 1
    if index >= pe[table_name].count:
        raise FatalError("invalid index {} for table {}: {:x} ({})".format(index, table_name, value, index_name))
    return pe[table_name][index]


def get_var_int(pe, off=None):
    if off is None:
        off = pe.tell()
    first, = struct.unpack("<B", pe.read(off, 1))
    if (first & 0xC0) == 0xC0:
        x, = struct.unpack("<B", pe.read(off + 1, 1))
        y, = struct.unpack("<B", pe.read(off + 2, 1))
        z, = struct.unpack("<B", pe.read(off + 3, 1))
        return 4, ((first & 0x1F) << 24) + (x << 16) + (y << 8) + z
    elif (first & 0x80) != 0:
        x, = struct.unpack("<B", pe.read(off + 1, 1))
        return 2, ((first & 0x3F) << 8) + x
    else:
        return 1, first & 0x7f

def get_string(index, pe):
    if pe.stream_strings_offset is None:
        raise FatalError("No #Strings stream")
    if index > pe.stream_strings_size:
        raise FatalError("Invalid #Strings index {} vs {}".format(index, pe.stream_strings_size))
    return pe.read_cstring_utf8(pe.stream_strings_offset + index, pe.stream_strings_size - index)

def parse_net(pe):
    pe.metadata["DotNet"] = OrderedDict()
    dd = pe["OptionalHeader"]["DataDirectory"]
    if dd.count < 15 or dd[14]["Rva"] == 0 or dd[14]["Size"] != 0x48:
        return
    off = pe.rva2off(dd[14]["Rva"])
    if not off or off >= pe.size():
        raise FatalError("CLR header not in file")
    pe.jump(off)
    clihdr = yield CLIHeader(name="CLR.Header", category=Type.HEADER)
    meta_off = pe.rva2off(clihdr["Metadata"]["Rva"])
    if not meta_off or meta_off >= pe.size():
        raise FatalError("Metadata header not in file")
    pe.jump(meta_off)
    mh = yield MetadataHeader(name="CLR.Metadata", category=Type.HEADER)
    # build streams index
    streams = {}
    pe.streams_net = {} 
    for i in range(mh["NumberOfStreams"]):
        stream_header = mh["StreamHeader[{}]".format(i)]
        foff = meta_off + stream_header["Offset"]
        name = stream_header["Name"]
        if not name in streams:
            # some obfuscator put duplicated stream names to fool parsers
            streams[name] = stream_header

    # parse #~ stream
    hdr = streams.get("#~", None)
    if hdr is None:
        hdr = streams.get("#-", None)
        if hdr is None:
            raise FatalError("Stream #~ missing")
    pe.jump(meta_off + hdr["Offset"])
    th = yield TablesHeader(name="#~", category=Type.HEADER)

    
    # tag other streams
    for k, hdr in streams.items():
        if k not in ("#~", "#-"):
            pe.jump(meta_off + hdr["Offset"])
            yield Bytes(hdr["Size"], name=hdr["Name"], category=Type.HEADER)
            pe.streams_net[hdr["Name"]] = (pe.tell(), hdr["Size"])
    pe.stream_blob_offset = 0
    pe.stream_blob_size = 0
    if "#Blob" in pe:
        pe.stream_blob_offset = pe.at("#Blob").offset
        pe.stream_blob_size = pe.at("#Blob").size
    pe.stream_strings_offset = 0
    pe.stream_strings_size = 0
    if "#Strings" in pe:
        pe.stream_strings_offset = pe.at("#Strings").offset
        pe.stream_strings_size = pe.at("#Strings").size

    # compute index sizes
    pe.index_tables_net = {}
    for k,v in TABLES_NAMES.items(): 
        fn = "{}Items".format(v)
        if fn in th:
            pe.index_tables_net[v] = th[fn] > 0xFFFF and UInt32 or UInt16
        else:
            pe.index_tables_net[v] = UInt16
    pe.index_tables_net["#Strings"] = pe["#~"]["HeapOffsetSizes"]["HugeStringStream"] and (lambda **kwargs: Offset32(base=pe.stream_strings_offset, hint=StringUtf8(0, True), zero_is_invalid=True, **kwargs)) or (lambda **kwargs: Offset16(base=pe.stream_strings_offset, hint=StringUtf8(0, True), zero_is_invalid=True, **kwargs))
    pe.index_tables_net["#GUID"] = pe["#~"]["HeapOffsetSizes"]["HugeGuidStream"] and (lambda **kwargs: Offset32(base=pe.at("#GUID").offset - 1, hint=GUID(), zero_is_invalid=True, **kwargs)) or (lambda **kwargs: Offset16(base=pe.at("#GUID").offset - 1, hint=GUID(), zero_is_invalid=True, **kwargs))
    pe.index_tables_net["#Blob"] = pe["#~"]["HeapOffsetSizes"]["HugeBlobStream"] and (lambda **kwargs: Offset32(base= pe.stream_blob_offset, zero_is_invalid=True, **kwargs)) or (lambda **kwargs: Offset16(base=pe.stream_blob_offset, zero_is_invalid=True, **kwargs))
    for name, el in COMPOSED_INDEXES.items():
        tag_bits, tables = el    #math.floor(math.log2(len(tables)))
        max_size = int(math.pow(2, 16-tag_bits))
        word = True
        for t in tables:
            ttn = "{}Items".format(t)
            if ttn in th and th[ttn] > max_size:
                word = False
        pe.index_tables_net[name] = word and UInt16 or UInt32
    

    pe.jump(th.offset + th.size)
    # tables ...
    for table_name in TABLES_NAMES.values():
        nbitemname = "{}Items".format(table_name)
        if nbitemname in th:
            if table_name in globals():
                yield Array(th[nbitemname], globals()[table_name](), parent=th, name="{}Table".format(table_name), category=Type.HEADER)
            else:
                raise KeyError("Unknown table {}".format(table_name))

    # metadata
    if pe["ModuleTable"].count:
        main_module = pe["ModuleTable"][0]
        pe.metadata["DotNet"]["Module name"] = get_string(main_module["Name"], pe)
    pe.architecture = bindings.FileType.DOTNET

    # resources
    try:
        pe.resources_net = {}
        if "ManifestResourceTable" in pe:
            rsrc_rva = clihdr["Resources"]["Rva"]
            rsrc_off = pe.rva2off(rsrc_rva)
            if rsrc_off is None:
                raise ParsingError("Invalid resource RVA")
            mrt = pe["ManifestResourceTable"]
            for rsrc in mrt:
                off = rsrc["Offset"] + rsrc_off
                rva = rsrc["Offset"] + rsrc_rva
                rsrc_size, = struct.unpack("<I", pe.read(off, 4))
                rsrc_name = toprintable(get_string(rsrc["Name"], pe))
                pe.jump(off + 4)
                if rsrc_size >= 4 and pe.read(off + 4, 4) == b"\xce\xca\xef\xbe":
                    # metadata rsrc
                    data_section_base = pe.tell()
                    data_section_base_rva = rva + 4
                    hdr = yield CompiledResourceHeader(name=rsrc_name, category=Type.HEADER, parent=mrt)
                    data_section = hdr["DataSection"]
                    infos_base = pe.tell()
                    subrsrces = []
                    if hdr["NumberOfResources"] == 0:
                        continue
                    for i in range(hdr["NumberOfResources"]):
                        subrsrc_off = infos_base + hdr["ResourcesInfos"][i]
                        pe.jump(subrsrc_off)
                        size, = struct.unpack("<B", pe.read(pe.tell(), 1))
                        subrsrc_name = toprintable(pe.read_cstring_utf16le(pe.tell() + 1, max_bytes=size))
                        subrsrc_start = data_section_base + data_section + struct.unpack("<I", pe.read(pe.tell() + 1 + size, 4))[0]
                        # TODO: how to properly get size of resource ?!?
                        subrsrc_size = None
                        subrsrces.append((subrsrc_start, subrsrc_name, subrsrc_size))
                    subrsrces = sorted(subrsrces, key=lambda x: x[0])
                    # heuristic for rsrc sizes
                    for i in range(len(subrsrces) - 1):
                        subrsrc_start, subrsrc_name, subrsrc_size = subrsrces[i]
                        if not subrsrc_size:
                            subrsrc_size = subrsrces[i+1][0] - subrsrc_start
                            subrsrces[i] = (subrsrc_start, subrsrc_name, subrsrc_size)
                    subrsrc_start, subrsrc_name, subrsrc_size = subrsrces[-1]
                    if not subrsrc_size:
                        subrsrc_size = 4 + off + rsrc_size - subrsrc_start
                        subrsrces[-1] = (subrsrc_start, subrsrc_name, subrsrc_size)
                    # parse resources
                    for subrsrc_start, subrsrc_name, subrsrc_size in subrsrces:
                        if not subrsrc_size:
                            continue
                        pe.jump(subrsrc_start)
                        rsrc_fullname = "{}/{}".format(rsrc_name, subrsrc_name)
                        dnr = yield DotnetResource(subrsrc_size, name=rsrc_fullname, parent=hdr, category=Type.RESOURCE)
                        pe.resources_net[rsrc_fullname] = Resource("", subrsrc_name, "", dnr.Data.offset + data_section_base_rva - data_section_base, dnr.Data.size)
                else:
                    pe.resources_net[rsrc_name] = Resource("", rsrc_name, "", rva + 4, rsrc_size)
                    yield Bytes(rsrc_size, name=rsrc_name, category=Type.RESOURCE, parent=mrt)
    except ParsingError: 
        import traceback
        traceback.print_exc()
        pass
    for k, v in pe.resources_net.items():
        pe.files.append(bindings.VirtualFile("/".join([".NET", k]), v.size, "open_rsrc_net"))

    # methods
    if "MethodDefTable" in pe:
        mdt = pe["MethodDefTable"]
        if "EntryPointToken" in clihdr:
            eptoken = clihdr["EntryPointToken"]
        else:
            eptoken = None
        for i, mdef in enumerate(mdt):
            section = pe.rva2region(mdef["Rva"])
            mstart = pe.rva2off(mdef["Rva"])
            if not mstart:
                continue
            pe.jump(mstart)
            #name = get_string(mdef["Name"], pe)
            #if not name:
            #    continue
            try:
                mh = yield MethodHeader(name="MethodHeader", parent=mdt, category=Type.HEADER)
                if eptoken == 0x06000000 | i + 1:
                    # this is the real EP
                    pe.symbols.append(bindings.FileSymbol(
                        pe.imagebase + mdef["Rva"] + mh.size,
                        bindings.FileSymbol.ENTRY, "DotNetEntryPoint"))
                if "Flags" in mh and mh["Flags"]["HasExtraSections"] and "CodeSize" in mh:
                    pe.jump(align(pe.tell() + mh["CodeSize"], 4))
                    mes = yield MethodExtraSection(name="MethodFooter", parent=mdt, category=Type.HEADER)
            except ParsingError:
                continue

    def resolve_symbol_name(sym, pe):
        if sym is None:
            return "?"
        if "SpecSignature" in sym:
            # TypeSpec
            delta = sym["SpecSignature"]
            if delta >= pe.stream_blob_offset:
                raise FatalError("Signature out of bound")
            off = pe.stream_blob_offset + delta
            left = pe.stream_blob_size - delta
            if left > 3:
                prefix = pe.read(off, 3)
                if prefix[1] == 0x15 and (prefix[2] == 0x11 or prefix[2] == 0x12):
                    # resolve GENERICINST TypeSpec
                    sz, value = get_var_int(pe, off + 3)
                    parent = get_composed_row(value, "TypeDefOrRef", pe)
                    base_type = resolve_symbol_name(parent, pe)
                    templates = []
                    if base_type:
                        off += sz + 3
                        sz, gen_args_count = get_var_int(pe, off)
                        off += sz
                        keep = False
                        for i in range(min(gen_args_count, 16)):
                            if not keep:
                                t = ""
                            keep = False
                            prefix = pe.read(off, 1)[0]
                            off += 1
                            if prefix in ELEMENT_TYPE:
                                t = ELEMENT_TYPE[prefix]
                            elif prefix == 0xf:
                                t = "*" + t
                                keep = True
                            elif prefix == 0x10:
                                t = "&" + t
                                keep = True
                            elif prefix == 0x11 or prefix == 0x12:
                                sz, value = get_var_int(pe, off)
                                off += sz
                                typ = get_composed_row(value, "TypeDefOrRef", pe)
                                t = resolve_symbol_name(typ, pe) + t
                            elif prefix == 0x13:
                                sz, value = get_var_int(pe, off)
                                t = "Gen{:d}".format(value) + t
                                off += sz
                            elif prefix == 0x1d:
                                t = "[]" + t
                            else: 
                                break
                            if not keep:
                                templates.append(t)
                    return "{}<{}>".format(base_type, ",".join(templates))

        if not "Name" in sym:
            return ""
        r = get_string(sym["Name"], pe)
        if "TypeNamespace" in sym:
            # TypeRef
            ns = get_string(sym["TypeNamespace"], pe)
            if ns:
                r = "{}.{}".format(ns, r)
            elif "Scope" in sym:
                parent = get_composed_row(sym["Scope"], "ResolutionScope", pe)
                parent_name = resolve_symbol_name(parent, pe)
                if parent_name:
                    r = "{}.{}".format(parent_name, r)
        if "Class" in sym:
            # MemberRef
            parent = get_composed_row(sym["Class"], "MemberRefParent", pe)
            parent_name = resolve_symbol_name(parent, pe)
            if parent_name:
                r = "{}.{}".format(parent_name, r)
        return r

    # native imports
    if "ImplMapTable" in pe and "MethodDefTable" in pe:
        mdt = pe["MethodDefTable"]
        for im in pe["ImplMapTable"]:
            access = get_composed_row(im["Member"], "MemberForwarded", pe)
            if not access:
                continue
            symname = get_string(im["ImportName"], pe)
            pe.symbols.append(bindings.FileSymbol(
                        pe.off2va(access.offset),
                        bindings.FileSymbol.IMPORT,
                        symname))


    # imports
    if "MemberRefTable" in pe:
        for mref in pe["MemberRefTable"]:
            pe.symbols.append(bindings.FileSymbol(
                        pe.off2va(mref.offset),
                        bindings.FileSymbol.IMPORT,
                        resolve_symbol_name(mref, pe)))
