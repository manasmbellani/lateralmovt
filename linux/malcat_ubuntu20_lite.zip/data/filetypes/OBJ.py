from filetypes.base import *
import bindings
import struct
from collections import OrderedDict
from filetypes.PE import Section

CV_SIGNATURE_C6  = 0  # Actual signature is >64K
CV_SIGNATURE_C7  = 1  # First explicit signature
CV_SIGNATURE_C11 = 2  # C11 (vc5.x) 32-bit types
CV_SIGNATURE_C13 = 4  # C13 (vc7.x) zero terminated names

class COFF(Struct):
    def parse(self):
        yield UInt16(name="Machine", comment="supported architecture")
        yield UInt16(name="NumberOfSections", comment="number of sections")
        yield Timestamp(name="TimeDateStamp", comment="file creation time")
        yield Offset32(name="PointerToSymbolTable", comment="pointer to symbol table")
        yield UInt32(name="NumberOfSymbols", comment="number of symbols")
        yield UInt16(name="SizeOfOptionalHeader", comment="size of optional header")
        yield UInt16(name="Characteristics", comment="file characteristics")


class SymbolTable(Struct):

    def __init__(self, nument, **args):
        Struct.__init__(self, **args)
        self.nument = nument

    def parse(self):
        sz = self.nument * 18
        string_table = self.offset + sz
        while len(self) < sz:
            se = yield SymbolEntry(string_table, name="Symbol")
            numaux = se["NumAux"]
            for i in range(numaux):
                if len(self) < sz:
                    yield Bytes(numaux*18, name="Symbol.AuxData", comment="auxilliary data")


class StringTable(Struct):

    def parse(self):
        sz = yield UInt32(name="Size", comment="string table size")
        if sz > 4:
            yield Bytes(sz - 4, name="Strings", comment="strings")




class SymbolEntry(Struct):
    def __init__(self, string_table, **kwargs):
        Struct.__init__(self, **kwargs)
        self.string_table = string_table

    def parse(self):
        if self.look_ahead(4) == b"\x00\x00\x00\x00":
            yield Unused(4, name="Zero")
            yield Offset32(name="NameOffset", base=self.string_table, hint=String(0, zero_terminated=True), comment="offset of symbol name inside string table")
        else:
            yield String(8, name="Name", comment="symbol name")
        yield UInt32(name="Value", comment="value of symbol, type-dependant")
        yield Int16(name="SectionNumber", comment="section number this symbol belongs to. could also be 0 (pubic symbol), -1 (absolute symbol) or -2 (debug symbol")
        yield UInt16(name="Type", comment="symbol type")
        yield UInt8(name="StorageClass", comment="tells where and what the symbol represents")
        numaux = yield UInt8(name="NumAux", comment="how many equivalent SYMENTs are used for aux entries")



class CVSymbolStream13(Struct):
    def __init__(self, size, **kwargs):
        Struct.__init__(self, **kwargs)
        self.maxsize = size

    def parse(self):
        subtype = yield UInt32(name="SubSectionType", comment="type of subsection")
        if subtype != 0xF1:
            raise FatalError("Invalid subsection type: {:x}".format(subtype))
        todo = yield UInt32(name="SubsectionSize", comment="size of subsection")
        if todo != 0:
            sz = min(self.maxsize - len(self), todo)
        else:
            sz = self.maxsize - len(self)
        yield Bytes(todo, name="Symbols", comment="symbols data")
        #while analyzer.tell() + 4 <= end:
        #    size, type = struct.unpack("<HH", analyzer.read(analyzer.tell(), 4))
        #    struc = RECORD_TYPE_TO_STRUCT.get(type, CVSymbolRecord)
        #    yield struc(name="Symbol")
        if todo % 4:
            yield Unused(4 - (todo % 4), name="Padding")


class CVUnknownStream13(Struct):
    def __init__(self, size, **kwargs):
        Struct.__init__(self, **kwargs)
        self.maxsize = size

    def parse(self):
        subtype = yield UInt32(name="SubSectionType", comment="type of subsection")
        todo = yield UInt32(name="SubsectionSize", comment="size of subsection")
        if todo != 0:
            sz = min(self.maxsize - len(self), todo)
        else:
            sz = self.maxsize - len(self)
        yield Bytes(sz, name="StreamData")
        if todo % 4:
            yield Unused(4 - (todo % 4), name="Padding")


class CoffRelocation(Struct):

    def parse(self):
        yield Va32(name="VirtualAddress", comment="address of the relocation")
        yield UInt32(name="SymbolTableIndex", comment="zero-based index into the symbol table. this symbol gives the address that is to be used for the relocation")
        yield UInt16(name="Type", comment="indicates the kind of relocation that should be performed")


    

        


class OBJAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.PROGRAM
    name = "OBJ"
    regexp = r"(?:\x64\x86|\x4c\x01|\x13\x0c).............\x00\x00\x00\x00\x00"

    def __init__(self):
        FileTypeAnalyzer.__init__(self)

   
    def parse(self, hint):
        coff = yield COFF(category=Type.HEADER)
        if coff["Machine"] == 0x8664:
            self.architecture = bindings.FileType.X64
        else:
            self.architecture = bindings.FileType.X86
        sections = yield Array(coff["NumberOfSections"], Section(), name="Sections", category=Type.HEADER)
        if len(sections) < 1 or len(sections) > 10000:
            raise FatalError("Invalid number of sections") 
        for s in sections:
            if s["PointerToRawData"] > self.remaining():
                raise FatalError("section {} lies outside of file range".format(s["Name"]))
            sname = s["Name"]
            si = sname.find("\x00")
            if si >= 0:
                sname = sname[:si]
            psize = (s["SizeOfRawData"] + 10*s["NumberOfRelocations"] + 6*s["NumberOfLinenumbers"]) & 0xFFFFFFFF
            self.sections.append(bindings.Section(s["PointerToRawData"], psize,
                s["PointerToRawData"], psize,
                sname,
                s["Characteristics"]["MemRead"],
                s["Characteristics"]["MemWrite"],
                s["Characteristics"]["MemExecute"],
                s["Characteristics"]["MemDiscardable"],
                )
            )
        
        # symbols
        machine = coff["Machine"]
        numsyms = coff["NumberOfSymbols"]
        syms = coff["PointerToSymbolTable"]
        string_table = syms + numsyms * 18
        symtable = None
        if syms and numsyms:
            self.jump(syms)
            symtable = yield SymbolTable(numsyms, category=Type.DEBUG)
        yield StringTable(category=Type.DEBUG)

        # symbols
        if symtable is not None:
            for s in symtable:
                if type(s) == bytes:
                    continue
                if not "Value" in s or s["Type"] != 0x20 or s["SectionNumber"] <= 0:
                    continue
                if "Name" in s:
                    name = s["Name"]
                else:
                    name = self.read_cstring_ascii(string_table + s["NameOffset"], 512)
                section = sections[s["SectionNumber"] - 1]
                self.symbols.append(bindings.FileSymbol(section["PointerToRawData"] + s["Value"], bindings.FileSymbol.EXPORT, name))

        for s in sections:
            if s["PointerToRawData"] > self.size() or s["PointerToLinenumbers"] > self.size():
                raise FatalError
            if s["PointerToRelocations"] and s["NumberOfRelocations"]:
                self.jump(s["PointerToRelocations"])
                relocs = yield Array(s["NumberOfRelocations"], CoffRelocation(), name="{}.Relocations".format(s["Name"].replace("\0","")), category=Type.FIXUP)
                reloc_base = s["PointerToRawData"] + s["VirtualAddress"]
                for reloc in relocs:
                    rtype = reloc["Type"]
                    if symtable is not None and (
                            rtype in (0x4, 0x6, 0x14)):
                        rindex = reloc["SymbolTableIndex"]
                        if rindex >= len(symtable):
                            raise FatalError("{} > {} for {:x}".format(rindex, len(symtable), reloc.address))
                        symentry = symtable[rindex]
                        if "Name" in symentry:
                            name = symentry["Name"]
                        else:
                            name = self.read_cstring_ascii(string_table + symentry["NameOffset"], 512)
                        self.symbols.append(bindings.FileSymbol(reloc_base + reloc["VirtualAddress"], bindings.FileSymbol.IMPORT, name))

            if s["Name"] == ".debug$S" and s["SizeOfRawData"] > 12:
                self.jump(s["PointerToRawData"])
                end = self.tell() + s["SizeOfRawData"]
                sig = yield UInt32(name="Signature", comment="cvres version", category=Type.HEADER)
                if sig == CV_SIGNATURE_C13:
                    # msvc 13
                    while self.tell() + 4 < end:
                        subtype, = struct.unpack("<I", self.read(self.tell(), 4))
                        if subtype == 0xF1:
                           yield CVSymbolStream13(end - self.tell(), name="SymbolStream", category=Type.DEBUG)
                        else:
                            yield CVUnknownStream13(end - self.tell(), name="Stream_{:2X}".format(subtype), category=Type.DEBUG)
