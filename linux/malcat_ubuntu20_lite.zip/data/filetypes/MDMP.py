from filetypes.base import *
import bindings
import collections
import datetime
from filetypes.PE import FixedFileInfo

# https://github.com/libyal/libmdmp/blob/master/documentation/Minidump%20(MDMP)%20format.asciidoc

class FileHeader(Struct):

    def parse(self):
        yield String(4, name="Signature")
        yield UInt16(name="FormatVersion", comment="format version (MINIDUMP_VERSION)")
        yield UInt16(name="ImplementationVersion", comment="implementation specific version")
        yield UInt32(name="NumberOfStreams", comment="number of streams")
        yield Offset32(name="StreamsDirectory", comment="streams directory RVA")
        yield UInt32(name="Checksum", comment="")
        yield Timestamp(name="TimeDateStamp", comment="dump creation time")
        yield BitsField(
            Bit(name="WithDataSegs", comment="include the data sections from all loaded modules"),
            Bit(name="WithFullMemory", comment="include all accessible memory in the process"),
            Bit(name="WithHandleData", comment="include high-level information about the operating system handles that are active when the minidump is made"),
            Bit(name="FilterMemory", comment="stack and backing store memory written to the minidump file should be filtered to remove all but the pointer values necessary to reconstruct a stack trace"),
            Bit(name="ScanMemory", comment="stack and backing store memory should be scanned for pointer references to modules in the module list. If a module is referenced by stack or backing store memory, the ModuleWriteFlags member of the MINIDUMP_CALLBACK_OUTPUT structure is set to ModuleReferencedByMemory"),
            Bit(name="WithUnloadedModules", comment="include information from the list of modules that were recently unloaded, if this information is maintained by the operating system"),
            Bit(name="WithIndirectlyReferencedMemory", comment="include pages with data referenced by locals or other stack memory"),
            Bit(name="FilterModulePaths", comment="filter module paths for information such as user names or important directories. This option may prevent the system from locating the image file and should be used only in special situations"),
            Bit(name="WithProcessThreadData", comment="include complete per-process and per-thread information from the operating system"),
            Bit(name="WithPrivateReadWriteMemory", comment="scan the virtual address space for PAGE_READWRITE memory to be included"),
            Bit(name="WithoutOptionalData", comment="reduce the data that is dumped by eliminating memory regions that are not essential to meet criteria specified for the dump"),
            Bit(name="WithFullMemoryInfo", comment="include memory region information"),
            Bit(name="WithThreadInfo", comment="include thread state information"),
            Bit(name="WithCodeSegs", comment="include all code and code-related sections from loaded modules to capture executable content"),
            Bit(name="WithoutAuxiliaryState", comment="turns off secondary auxiliary-supported memory gathering"),
            Bit(name="WithFullAuxiliaryState", comment="requests that auxiliary data providers include their state in the dump image"),
            Bit(name="WithPrivateWriteCopyMemory", comment="scans the virtual address space for PAGE_WRITECOPY memory to be included"),
            Bit(name="IgnoreInaccessibleMemory", comment="if you specify MiniDumpWithFullMemory, the MiniDumpWriteDump function will fail if the function cannot read the memory regions; however, if you include MiniDumpIgnoreInaccessibleMemory, the MiniDumpWriteDump function will ignore the memory read failures and continue to generate the dump"),
            Bit(name="WithTokenInformation", comment="adds security token related data"),
            Bit(name="WithModuleHeaders", comment="adds module header related data"),
            Bit(name="WithFilterTriage", comment="adds filter triage related data"),
            NullBits(64-21),
            name="FileFlags", comment="minidump flags")


class LocationDescriptor(Struct):

    def parse(self):
        yield UInt32(name="DataSize", comment="size of data")
        yield Offset32(name="DataRva", comment="rva of data")


class MinidumpDirectory(Struct):

    def parse(self):
        yield UInt32(name="StreamType", values=[
            ("UnusedStream", 0),
            ("ReservedStream0", 1),
            ("ReservedStream1", 2),
            ("ThreadListStream", 3),
            ("ModuleListStream", 4),
            ("MemoryListStream", 5),
            ("ExceptionStream", 6),
            ("SystemInfoStream", 7),
            ("ThreadExListStream", 8),
            ("Memory64ListStream", 9),
            ("CommentStreamA", 10),
            ("CommentStreamW", 11),
            ("HandleDataStream", 12),
            ("FunctionTableStream", 13),
            ("UnloadedModuleListStream", 14),
            ("MiscInfoStream", 15),
            ("MemoryInfoListStream", 16),
            ("ThreadInfoListStream", 17),
            ("HandleOperationListStream", 18),
            ("TokenStream", 19),
            ])
        yield LocationDescriptor(name="Location", comment="location of stream")


class Module(Struct):

    def parse(self):
        yield Va64(name="BaseOfImage", comment="base address of the module executable image in memory")
        yield UInt32(name="SizeOfImage", comment="size of the module executable image in memory, in bytes")
        yield UInt32(name="Checksum", comment="checksum value of the module executable image")
        yield Timestamp(name="TimeDateStamp", comment="timestamp value of the module executable image")
        yield Offset32(name="ModuleName", hint=StringUtf16le(0, zero_terminated=True), base=4, comment="RVA to a MINIDUMP_STRING structure that specifies the name of the module")
        yield FixedFileInfo(name="FileInformation", comment="VS_FIXEDFILEINFO structure that specifies the version of the module")
        yield LocationDescriptor(name="CvRecord", comment="CodeView record of the module")
        yield LocationDescriptor(name="MiscRecord", comment="miscellaneous  record of the module")
        yield UInt64(name="Reserved0", comment="")
        yield UInt64(name="Reserved1", comment="")


class ModuleList(Struct):

    def parse(self):
        num = yield UInt32(name="NumberOfModules")
        yield Array(num, Module(), name="Modules")





class MemoryList(Struct):

    def parse(self):
        num = yield UInt32(name="NumberOfMemoryRanges")
        yield Array(num, MemoryRange(), name="Ranges")     

class MemoryRange(Struct):

    def parse(self):
        yield Va64(name="StartOfMemoryRange", comment="virtual address of memory block")
        yield UInt32(name="DataSize")             
        yield Offset32(name="DataRva")             


SUPPORTED_DIRECTORIES = {
        "ModuleListStream": ModuleList,
        "MemoryListStream": MemoryList,
}


class MiniDumpAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.PROGRAM
    name = "Minidump"
    regexp = r"MDMP\x93\xA7"

    
    def parse(self, hint):
        fh = yield FileHeader(category=Type.HEADER)
        self.metadata["Creation time"] = fh["TimeDateStamp"].strftime("%Y-%m-%d %H:%M:%S")
        self.jump(fh["StreamsDirectory"])
        d = yield Array(fh["NumberOfStreams"], MinidumpDirectory(), name="MinidumpDirectory", category=Type.HEADER)
        for entry in d:
            typ = SUPPORTED_DIRECTORIES.get(entry.StreamType.enum, None)
            if typ is not None:
                self.jump(entry["Location"]["DataRva"])
                yield typ( category=Type.HEADER)

            if entry["Location"]["DataSize"]:
                self.sections.append(bindings.Section(entry["Location"]["DataRva"], entry["Location"]["DataSize"],
                        entry["Location"]["DataRva"], entry["Location"]["DataSize"],
                        entry.StreamType.enum.replace("Stream", ""),
                        True)
                )
