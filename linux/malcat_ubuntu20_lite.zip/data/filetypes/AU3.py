from filetypes.base import *
import bindings
import struct
from struct import unpack_from
import os

# from https://github.com/nazywam/AutoIt-Ripper
def bytes_to_bitstring(data: bytes) -> str:
    return "".join(bin(x)[2:].zfill(8) for x in data)


class BitStream:
    def __init__(self, data: bytes) -> None:
        self.data = bytes_to_bitstring(data)
        self.ptr = 0

    def get_bits(self, num: int) -> int:
        if self.ptr + num > len(self.data):
            raise KeyError
        out = int(self.data[self.ptr:self.ptr+num], 2)
        self.ptr += num
        return out



def au3_decompress(data):
    _, uncomp_size = struct.unpack(">II", data[:8])
    if uncomp_size > 100000000:
        raise ValueError("script too big to be decompressed")
    bin_data = BitStream(data[8:])
    out_data = bytearray(uncomp_size)   # small performance hack
    cur_output = 0
    while cur_output < uncomp_size:
        addme = 0
        # version changes...
        if bin_data.get_bits(1):
            out_data[cur_output] = bin_data.get_bits(8)
            cur_output += 1
        else:
            bb = bin_data.get_bits(15)
            bs = bin_data.get_bits(2)
            if bs == 3:
                addme = 3
                bs = bin_data.get_bits(3)
                if bs == 7:
                    addme = 10
                    bs = bin_data.get_bits(5)
                    if bs == 31:
                        addme = 41
                        bs = bin_data.get_bits(8)
                        if bs == 255:
                            addme = 296
                            while True:
                                bs = bin_data.get_bits(8)
                                if bs != 255:
                                    break
                                addme += 255
            bs += 3 + addme
            i = cur_output - bb
            while bs > 0 and cur_output < uncomp_size:
                out_data[cur_output] = out_data[i]
                cur_output += 1
                i += 1
                bs -= 1
    return out_data


def blob(data):
    off = 0
    var = data[off]
    out = ""

    if var == 0x33:
        out = "$"
    elif var == 0x36:
        out = '"'
    elif var == 0x30:
        pass
    elif var == 0x32:
        out = "@"
    elif var == 0x34:
        pass
    elif var == 0x35:
        pass
    off += 1

    key = unpack_from("<H", data[off:])[0]
    off += 2 + 2

    dec = [0] * (key * 2)
    for i in range(key):
        d = unpack_from("<H", data[off:])[0]
        d ^= key
        dec[i * 2 + 0] = d & 0xFF
        dec[i * 2 + 1] = (d >> 8) & 0xFF
        off += 2

    out += bytes(dec).decode("utf-16")
    if var == 0x36:
        out += '" '
    elif var == 0x33 and data[off] == 0x35:
        out += "."
    else:
        out += " "
    return (out, off)


OPCODES = {
    0x05: lambda x: (str(unpack_from("<I", x)[0]) + " ", 1 + 4),
    0x10: lambda x: (str(unpack_from("<Q", x)[0]) + " ", 1 + 8),
    0x20: lambda x: (str(unpack_from("<d", x)[0]) + " ", 1 + 8),
    0x30: blob,
    0x31: blob,
    0x32: blob,
    0x33: blob,
    0x34: blob,
    0x35: blob,
    0x36: blob,
    0x37: blob,
    0x38: blob,
    0x39: blob,
    0x3A: blob,
    0x3B: blob,
    0x3C: blob,
    0x3D: blob,
    0x3E: blob,
    0x3F: blob,
    0x40: lambda x: (", ", 1),
    0x41: lambda x: ("= ", 1),
    0x42: lambda x: ("> ", 1),
    0x43: lambda x: ("< ", 1),
    0x44: lambda x: ("<> ", 1),
    0x45: lambda x: (">= ", 1),
    0x46: lambda x: ("<= ", 1),
    0x47: lambda x: ("( ", 1),
    0x48: lambda x: (") ", 1),
    0x49: lambda x: ("+ ", 1),
    0x4A: lambda x: ("- ", 1),
    0x4B: lambda x: ("/ ", 1),
    0x4C: lambda x: ("* ", 1),
    0x4D: lambda x: ("& ", 1),
    0x4E: lambda x: ("[ ", 1),
    0x4F: lambda x: ("] ", 1),
    0x50: lambda x: ("== ", 1),
    0x51: lambda x: ("^ ", 1),
    0x52: lambda x: ("+= ", 1),
    0x53: lambda x: ("-= ", 1),
    0x54: lambda x: ("/= ", 1),
    0x55: lambda x: ("*= ", 1),
    0x56: lambda x: ("&= ", 1),
    0x57: lambda x: ("? ", 1),
    0x58: lambda x: (": ", 1),
}


# based on https://github.com/dzzie/myaut_contrib
class RanRot:

    def __init__(self, seed):
        self.randbuffer = []
        for i in range(17):
            seed = (seed * 2891336453 + 1) & 0xFFFFFFFF
            self.randbuffer.append(seed)
        self.p1 = 0
        self.p2 = 10
        for i in range(9):
            self.random()

    def random(self):
        def lrotl(n, d):
            return ((n << d) & 0xFFFFFFFF) | (n >> (32 - d))
        x = (lrotl(self.randbuffer[self.p2], 13) + lrotl(self.randbuffer[self.p1], 9)) & 0xFFFFFFFF
        self.randbuffer[self.p1] = x
        if self.p1:
            self.p1 = self.p1 - 1
        else:
            self.p1 = 16
        if self.p2:
            self.p2 = self.p2 - 1
        else:
            self.p2 = 16
        x = ((x << 20 ) & 0xFFFFFFFF) | ((x >> 12) | 0x3FF00000) << 32
        x = struct.unpack("<d", struct.pack("<Q", x))[0] - 1.0
        return x

    def random8(self):
        self.random()
        return min(255, int(self.random() * 256))


def au3_decrypt(data, rr_seed, fmt=None):
    rr = RanRot(rr_seed)
    if fmt is not None:
        data = struct.pack(fmt, data)
    res = bytearray(data)
    for i in range(len(res)):
        r8 = rr.random8()
        res[i] = res[i] ^ r8
    if fmt is not None:
        res, = struct.unpack(fmt, res)
    return res


class Au3FileHeader(Struct):

    def parse(self):
        yield Bytes(16, name="Password", comment="password md5 (encrypted")
        restype_crypted = yield Bytes(4, name="ResType", comment="resource type (encrypted)")
        restype = au3_decrypt(restype_crypted, 0x18ee)
        if restype != b"FILE":
            raise FatalError("Invalid resource type: {}".format(restype))
        prolog_len = yield UInt32Xor(0xADBC, name="PrologLen", comment="len of prolog string")
        prolog = yield Bytes(prolog_len*2, name="Prolog", comment="script prolog (encrypted)")
        prolog = au3_decrypt(prolog, 0xb33f + prolog_len).decode("utf-16-le", errors="ignore")
        path_len = yield UInt32Xor(0xF820, name="PathLen", comment="len of compiled path string")
        if path_len:
            path = yield Bytes(path_len*2, name="Path", comment="script path (encrypted)")
            path = au3_decrypt(path, 0xf479 + path_len).decode("utf-16-le", errors="ignore")
        compressed = yield UInt8(name="IsCompressed", comment="is the script compressed ?")
        script_size_compressed = yield UInt32Xor(0x87BC, name="CompressedSize", comment="len of compressed script")
        script_size = yield UInt32Xor(0x87BC, name="UncompressedSize", comment="len of uncompressed script")
        yield UInt32Xor(0xa685, name="Crc32", comment="crc32 of plain-text script")
        if script_size_compressed:
            yield UInt32(name="CreationTimeHigh")
            yield UInt32(name="CreationTimeLow")
            yield UInt32(name="ModificationTimeHigh")
            yield UInt32(name="ModificationTimeLow")




class AutoItAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.ARCHIVE
    name = "AU3"
    regexp = r"\xA3\x48\x4B\xBE\x98\x6C\x4A\xA9\x99\x4C\x53\x0A\x86\xD6\x48\x7DAU3!"

    def __init__(self, *args, **kwargs):
        FileTypeAnalyzer.__init__(self, *args, **kwargs)
        self.filesystem = {}

    def unpack(self, vfile):
        if vfile.size == 0:
            return b"EMPTY FILE"
        return self.unpack_file(self.filesystem[vfile.path])
       

    def unpack_file(self, hdr):
        data = self.read(hdr.offset + hdr.size, hdr["CompressedSize"])
        decrypted = au3_decrypt(data, 0x2477)
        if decrypted[:4] != b"EA06":
            raise ValueError("Not a valid AU3.3+ script")
        if hdr["IsCompressed"] == 0:
            return decrypted
        return au3_decompress(decrypted)


    def parse(self, hint):
        yield Bytes(24, name="Magic", category=Type.HEADER)
        first = True
        while True:
            data = self.read(self.tell(), 24)
            if data == b"\x44\x07\xA6\x48\x48\x58\xCC\x8F\x74\x95\xA2\x82\xAF\x86\x68\xB0\x41\x55\x33\x21\x45\x41\x30\x36":
                yield Bytes(24, name="MagicEnd", category=Type.HEADER)
                break
            else:
                hdr = yield Au3FileHeader(category=Type.HEADER)
                self.confirm()
                sz = hdr["CompressedSize"] - 16 # pwd len
                if sz > 0:
                    self.sections.append(bindings.Section(
                        hdr.offset, sz + hdr.size,
                        hdr.offset, sz + hdr.size,
                        "file{:d}".format(len(self.sections)),
                        True
                    ))
                    name = au3_decrypt(hdr["Path"], 0xf479 + hdr["PathLen"]).decode("utf-16-le", errors="ignore")
                    self.filesystem[name] = hdr
                    ftype = ""
                    if name.endswith(".tok") or name.endswith(".tmp"):
                        ftype = "AU3.Tokens"
                    self.files.append(bindings.VirtualFile(name, hdr["UncompressedSize"], "unpack", ftype))
                    if hdr["CompressedSize"]:
                        yield Bytes(sz, name="File", category=Type.DATA)
                    first = False




class TokensHeader(Struct):

    def parse(self):
        yield UInt32(name="NumberOfLines")





class AutoItTokensAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.PROGRAM
    name = "AU3.Tokens"

    def __init__(self, *args, **kwargs):
        FileTypeAnalyzer.__init__(self, *args, **kwargs)
        self.decompiled = ""

    def decompile(self):
        if not self.decompiled:
            res = []
            data = self.read(0, self.size())
            ptr = self.tell()
            curline = 0
            numlines = self["Header"]["NumberOfLines"]
            while curline < numlines:
                opcode = data[ptr]
                if opcode in OPCODES:
                    add, off = OPCODES[opcode](data[ptr:])
                elif opcode == 0x7F:
                    curline += 1
                    add, off = "\r\n", 0 + 1
                elif opcode <= 0x0F:
                    add, off = "", 4 + 1
                elif opcode <= 0x1F:
                    add, off = "", 8 + 1
                elif opcode <= 0x2F:
                    add, off = "", 8 + 1
                else:
                    add, off = "", 0 + 1
                res.append(add)
                ptr += off
            self.decompiled = "".join(res)
        return self.decompiled

    def parse(self, hint):
        hdr = yield TokensHeader(name="Header")
        
                

