from filetypes.base import *
import bindings
import struct
import io
import zipfile
from collections import OrderedDict




class LocalFile(Struct):

    def parse(self):
        yield UInt32(name="Signature")
        yield UInt16(name="VersionNeeded", comment="ZIP version needed to extract (0x14 = 20 = 2.0)")
        flags = yield BitsField(
            Bit(name="EncryptedFile"),
            Bit(name="CompressionOption"),
            Bit(name="CompressionOption"),
            Bit(name="DataDescriptor"),
            Bit(name="EnhancedDeflation"),
            Bit(name="CompressedPatchedData"),
            Bit(name="StrongEncrpytion"),
            NullBits(4),
            Bit(name="LanguageEncoding"),
            NullBits(1),
            Bit(name="MaskHeaderValues"),
            name="Flags")
        yield UInt16(name="CompressionMethod", values=[
            ("no compression", 0),
            ("shrunk", 1),
            ("reduced with compression factor 1", 2),
            ("reduced with compression factor 2", 3),
            ("reduced with compression factor 3", 4),
            ("reduced with compression factor 4", 5),
            ("imploded", 6),
            ("reserved", 7),
            ("deflated", 8),
            ("enhanced deflated", 9),
            ("PKWare DCL imploded", 10),
            ("reserved", 11),
            ("compressed using BZIP2", 12),
            ("reserved", 13),
            ("LZMA", 14),
            ("17: reserved", 15),
            ("compressed using IBM TERSE", 18),
            ("IBM LZ77 z", 19),
            ("PPMd version I, Rev 1", 98),
            ])
        yield DosDateTime(name="ModificationTime", comment="stored in standard MS-DOS format")
        yield UInt32(name="Crc32", comment="value computed over file data by CRC-32 algorithm with 'magic number' 0xdebb20e3 (little endian)")
        yield UInt32(name="CompressedSize", comment="if archive is in ZIP64 format, this filed is 0xffffffff and the length is stored in the extra field")
        yield UInt32(name="UncompressedSize", comment="if archive is in ZIP64 format, this filed is 0xffffffff and the length is stored in the extra field")
        fnl = yield UInt16(name="FileNameLen", comment="the length of the file name field below")
        efl = yield UInt16(name="ExtraFieldLen", comment="the length of the extra field below")
        if fnl:
            if flags["LanguageEncoding"]:
                sc = StringUtf8
            else:
                sc = String
            yield sc(fnl, name="FileName", zero_terminated=False, comment="the name of the file including an optional relative path. All slashes in the path should be forward slashes '/'")
        start = len(self)
        while len(self) - start + 4 <= efl:
            tag, = struct.unpack("<H", self.look_ahead(2))
            field_class = EXTRA_FIELDS.get(tag, ExtraField)
            yield field_class(name=field_class.__name__)
        if len(self) - start < efl:
            yield Bytes(efl - (len(self) - start), name="ExtraDataRaw", comment="unparsed extra data")


class ExtraField(Struct):

    def parse(self):       
        yield UInt16(name="FieldId")
        sz = yield UInt16(name="FieldSize")
        yield Bytes(sz, name="FieldData")


class Zip64ExtraField(Struct):

    def parse(self):       
        yield UInt16(name="FieldId")
        sz = yield UInt16(name="FieldSize")
        yield UInt64(name="UncompressedSize")
        if sz > 8:
            yield UInt64(name="CompressedSize")
        if sz > 16:
            yield UInt64(name="RelativeHeaderOffset")
        if sz > 24:
            yield UInt32(name="DiskStart")


class UnixExtraFieldNew(Struct):

    def parse(self):       
        yield UInt16(name="FieldId")
        sz = yield UInt16(name="FieldSize")
        if sz >= 2:
            yield UInt16(name="UID")
        if sz >= 4:
            yield UInt16(name="GID")


class UnixExtraFieldOld(Struct):

    def parse(self):       
        yield UInt16(name="FieldId")
        sz = yield UInt16(name="FieldSize")
        yield Timestamp(name="LastAccess")
        yield Timestamp(name="LastModification")        
        if sz > 8:
            yield UInt16(name="UID")
            yield UInt16(name="GID")


EXTRA_FIELDS = {
    1: Zip64ExtraField,
    0x5855: UnixExtraFieldOld,
    0x7855: UnixExtraFieldNew,
}

class DataDescriptor(Struct):

    def parse(self):           
        yield UInt32(name="Crc32")
        yield UInt32(name="CompressedSize")
        yield UInt32(name="UncompressedSize")


class DataDescriptorBlock(Struct):

    def parse(self):
        yield UInt32(name="Signature")
        yield UInt32(name="Crc32")
        yield UInt32(name="CompressedSize")
        yield UInt32(name="UncompressedSize")


class CentralDirectory(Struct):

    def parse(self):
        yield UInt32(name="Signature")
        yield UInt8(name="Version", comment="Version made by")
        yield UInt8(name="OperatingSystem", comment="OS type", values=[
            ("FAT filesystem (MS-DOS, OS/2, NT/Win32)", 0x00),
            ("Amiga", 0x01),
            ("VMS (or OpenVMS)", 0x02),
            ("Unix", 0x03),
            ("VM/CMS", 0x04),
            ("Atari TOS", 0x05),
            ("HPFS filesystem (OS/2, NT)", 0x06),
            ("Macintosh", 0x07),
            ("Z-System", 0x08),
            ("CP/M", 0x09),
            ("Windows NTFS", 0x0a),
            ("MVS (OS/390 - Z/OS)", 0x0b),
            ("VSE", 0x0c),
            ("Acorn RISCOS", 0x0d),
            ("VFAT", 0x0e),
            ("alternate MVS", 0x0f),
            ("BeOS", 0x10),
            ("Tandem", 0x11),
            ("OS/400", 0x12),
            ("OS/X (Darwin)", 0x13),
            ("unknown", 0xff),
            ])
        yield UInt16(name="VersionNeeded", comment="ZIP version needed to extract (0x14 = 20 = 2.0)")
        flags = yield BitsField(
            Bit(name="EncryptedFile"),
            Bit(name="CompressionOption"),
            Bit(name="CompressionOption"),
            Bit(name="DataDescriptor"),
            Bit(name="EnhancedDeflation"),
            Bit(name="CompressedPatchedData"),
            Bit(name="StrongEncrpytion"),
            NullBits(4),
            Bit(name="LanguageEncoding"),
            NullBits(1),
            Bit(name="MaskHeaderValues"),
            name="Flags")
        yield UInt16(name="CompressionMethod", values=[
            ("no compression", 0),
            ("shrunk", 1),
            ("reduced with compression factor 1", 2),
            ("reduced with compression factor 2", 3),
            ("reduced with compression factor 3", 4),
            ("reduced with compression factor 4", 5),
            ("imploded", 6),
            ("reserved", 7),
            ("deflated", 8),
            ("enhanced deflated", 9),
            ("PKWare DCL imploded", 10),
            ("reserved", 11),
            ("compressed using BZIP2", 12),
            ("reserved", 13),
            ("LZMA", 14),
            ("17: reserved", 15),
            ("compressed using IBM TERSE", 18),
            ("IBM LZ77 z", 19),
            ("PPMd version I, Rev 1", 98),
            ])
        yield DosDateTime(name="ModificationTime", comment="stored in standard MS-DOS format")
        yield UInt32(name="Crc32", comment="value computed over file data by CRC-32 algorithm with 'magic number' 0xdebb20e3 (little endian)")
        yield UInt32(name="CompressedSize", comment="if archive is in ZIP64 format, this filed is 0xffffffff and the length is stored in the extra field")
        yield UInt32(name="UncompressedSize", comment="if archive is in ZIP64 format, this filed is 0xffffffff and the length is stored in the extra field")
        fnl = yield UInt16(name="FileNameLen", comment="the length of the file name field below")
        efl = yield UInt16(name="ExtraFieldLen", comment="the length of the extra field below")
        coml = yield UInt16(name="CommentLen", comment="the length of the comment field below")
        yield UInt16(name="DiskStart", comment="number of the disk on which this file exists")
        yield BitsField(
            Bit(name="AsciiFile"),
            NullBits(1),
            Bit(name="ControlFieldBeforeLogical"),
            NullBits(13),
            name="InternalAttributes")
        yield UInt32(name="ExternalAttributes", comment="host-system dependent")
        yield Offset32(name="LocalFileOffset", comment="offset of where to find the corresponding local file header from the start of the first disk")
        if fnl:
            if flags["LanguageEncoding"]:
                sc = StringUtf8
            else:
                sc = String
            yield sc(fnl, name="FileName", zero_terminated=False, comment="the name of the file including an optional relative path. All slashes in the path should be forward slashes '/'")
        start = len(self)
        while len(self) - start + 3 < efl:
            tag, = struct.unpack("<H", self.look_ahead(2))
            field_class = EXTRA_FIELDS.get(tag, ExtraField)
            yield field_class(name=field_class.__name__)
        if coml:
            yield String(coml, name="Comment", zero_terminated=False, comment="optional comment for the file")


class EndOfCentralDirectory(Struct):

    def parse(self):
        yield UInt32(name="Signature")
        yield UInt16(name="DiskNumber", comment="number of this disk (containing the end of central directory record)")
        yield UInt16(name="DiskStart", comment="number of the disk on which the central directory starts")
        yield UInt16(name="DiskEntries", comment="number of central directory entries on this disk")
        yield UInt16(name="TotalEntries", comment="number of entries in the central directory")
        yield UInt32(name="CentralDirectorySize", comment="size of the central directory")
        yield Offset32(name="CentralDirectoryStartOffset", comment="offset of the start of the central directory on the disk on which the central directory starts")
        coml = yield UInt16(name="CommentLen", comment="the length of the comment field below")
        if coml:
            yield String(coml, name="Comment", zero_terminated=False, comment="optional comment for the archive")

class EndOfCentralDirectoryLocator64(Struct):

    def parse(self):
        yield UInt32(name="Signature")
        yield UInt32(name="DiskStart", comment="number of the disk on which the central directory starts")
        yield Offset64(name="CentralDirectoryStartOffset", comment="offset of the start of the central directory on the disk on which the central directory starts")
        yield UInt32(name="TotalDisk", comment="total number of disks")

class EndOfCentralDirectory64(Struct):

    def parse(self):
        yield UInt32(name="Signature")
        sz = yield UInt64(name="Size", comment="size of zip64 end of central directory record")
        start = len(self)
        yield UInt8(name="Version", comment="Version made by")
        yield UInt8(name="OperatingSystem", comment="OS type", values=[
            ("FAT filesystem (MS-DOS, OS/2, NT/Win32)", 0x00),
            ("Amiga", 0x01),
            ("VMS (or OpenVMS)", 0x02),
            ("Unix", 0x03),
            ("VM/CMS", 0x04),
            ("Atari TOS", 0x05),
            ("HPFS filesystem (OS/2, NT)", 0x06),
            ("Macintosh", 0x07),
            ("Z-System", 0x08),
            ("CP/M", 0x09),
            ("Windows NTFS", 0x0a),
            ("MVS (OS/390 - Z/OS)", 0x0b),
            ("VSE", 0x0c),
            ("Acorn RISCOS", 0x0d),
            ("VFAT", 0x0e),
            ("alternate MVS", 0x0f),
            ("BeOS", 0x10),
            ("Tandem", 0x11),
            ("OS/400", 0x12),
            ("OS/X (Darwin)", 0x13),
            ("unknown", 0xff),
            ])
        yield UInt16(name="VersionNeeded", comment="ZIP version needed to extract (0x14 = 20 = 2.0)")
        yield UInt32(name="DiskNumber", comment="number of this disk (containing the end of central directory record)")
        yield UInt32(name="DiskStart", comment="number of the disk on which the central directory starts")
        yield UInt64(name="DiskEntries", comment="number of central directory entries on this disk")
        yield UInt64(name="TotalEntries", comment="number of entries in the central directory")
        yield UInt64(name="CentralDirectorySize", comment="size of the central directory")
        yield Offset64(name="CentralDirectoryStartOffset", comment="offset of the start of the central directory on the disk on which the central directory starts")
        done = len(self) - start
        if done < sz:
            yield Bytes(sz - done, name="ExtensibleData")


class ZipAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.ARCHIVE
    name = "ZIP"
    regexp = r"PK\x03\x04"

    def __init__(self):
        FileTypeAnalyzer.__init__(self)
        self.size = 0

    @classmethod
    def start_of_file(cls, curfile, offset_magic, parent_filetype):
        if parent_filetype is not None and parent_filetype.name == "ZIP":
            # no ZIP in ZIP 
            return None
        return offset_magic

    def open(self, vfile):
        if not self.size:
            raise FatalError("Invalid zip file")
        mybuf = io.BytesIO(self.read(0, self.size))
        with zipfile.ZipFile(mybuf, "r") as myzip:
            zinfo = myzip.getinfo(vfile.path)
            if not zinfo:
                raise ValueError("Could not get infos for file {}".format(vfile.path))
            pwdlist = [None]
            if zinfo.flag_bits & 0x1 :
                # encrypted
                pwdlist = [b"infected", b"virus", b"malware"]
            for pwd in pwdlist:
                try:
                     return myzip.read(vfile.path, pwd)
                except RuntimeError:
                    pass
        raise ValueError("Could not extract ZIP file '{}' using any of these passwords: {}".format(vfile.path, " or ".join(map(str, pwdlist))))


    def parse(self, hint):
        num_local_files = 0
        num_central_directory = 0
        files_seen = set()
        central_directory_start = None
        while self.remaining() > 4:
            start = self.tell()
            tag = self.read(start, 4)
            if tag == b"PK\x03\x04":
                if central_directory_start:
                    raise FatalError("Central directory started")
                lfh = yield LocalFile(category=Type.HEADER)
                compressed_size = lfh["CompressedSize"]
                if "Zip64ExtraField" in lfh and "CompressedSize" in lfh["Zip64ExtraField"]:
                    compressed_size = lfh["Zip64ExtraField"]["CompressedSize"]
                if lfh["Flags"]["DataDescriptor"]:
                    cur = self.tell()
                    # look for data descriptor sig
                    ddsig, ddsig_sz = self.search(r"PK\x07\x08", self.tell())
                    if ddsig_sz:
                        compressed_size = ddsig - cur
                if compressed_size > self.remaining():
                    break
                fn = ""
                if "FileName" in lfh:
                    fn = lfh["FileName"]
                if compressed_size:
                    yield Bytes(min(compressed_size, self.remaining()), name="Data", category=Type.DATA)
                #if lfh["Flags"]["DataDescriptor"]:
                #    dd = yield DataDescriptor(category=Type.HEADER)
                #    if compressed_size = dd["CompressedSize"]
                size = self.tell() - start
                self.sections.append(bindings.Section(start, size, start, size, fn, read=True))
                if fn and lfh["UncompressedSize"] and fn not in files_seen:
                    files_seen.add(fn)
                    self.files.append(bindings.VirtualFile(fn, lfh["UncompressedSize"], "open"))
                num_local_files += 1
                if num_local_files > 10:
                    self.confirm()
            elif tag == b"PK\x07\x08":
                if central_directory_start:
                    raise FatalError("Central directory started")
                yield DataDescriptorBlock(category=Type.HEADER)
            elif tag == b"PK\x01\x02":
                if central_directory_start is None:
                    central_directory_start = self.tell()
                cd = yield CentralDirectory(category=Type.HEADER)
                #if cd["Flags"]["DataDescriptor"]:
                #    yield DataDescriptor(category=Type.HEADER)
                fn = ""
                if "FileName" in cd:
                    fn = cd["FileName"]
                size = self.tell() - start
                if fn and cd["UncompressedSize"] and fn not in files_seen:
                    files_seen.add(fn)
                    self.files.append(bindings.VirtualFile(fn, cd["UncompressedSize"], "open"))
                num_central_directory += 1
            elif tag == b"PK\x06\x06":
                yield EndOfCentralDirectory64(category=Type.HEADER)
            elif tag == b"PK\x06\x07":
                yield EndOfCentralDirectoryLocator64(category=Type.HEADER)
            elif tag == b"PK\x05\x06":
                yield EndOfCentralDirectory(category=Type.HEADER)
                break
            else:
                off, sz = self.search(b"PK(?:\\x03\\x04|\\x07\\x08|\\x01\\x02|\\x06[\\x06\\x07]|\\x05\\x06)", start=self.tell())
                if sz:
                    yield Unused(off - self.tell(), name="UnusedSpace", category=Type.ANOMALY)
                    continue
                raise FatalError("Unknown tag {}".format(tag))
        if central_directory_start:
            cd_size = self.tell() - central_directory_start
            self.sections.append(bindings.Section(central_directory_start, cd_size, 
                central_directory_start, cd_size, 
                "<directory>",
                discard = True))

        if num_local_files == 0 or num_local_files != num_central_directory:
            raise FatalError("Incomplete ZIP file")
        self.size = self.tell()
            

