from filetypes.base import *
import bindings 
from collections import OrderedDict
import struct



class EmfRecord(Struct):

    def parse(self):
        type = yield UInt32(name="Type")
        size = yield UInt32(name="Size", comment="size of data")
        if size > 8:
            yield Bytes(size - 8, name="Data")

class HeaderRecord(Struct):

    def parse(self):
        type = yield UInt32(name="Type")
        size = yield UInt32(name="Size", comment="size of data")
        yield Rect(name="Bounds")
        yield Rect(name="Frame")
        yield String(4, zero_terminated=False, name="Signature")
        yield UInt16(name="VersionMinor")
        yield UInt16(name="VersionMajor")
        yield UInt32(name="FileSize")
        yield UInt32(name="Records")
        yield UInt16(name="Handles")
        yield UInt16(name="Reserved")
        yield UInt32(name="DescriptionSize")
        yield Offset32(name="DescriptionOffset")
        yield UInt32(name="PaletteEntries")
        yield Dimension(name="SurfaceSize")
        yield Dimension(name="SurfaceSizeMilli")
        yield UInt32(name="PixelFormatCount")
        yield Offset32(name="PixelFormatOffset")
        yield UInt32(name="OpenGL")
        yield Dimension(name="SurfaceSizeMicro")
        if len(self) < size:
            yield Bytes(size - len(self), name="Data")            


class ObjectRecord(Struct):

     def parse(self):
        start = self.analyzer.tell()
        type = yield UInt32(name="Type")
        size = yield UInt32(name="Size", comment="size of data")
        yield Rect(name="Bounds")
        yield Point(name="Destination")
        yield Rect(name="Source")
        yield Offset32(name="BmiHeaderOffset", base=start)
        yield UInt32(name="BmiHeaderSize")
        yield Offset32(name="BufferOffset", base=start)
        yield UInt32(name="BufferSize")
        yield UInt32(name="UsageSource")
        yield UInt32(name="RasterOperation")
        yield Point(name="cDestination")
        if len(self) < size:
            yield Bytes(size - len(self), name="Data")            


class CommentRecord(Struct):

     def parse(self):
        type = yield UInt32(name="Type")
        size = yield UInt32(name="Size", comment="size of data")
        yield UInt32(name="DataSize")
        sig = yield String(4, zero_terminated=False, name="Signature")
        if sig == "EMF+":
            while len(self) + 2 < size:
                tag, = struct.unpack("<H", self.look_ahead(2))
                cls = RECORDS_PLUS.get(tag, EmfPlusRecord)
                yield cls()
        if len(self) < size:
            yield Bytes(size - len(self), name="Data")            


class Point(Struct):

    def parse(self):
        yield UInt32(name="X")
        yield UInt32(name="Y")


class Dimension(Struct):

    def parse(self):
        yield UInt32(name="Width")
        yield UInt32(name="Height")        


class Rect(Struct):

    def parse(self):
        yield Point(name="TopLeft")
        yield Point(name="BottomRight")        




RECORDS = {
    1: (HeaderRecord, Type.HEADER),
    0x46: (CommentRecord, Type.DEBUG),
    0x51: (ObjectRecord, Type.DATA),
}
   

############################################### EMF+

class EmfPlusRecord(Struct):

    def parse(self):
        type = yield UInt16(name="Type")
        flags = yield UInt16(name="Flags")
        size = yield UInt32(name="Size", comment="size of data")
        if size > 8:
            yield Bytes(size - 8, name="Data")


class ObjectPlusImageRecord(Struct):

    def parse(self):
        yield UInt32(name="Version")
        tp = yield UInt32(name="Type", values = [
            ("BITMAP", 1),
            ("METAFILE", 2),
            ])
        if tp == 1:
            yield UInt32(name="Width")
            yield UInt32(name="Height")
            yield UInt32(name="Stride")
            yield UInt32(name="PixelFormat")
            yield UInt32(name="BitmapType", values = [
            ("PIXEL", 0),
            ("COMPRESSED", 1),
            ])

class ObjectPlusRecord(Struct):

    def parse(self):
        type = yield UInt16(name="Type")
        yield UInt8(name="ObjectId")
        object_type = yield UInt8(name="ObjectType", values = [
            ("BRUSH", 0x1),
            ("PEN", 0x2),
            ("PATH", 0x3),
            ("REGION", 0x4),
            ("IMAGE", 0x5),
            ("FONT", 0x6),
            ("STRING_FORMAT", 0x7),
            ("IMAGE_ATTRIBUTES", 0x8),
            ("CUSTOM_LINE_CAP", 0x9),
            ("BRUSH", 0x81),
            ("PEN", 0x82),
            ("PATH", 0x83),
            ("REGION", 0x84),
            ("IMAGE", 0x85),
            ("FONT", 0x86),
            ("STRING_FORMAT", 0x87),
            ("IMAGE_ATTRIBUTES", 0x88),            
            ("CUSTOM_LINE_CAP", 0x89),
            ])
        size = yield UInt32(name="Size", comment="size of data")
        if object_type & 0x80:
            yield UInt32(name="TotalSize", comment="Once TotalObjectSize number of bytes has been read, the next EMF+ record will not be treated as part of the continuing object")
        size = yield UInt32(name="DataSize", comment="32-bit-aligned number of bytes of data in the record-specific data that follows")
        if object_type & 0x7f == 5:
            yield ObjectPlusImageRecord(name="DataHeader")
        if len(self) < size:
            yield Bytes(size - len(self), name="Data")            
        

RECORDS_PLUS = {
    0x4008: ObjectPlusRecord,
}
               
############################################### Analyzer


class EMFAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.IMAGE
    name = "EMF"
    regexp = r"\x01\x00\x00\x00.{36} EMF\x00\x00\x01\x00"



    def parse(self, hint):
        hdr = yield HeaderRecord(name="Header", category=Type.HEADER)
        self.metadata["Version"] = "{}.{}".format(hdr["VersionMajor"], hdr["VersionMinor"])
        self.metadata["Surface"] = "{}cm x {}cm".format(hdr["SurfaceSizeMilli"]["Width"] / 10, hdr["SurfaceSizeMilli"]["Height"] / 10)
        filesize = hdr["FileSize"]
        self.confirm()
        while self.remaining() >= 8 and self.tell() < filesize:
            tag, = struct.unpack("<I", self.read(self.tell(), 4))
            cls, typ = RECORDS.get(tag, (EmfRecord, Type.DATA))
            yield cls(category=typ)
            if tag == 14:
                # EOF
                self.confirm()
                break

       
        

