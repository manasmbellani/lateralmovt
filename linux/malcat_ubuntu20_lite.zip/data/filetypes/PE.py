from filetypes.base import *
from filetypes.ordinals import OrdinalTranslator
import bindings
import datetime
import struct
from collections import OrderedDict

def align(val, what, down=False):
    if val % what:
        if down:
            val -= val % what
        else:
            val += what - (val % what)
    return val

MAX_DYNAMIC_STRUCTURE_LENGTH = 4096


class MZ(Struct):

    def parse(self):
        yield String(2, name="Signature", comment="MZ signature")
        yield UInt16(name="LastSize", comment="size of last page of file")
        yield UInt16(name="NumberOfBlocks", comment="number of pages in file")
        yield UInt16(name="NumberOfRelocs", comment="number of relocations")
        yield UInt16(name="HeaderSize", comment="size of header (in 16 bytes paragraphs)")
        yield UInt16(name="MinimumAllocation", comment="minimum extra paragraphs needed")
        yield UInt16(name="MaximumAllocation", comment="maximum extra paragraphs needed")
        yield UInt16(name="InitialSS", comment="initial ss value (relative)")
        yield UInt16(name="InitialSP", comment="inital sp value")
        yield UInt16(name="Checksum", comment="file checksum")
        yield UInt16(name="InitialIP", comment="inital ip value")
        yield UInt16(name="InitialC", comment="inital cs value")
        yield UInt16(name="RelocPosition", comment="file offset to relocation table")
        yield UInt16(name="OverlayNumber", comment="overlay number")
        yield Unused(8, name="Reserved", comment="reserved")
        yield UInt16(name="OEMid", comment="OEM identifier")
        yield UInt16(name="OEMinfos", comment="OEM-specific information")
        yield Unused(20, name="Reserved2", comment="reserved")
        yield UInt32(name="AddressOfPE", comment="file offset to PE header")



RICH_TOOL_ID = [
('Unknown',0x0000), ('Import',0x0001), ('Linker',0x0002), ('Cvtomf',0x0003), ('Linker',0x0004), ('Cvtomf',0x0005), ('Cvtres',0x0006), ('Basic',0x0007), ('C',0x0008), ('Basic',0x0009), 
('C',0x000a), ('CPP',0x000b), ('AliasObj',0x000c), ('VisualBasic',0x000d), ('Masm',0x000e), ('Masm',0x000f), ('Linker',0x0010), ('Cvtomf',0x0011), ('Masm',0x0012), ('Linker',0x0013), 
('Cvtomf',0x0014), ('C_Std',0x0015), ('CPP_Std',0x0016), ('C_Book',0x0017), ('CPP_Book',0x0018), ('Implib',0x0019), ('Cvtomf',0x001a), ('Basic',0x001b), ('C',0x001c), ('CPP',0x001d), 
('Linker',0x001e), ('Cvtomf',0x001f), ('Linker',0x0020), ('Cvtomf',0x0021), ('Basic',0x0022), ('C',0x0023), ('CPP',0x0024), ('Linker',0x0025), ('Cvtomf',0x0026), ('AliasObj',0x0027), 
('Linker',0x0028), ('Cvtomf',0x0029), ('Masm',0x002a), ('LTCG_C',0x002b), ('LTCG_CPP',0x002c), ('Masm',0x002d), ('ILAsm',0x002e), ('Basic',0x002f), ('C',0x0030), ('CPP',0x0031), 
('C_Std',0x0032), ('CPP_Std',0x0033), ('C_Book',0x0034), ('CPP_Book',0x0035), ('Implib',0x0036), ('Cvtomf',0x0037), ('Cvtres',0x0038), ('C_Std',0x0039), ('CPP_Std',0x003a), ('Cvtpgd',0x003b), 
('Linker',0x003c), ('Linker',0x003d), ('Export',0x003e), ('Export',0x003f), ('Masm',0x0040), ('POGO_I_C',0x0041), ('POGO_I_CPP',0x0042), ('POGO_O_C',0x0043), ('POGO_O_CPP',0x0044), ('Cvtres',0x0045), 
('Cvtres',0x0046), ('Linker',0x0047), ('Cvtomf',0x0048), ('Export',0x0049), ('Implib',0x004a), ('Masm',0x004b), ('C',0x004c), ('CPP',0x004d), ('C_Std',0x004e), ('CPP_Std',0x004f), 
('LTCG_C',0x0050), ('LTCG_CPP',0x0051), ('POGO_I_C',0x0052), ('POGO_I_CPP',0x0053), ('POGO_O_C',0x0054), ('POGO_O_CPP',0x0055), ('Linker',0x0056), ('Cvtomf',0x0057), ('Export',0x0058), ('Implib',0x0059), 
('Linker',0x005a), ('Cvtomf',0x005b), ('Export',0x005c), ('Implib',0x005d), ('Cvtres',0x005e), ('C',0x005f), ('CPP',0x0060), ('C_Std',0x0061), ('CPP_Std',0x0062), ('LTCG_C',0x0063), 
('LTCG_CPP',0x0064), ('POGO_I_C',0x0065), ('POGO_I_CPP',0x0066), ('POGO_O_C',0x0067), ('POGO_O_CPP',0x0068), ('AliasObj',0x0069), ('AliasObj',0x006a), ('Cvtpgd',0x006b), ('Cvtpgd',0x006c), ('C',0x006d), 
('CPP',0x006e), ('C_Std',0x006f), ('CPP_Std',0x0070), ('LTCG_C',0x0071), ('LTCG_CPP',0x0072), ('POGO_I_C',0x0073), ('POGO_I_CPP',0x0074), ('POGO_O_C',0x0075), ('POGO_O_CPP',0x0076), ('Cvtpgd',0x0077), 
('Linker',0x0078), ('Cvtomf',0x0079), ('Export',0x007a), ('Implib',0x007b), ('Cvtres',0x007c), ('Masm',0x007d), ('AliasObj',0x007e), ('CIL_C',0x0080), ('CIL_CPP',0x0081), ('LTCG_MSIL',0x0082), 
('C',0x0083), ('CPP',0x0084), ('C_Std',0x0085), ('CPP_Std',0x0086), ('CIL_C',0x0087), ('CIL_CPP',0x0088), ('LTCG_C',0x0089), ('LTCG_CPP',0x008a), ('LTCG_MSIL',0x008b), ('POGO_I_C',0x008c), 
('POGO_I_CPP',0x008d), ('POGO_O_C',0x008e), ('POGO_O_CPP',0x008f), ('Cvtpgd',0x0090), ('Linker',0x0091), ('Export',0x0092), ('Implib',0x0093), ('Cvtres',0x0094), ('Masm',0x0095), ('AliasObj',0x0096), 
('Resource',0x0097), ('AliasObj',0x0098), ('Cvtpgd',0x0099), ('Cvtres',0x009a), ('Export',0x009b), ('Implib',0x009c), ('Linker',0x009d), ('Masm',0x009e), ('C',0x009f), ('CPP',0x00a0), 
('CIL_C',0x00a1), ('CIL_CPP',0x00a2), ('LTCG_C',0x00a3), ('LTCG_CPP',0x00a4), ('LTCG_MSIL',0x00a5), ('POGO_I_C',0x00a6), ('POGO_I_CPP',0x00a7), ('POGO_O_C',0x00a8), ('POGO_O_CPP',0x00a9), ('C',0x00aa), 
('CPP',0x00ab), ('CIL_C',0x00ac), ('CIL_CPP',0x00ad), ('LTCG_C',0x00ae), ('LTCG_CPP',0x00af), ('LTCG_MSIL',0x00b0), ('POGO_I_C',0x00b1), ('POGO_I_CPP',0x00b2), ('POGO_O_C',0x00b3), ('POGO_O_CPP',0x00b4), 
('AliasObj',0x00b5), ('Cvtpgd',0x00b6), ('Cvtres',0x00b7), ('Export',0x00b8), ('Implib',0x00b9), ('Linker',0x00ba), ('Masm',0x00bb), ('C',0x00bc), ('CPP',0x00bd), ('CIL_C',0x00be), 
('CIL_CPP',0x00bf), ('LTCG_C',0x00c0), ('LTCG_CPP',0x00c1), ('LTCG_MSIL',0x00c2), ('POGO_I_C',0x00c3), ('POGO_I_CPP',0x00c4), ('POGO_O_C',0x00c5), ('POGO_O_CPP',0x00c6), ('AliasObj',0x00c7), ('Cvtpgd',0x00c8), 
('Cvtres',0x00c9), ('Export',0x00ca), ('Implib',0x00cb), ('Linker',0x00cc), ('Masm',0x00cd), ('C',0x00ce), ('CPP',0x00cf), ('CIL_C',0x00d0), ('CIL_CPP',0x00d1), ('LTCG_C',0x00d2), 
('LTCG_CPP',0x00d3), ('LTCG_MSIL',0x00d4), ('POGO_I_C',0x00d5), ('POGO_I_CPP',0x00d6), ('POGO_O_C',0x00d7), ('POGO_O_CPP',0x00d8), ('AliasObj',0x00d9), ('Cvtpgd',0x00da), ('Cvtres',0x00db), ('Export',0x00dc), 
('Implib',0x00dd), ('Linker',0x00de), ('Masm',0x00df), ('C',0x00e0), ('CPP',0x00e1), ('CIL_C',0x00e2), ('CIL_CPP',0x00d3), ('LTCG_C',0x00e4), ('LTCG_CPP',0x00e5), ('LTCG_MSIL',0x00e6), 
('POGO_I_C',0x00e7), ('POGO_I_CPP',0x00e8), ('POGO_O_C',0x00e9), ('POGO_O_CPP',0x00ea), ('AliasObj',0x00eb), ('Cvtpgd',0x00ec), ('Cvtres',0x00ed), ('Export',0x00ee), ('Implib',0x00ef), ('Linker',0x00f0), 
('Masm',0x00f1), ('C',0x00f2), ('CPP',0x00f3), ('CIL_C',0x00f4), ('CIL_CPP',0x00f5), ('LTCG_C',0x00f6), ('LTCG_CPP',0x00f7), ('LTCG_MSIL',0x00f8), ('POGO_I_C',0x00f9), ('POGO_I_CPP',0x00fa), 
('POGO_O_C',0x00fb), ('POGO_O_CPP',0x00fc), ('AliasObj',0x00fd), ('Cvtpgd',0x00fe), ('Cvtres',0x00ff), ('Export',0x0100), ('Implib',0x0101), ('Linker',0x0102), ('Masm',0x0103), ('C',0x0104), 
('CPP',0x0105), ('CIL_C',0x0106), ('CIL_CPP',0x0107), ('LTCG_C',0x0108), ('LTCG_CPP',0x0109), ('LTCG_MSIL',0x010a), ('POGO_I_C',0x010b), ('POGO_I_CPP',0x010c), ('POGO_O_C',0x010d), ('POGO_O_CPP',0x010e), 
        ] 

class RichEntry(Struct): 
    
    def __init__(self, xorkey, **kwargs): 
        Struct.__init__(self, **kwargs) 
        self.xorkey = xorkey 
        
    def parse(self):
        key32 = self.xorkey
        key16_1 = key32 & 0xFFFF
        key16_2 = key32 >> 16
        yield UInt16Xor(key16_1, name="Version", comment="Internal build ID of tool")
        yield UInt16Xor(key16_2, name="Tool", comment="Id of tool", values=RICH_TOOL_ID)
        yield UInt32Xor(key32, name="NumberOfUses", comment="Number of uses of the tool")


class RichHeader(Struct):

    def __init__(self, xorkey, size, **kwargs):
        Struct.__init__(self, **kwargs)
        self.xorkey = xorkey
        self.size = size

    def parse(self):
        sig = yield UInt32Xor(self.xorkey, name="Signature", comment="DanS")
        yield Unused(12, name="Padding")
        left = self.size - (len(self) + 8)
        if left > 0:
            yield Array(left//8, RichEntry(self.xorkey), name="ToolsList")
        yield String(4, zero_terminated=False, name="Rich", comment="Rich signature")
        yield UInt32(name="XorKey", comment="xor key")


class PE(Struct):

    def parse(self):
        sig = yield String(4, name="Signature", comment="PE signature")
        if sig != "PE\x00\x00":
            raise FatalError("Invalid PE signature")
        yield UInt16(name="Machine", comment="supported architecture", values=[
            ("IMAGE_FILE_MACHINE_UNKNOWN", 0x0),
            ("IMAGE_FILE_MACHINE_AM33", 0x1d3),
            ("IMAGE_FILE_MACHINE_AMD64", 0x8664),
            ("IMAGE_FILE_MACHINE_ARM", 0x1c0),
            ("IMAGE_FILE_MACHINE_ARM64", 0xaa64),
            ("IMAGE_FILE_MACHINE_ARMNT", 0x1c4),
            ("IMAGE_FILE_MACHINE_EBC", 0xebc),
            ("IMAGE_FILE_MACHINE_I386", 0x14c),
            ("IMAGE_FILE_MACHINE_IA64", 0x200),
            ("IMAGE_FILE_MACHINE_M32R", 0x9041),
            ("IMAGE_FILE_MACHINE_MIPS16", 0x266),
            ("IMAGE_FILE_MACHINE_MIPSFPU", 0x366),
            ("IMAGE_FILE_MACHINE_MIPSFPU16", 0x466),
            ("IMAGE_FILE_MACHINE_POWERPC", 0x1f0),
            ("IMAGE_FILE_MACHINE_POWERPCFP", 0x1f1),
            ("IMAGE_FILE_MACHINE_R4000", 0x166),
            ("IMAGE_FILE_MACHINE_RISCV32", 0x5032),
            ("IMAGE_FILE_MACHINE_RISCV64", 0x5064),
            ("IMAGE_FILE_MACHINE_RISCV128", 0x5128),
            ("IMAGE_FILE_MACHINE_SH3", 0x1a2),
            ("IMAGE_FILE_MACHINE_SH3DSP", 0x1a3),
            ("IMAGE_FILE_MACHINE_SH4", 0x1a6),
            ("IMAGE_FILE_MACHINE_SH5", 0x1a8),
            ("IMAGE_FILE_MACHINE_THUMB", 0x1c2),
            ("IMAGE_FILE_MACHINE_WCEMIPSV2", 0x169),
            ])
        yield UInt16(name="NumberOfSections", comment="number of sections")
        yield Timestamp(name="TimeDateStamp", comment="file creation time")
        yield Rva(name="PointerToSymbolTable", comment="pointer to symbol table")
        yield UInt32(name="NumberOfSymbols", comment="number of symbols")
        yield UInt16(name="SizeOfOptionalHeader", comment="size of optional header")
        yield BitsField(
            Bit(name="RelocsStripped", comment="the file does not contain base relocations and must therefore be loaded at its preferred base"),
            Bit(name="ExecutableImage", comment="the image file is valid and can be run"),
            Bit(name="LineNumbersStripped", comment="COFF line numbers have been removed. This flag is deprecated and should be zero"),
            Bit(name="LocalSymbolsStripped", comment="COFF symbol table entries for local symbols have been removed. This flag is deprecated and should be zero"),
            Bit(name="AggresiveWsTrim", comment="aggressively trim working set. This flag is deprecated for Windows 2000 and later and must be zero."),
            Bit(name="LargeAddressAware", comment="application can handle > 2-GB addresses."),
            NullBits(1),
            Bit(name="BytesReversedLo", comment="the least significant bit (LSB) precedes the most significant bit (MSB) in memory. This flag is deprecated and should be zero"),
            Bit(name="32BitsMachine", comment="based on a 32-bit-word architecture"),
            Bit(name="DebugStripped", comment="debugging information is removed from the image file"),
            Bit(name="RemovableRunFromSwap", comment="if the image is on removable media, fully load it and copy it to the swap file"),
            Bit(name="NetRunFromSwap", comment="if the image is on network media, fully load it and copy it to the swap file"),
            Bit(name="SytemFile", comment="the image file is a system file, not a user program"),
            Bit(name="Dll", comment="image file is a dynamic-link library (DLL)."),
            Bit(name="SystemOnly", comment="file should be run only on a uniprocessor machine"),
            Bit(name="BytesReversedHi", comment="the MSB precedes the LSB in memory. This flag is deprecated and should be zero"),
            name="Characteristics", comment="file characteristics")


class OptionalHeader32(Struct):

    def parse(self):
        magic = yield UInt16(name="Magic", comment="magic", values=[
            ("PE32", 0x10b),
            ("ROM", 0x107),
            ("PE32+", 0x20b),
            ])
        if magic != 0x010B and magic != 0x0107:
            raise FatalError("Invalid magic value: {:x}".format(magic))
        yield UInt8(name="MajorLinkerVersion", comment="linker version (major)")
        yield UInt8(name="MinorLinkerVersion", comment="linker version (minor)")
        yield UInt32(name="SizeOfCode", comment="cumulated size of all code sections")
        yield UInt32(name="SizeOfInitializedData", comment="cumulated size of all initialized data sections")
        yield UInt32(name="SizeOfUninitializedData", comment="cumulated size of all uninitialized data sections")
        yield Rva(name="AddressOfEntryPoint", comment="rva of module entry point")
        yield Rva(name="BaseOfCode", comment="rva of first code section")
        yield Rva(name="BaseOfData", comment="rva of first data section")
        yield Va32(name="ImageBase", comment="preferred loading address")
        yield UInt32(name="SectionAlignment", comment="alignment of sections in memory")
        yield UInt32(name="FileAlignment", comment="alignment of sections on the disk")
        yield UInt16(name="MajorOperatingSystemVersion", comment="required OS version (major)")
        yield UInt16(name="MinorOperatingSystemVersion", comment="required OS version (minor)")
        yield UInt16(name="MajorImageVersion", comment="image version (major)")
        yield UInt16(name="MinorImageVersion", comment="image version (minor)")
        yield UInt16(name="MajorSubsystemVersion", comment="subsystem version (major)")
        yield UInt16(name="MinorSubsystemVersion", comment="subsystem version (minor)")
        yield UInt32(name="Win32VersionValue", comment="???")
        yield UInt32(name="SizeOfImage", comment="size of module once loaded in memory")
        yield UInt32(name="SizeOfHeaders", comment="cumulated size of all headers")
        yield UInt32(name="Checksum", comment="checksum")
        yield UInt16(name="Subsystem", comment="subsystem", values=[
            ("IMAGE_SUBSYSTEM_UNKNOWN", 0),
            ("IMAGE_SUBSYSTEM_NATIVE", 1),
            ("IMAGE_SUBSYSTEM_WINDOWS_GUI", 2),
            ("IMAGE_SUBSYSTEM_WINDOWS_CUI", 3),
            ("IMAGE_SUBSYSTEM_OS2_CUI", 5),
            ("IMAGE_SUBSYSTEM_POSIX_CUI", 7),
            ("IMAGE_SUBSYSTEM_NATIVE_WINDOWS", 8),
            ("IMAGE_SUBSYSTEM_WINDOWS_CE_GUI", 9),
            ("IMAGE_SUBSYSTEM_EFI_APPLICATION", 10),
            ("IMAGE_SUBSYSTEM_EFI_BOOT_ SERVICE_DRIVER", 11),
            ("IMAGE_SUBSYSTEM_EFI_RUNTIME_ DRIVER", 12),
            ("IMAGE_SUBSYSTEM_EFI_ROM", 13),
            ("IMAGE_SUBSYSTEM_XBOX", 14),
            ("IMAGE_SUBSYSTEM_WINDOWS_BOOT_APPLICATION", 16),
            ])
        yield BitsField(
            NullBits(5),
            Bit(name="HighEntropyVA", comment="image can handle a high entropy 64-bit virtual address space"),
            Bit(name="DynamicBase", comment="DLL can be relocated at load time"),
            Bit(name="ForceIntegrity", comment="code Integrity checks are enforced"),
            Bit(name="NXcompat", comment="image is NX compatible"),
            Bit(name="NoIsolation", comment="isolation aware, but do not isolate the image"),
            Bit(name="NoSEH", comment="does not use Structured Exception Handling"),
            Bit(name="NoBind", comment="do not bind the image"),
            Bit(name="AppContainer", comment="image must execute in an AppContainer"),
            Bit(name="WDMDriver", comment="image is a WDM driver"),
            Bit(name="ControlFlowGuard", comment="image supports control flow guard"),
            Bit(name="TerminalServerAware", comment="terminal server aware"),
            name="DllCharacteristics", comment="pe characteristics")
        yield UInt32(name="SizeOfStackReserve", comment="maximum size of stack")
        yield UInt32(name="SizeOfStackCommit", comment="initial size of stack")
        yield UInt32(name="SizeOfHeapReserve", comment="maximum size of heap")
        yield UInt32(name="SizeOfHeapCommit", comment="initial size of heap")
        yield UInt32(name="LoaderFlags", comment="reserved, must be zero")
        num_dd = yield UInt32(name="NumberOfRvaAndSizes", comment="number of entries in datadirectory")
        if self.analyzer["PE"]["SizeOfOptionalHeader"]:
            if not num_dd:
                num_dd = (self.analyzer["PE"]["SizeOfOptionalHeader"] - len(self)) // 8
            else:
                num_dd = min(num_dd, (self.analyzer["PE"]["SizeOfOptionalHeader"] - len(self)) // 8)
        if num_dd <= 0:
            num_dd = 1
        yield Array(num_dd, InfoDataDirectory(), name="DataDirectory")

class OptionalHeader64(Struct):

    def parse(self):
        magic = yield UInt16(name="Magic", comment="magic", values=[
            ("PE32", 0x10b),
            ("ROM", 0x107),
            ("PE32+", 0x20b),
            ])
        if magic != 0x020B:
            raise FatalError("Invalid magic value: {:x}".format(magic))
        yield UInt8(name="MajorLinkerVersion", comment="linker version (major)")
        yield UInt8(name="MinorLinkerVersion", comment="linker version (minor)")
        yield UInt32(name="SizeOfCode", comment="cumulated size of all code sections")
        yield UInt32(name="SizeOfInitializedData", comment="cumulated size of all initialized data sections")
        yield UInt32(name="SizeOfUninitializedData", comment="cumulated size of all uninitialized data sections")
        yield Rva(name="AddressOfEntryPoint", comment="rva of module entry point")
        yield Rva(name="BaseOfCode", comment="rva of first code section")
        yield Va64(name="ImageBase", comment="preferred loading address")
        yield UInt32(name="SectionAlignment", comment="alignment of sections in memory")
        yield UInt32(name="FileAlignment", comment="alignment of sections on the disk")
        yield UInt16(name="MajorOperatingSystemVersion", comment="required OS version (major)")
        yield UInt16(name="MinorOperatingSystemVersion", comment="required OS version (minor)")
        yield UInt16(name="MajorImageVersion", comment="image version (major)")
        yield UInt16(name="MinorImageVersion", comment="image version (minor)")
        yield UInt16(name="MajorSubsystemVersion", comment="subsystem version (major)")
        yield UInt16(name="MinorSubsystemVersion", comment="subsystem version (minor)")
        yield UInt32(name="Win32VersionValue", comment="???")
        yield UInt32(name="SizeOfImage", comment="size of module once loaded in memory")
        yield UInt32(name="SizeOfHeaders", comment="cumulated size of all headers")
        yield UInt32(name="Checksum", comment="checksum")
        yield UInt16(name="Subsystem", comment="subsystem", values=[
            ("IMAGE_SUBSYSTEM_UNKNOWN", 0),
            ("IMAGE_SUBSYSTEM_NATIVE", 1),
            ("IMAGE_SUBSYSTEM_WINDOWS_GUI", 2),
            ("IMAGE_SUBSYSTEM_WINDOWS_CUI", 3),
            ("IMAGE_SUBSYSTEM_OS2_CUI", 5),
            ("IMAGE_SUBSYSTEM_POSIX_CUI", 7),
            ("IMAGE_SUBSYSTEM_NATIVE_WINDOWS", 8),
            ("IMAGE_SUBSYSTEM_WINDOWS_CE_GUI", 9),
            ("IMAGE_SUBSYSTEM_EFI_APPLICATION", 10),
            ("IMAGE_SUBSYSTEM_EFI_BOOT_ SERVICE_DRIVER", 11),
            ("IMAGE_SUBSYSTEM_EFI_RUNTIME_ DRIVER", 12),
            ("IMAGE_SUBSYSTEM_EFI_ROM", 13),
            ("IMAGE_SUBSYSTEM_XBOX", 14),
            ("IMAGE_SUBSYSTEM_WINDOWS_BOOT_APPLICATION", 16),
            ])
        yield BitsField(
            NullBits(5),
            Bit(name="HighEntropyVA", comment="image can handle a high entropy 64-bit virtual address space"),
            Bit(name="DynamicBase", comment="DLL can be relocated at load time"),
            Bit(name="ForceIntegrity", comment="code Integrity checks are enforced"),
            Bit(name="NXcompat", comment="image is NX compatible"),
            Bit(name="NoIsolation", comment="isolation aware, but do not isolate the image"),
            Bit(name="NoSEH", comment="does not use Structured Exception Handling"),
            Bit(name="NoBind", comment="do not bind the image"),
            Bit(name="AppContainer", comment="image must execute in an AppContainer"),
            Bit(name="WDMDriver", comment="image is a WDM driver"),
            Bit(name="ControlFlowGuard", comment="image supports control flow guard"),
            Bit(name="TerminalServerAware", comment="terminal server aware"),
            name="DllCharacteristics", comment="pe characteristics")
        yield UInt64(name="SizeOfStackReserve", comment="maximum size of stack")
        yield UInt64(name="SizeOfStackCommit", comment="initial size of stack")
        yield UInt64(name="SizeOfHeapReserve", comment="maximum size of heap")
        yield UInt64(name="SizeOfHeapCommit", comment="initial size of heap")
        yield UInt32(name="LoaderFlags", comment="???")
        num_dd = yield UInt32(name="NumberOfRvaAndSizes", comment="number of entries in datadirectory")
        if num_dd == 0:
            raise FatalError("invalid NumberOfRvaAndSize: {}".format(num_dd))
        num_dd = min(num_dd, (self.analyzer["PE"]["SizeOfOptionalHeader"] - len(self)) // 8)
        if num_dd <= 0:
            num_dd = 1
        yield Array(num_dd, InfoDataDirectory(), name="DataDirectory")


class InfoDataDirectory(Struct):

    def parse(self):
        yield Rva(name="Rva")
        yield UInt32(name="Size")


class Section(Struct):

    def parse(self):
        yield String(8, name="Name", comment="section name")
        yield UInt32(name="VirtualSize", comment="section size in memory")
        yield Rva(name="VirtualAddress", comment="section rva")
        yield UInt32(name="SizeOfRawData", comment="section size on disk")
        yield Offset32(name="PointerToRawData", comment="section file offset")
        yield Offset32(name="PointerToRelocations", comment="")
        yield Offset32(name="PointerToLinenumbers", comment="")
        yield UInt16(name="NumberOfRelocations", comment="")
        yield UInt16(name="NumberOfLinenumbers", comment="")
        yield BitsField(
            NullBits(3),
            Bit(name="SctTypeNoPad", comment="section should not be padded to the next boundary (this flag is obsolete and is replaced by ScnAlign1)"),
            NullBits(1),
            Bit(name="SctCntCode", comment="section contains executable code"),
            Bit(name="SctCntInitializedData", comment="section contains initialized data"),
            Bit(name="SctCntUnititializedData", comment="section contains uninitialized data"),
            Bit(name="SctLnkOther", comment="for future use"),
            Bit(name="ScnLnkInfo", comment="section contains comments or other information, valid only for object files"),
            NullBits(1),
            Bit(name="ScnLnkRemove", comment="section will not become part of the image, valid only for object files"),
            Bit(name="ScnLnkComdat", comment="section contains COMDAT data, valid only for object files"),
            NullBits(2),
            Bit(name="ScnGprel", comment="section contains data referenced through the global pointer (GP)"),
            Bit(name="MemPurgeable", comment="for future use"),
            Bit(name="Mem16bit", comment="for future use"),
            Bit(name="MemLocked", comment="for future use"),
            Bit(name="MemPreload", comment="for future use"),
            Bit(name="ScnAlign1", comment="align data on an 1-byte boundary, valid only for object files"),
            Bit(name="ScnAlign2", comment="align data on an 2-byte boundary, valid only for object files"),
            Bit(name="ScnAlign8", comment="align data on an 8-byte boundary, valid only for object files"),
            Bit(name="ScnAlign128", comment="align data on an 128-byte boundary, valid only for object files"),
            Bit(name="LinkRelocOverflow ", comment="section contains extended relocations"),
            Bit(name="MemDiscardable", comment="section can be discarded as needed"),
            Bit(name="MemNotCached", comment="section cannot be cached"),
            Bit(name="MemNotPaged", comment="section is not pageable"),
            Bit(name="MemShared", comment="section can be shared in memory"),
            Bit(name="MemExecute", comment="section can be executed as code"),
            Bit(name="MemRead", comment="section can be read"),
            Bit(name="MemWrite", comment="section can be written to"),
            name="Characteristics", comment="section characteristics")


class ExportDirectory(Struct):        
    def parse(self):
        yield UInt32(name="Flags", comment="reserved, must be 0")
        yield Timestamp(name="TimeDateStamp", comment="timedatestamp")
        yield UInt16(name="MajorVersion", comment="major version number")
        yield UInt16(name="MinorVersion", comment="minor version number")
        yield Rva(name="Name", hint=String(0, True), comment="rva to dll name")
        yield UInt32(name="OrdinalBase", comment="specifies the starting ordinal number for the export address table, usually set to 1")
        yield UInt32(name="AddressTableEntries", comment="number of entries in the export address table")
        yield UInt32(name="NameTableEntries", comment="number of entries in the name pointer table")
        yield Rva(name="AddressTable", comment="export address table rva")
        yield Rva(name="NameTable", comment="export address table rva")
        yield Rva(name="OrdinalTable", comment="export ordinal table rva")


class ExceptionEntryX64(Struct):

    def parse(self):
        yield Rva(name="Begin", comment="start of function")
        yield Rva(name="End", comment="end of function")
        yield Rva(name="Information", comment="unwind information")



class DelayImportDescriptor(Struct):
    def __init__(self, use_rva=False, *args, **kwargs):
        Struct.__init__(self, *args, **kwargs)
        self.use_rva = use_rva

    def parse(self):
        if self.use_rva:
            ptr = Rva
        else:
            ptr = Va32
        yield BitsField(
            Bit(name="UseRva", comment="new format used, pointers are rvas"),
            NullBits(31),
            name="Attributes")
        yield ptr(name="Name", hint=String(0, True), comment="rva to dll name")
        yield Rva(name="ModuleHandle",comment="RVA of the module handle (in the data section of the image) of the DLL to be delay-loaded. It is used for storage by the routine that is supplied to manage delay-loading")
        yield Rva(name="AddressTable",comment="RVA of the delay-load import address table")
        yield ptr(name="NameTable",comment="RVA of the delay-load name table, which contains the names of the imports that might need to be loaded. This matches the layout of the import name table")
        yield ptr(name="BoundTable",comment="RVA of the bound delay-load address table, if it exists")
        yield ptr(name="UnloadAddressTable",comment="RVA of the unload delay-load address table, if it exists. This is an exact copy of the delay import address table. If the caller unloads the DLL, this table should be copied back over the delay import address table so that subsequent calls to the DLL continue to use the thunking mechanism correctly")
        yield Timestamp(name="TimeDateStamp", comment="timedatestamp of bound dll")

class ImageImportDescriptor(Struct):

    def parse(self):
        yield Rva(name="OriginalFirstThunk", comment="rva to original list of api names")
        yield Timestamp(name="TimeDateStamp", comment="timedatestamp of bound dll")
        yield UInt32(name="ForwarderChain", comment="-1 if not forwarded")
        yield Rva(name="Name", hint=String(0, True), comment="rva to dll name")
        yield Rva(name="FirstThunk", comment="rva to import address table")


class ImageResourceDirectory(Struct):

    def __init__(self, entries, **kwargs):
        Struct.__init__(self, **kwargs)
        self.entries = entries

    def parse(self):
        yield UInt32(name="Characteristics", comment="resource flags (always 0)")
        yield Timestamp(name="TimeDateStamp", comment="creation time of the resource")
        yield UInt16(name="MajorVersion", comment="major version number of resource")
        yield UInt16(name="MinorVersion", comment="minor version number of resource")
        num_named = yield UInt16(name="NumberOfNamedEntries", comment="number of named entries in dir")
        num_id = yield UInt16(name="NumberOfIdEntries", comment="number of ID entries in dir")
        if num_named + num_id > MAX_DYNAMIC_STRUCTURE_LENGTH:
            raise FatalError("Resources too big")
        yield Array(num_id + num_named, self.entries(), name="DirectoryEntries")




class ImageResourceDirectoryEntry2(Struct):

    def parse(self):
        yield UInt32(name="Name", comment="ID or offset (relative to start of resources) to name (if high bit is set)")
        yield UInt32(name="OffsetToData", comment="offset (relative to start of resources) to ImageResourceDataEntry")

class ImageResourceDirectoryEntry1(Struct):

    def parse(self):
        yield UInt32(name="Type", comment="ID or offset (relative to start of resources) to resource type (if high bit is set)", values=RSRC_ID)
        yield UInt32(name="OffsetToData", comment="offset (relative to start of resources) to ImageResourceDirectory")        

class ImageResourceDirectoryEntry3(Struct):

    def parse(self):
        yield UInt32(name="Language", comment="resource language", values=RSRC_LANGUAGE)
        yield UInt32(name="OffsetToData", comment="offset (relative to start of resources) to ImageResourceDirectory ")        


class ImageResourceDirString(Struct):

    def parse(self):
        num_cars= yield UInt16(name="Length", comment="number of unicode characters")
        yield Array(num_cars, UInt16(), name="NameString")

class ImageResourceDataEntry(Struct):

    def parse(self):
        rva = yield Rva(name="OffsetToData", comment="rva to resource data")
        yield UInt32(name="Size", comment="size of resource data")
        yield UInt32(name="CodePage", comment="codepage")
        # Some compilers make the resource starts at Reserved in order to save 4 bytes. 
        # If we don't want structures to overlap, we just omit Reserved then
        off = self.analyzer.rva2off(rva)
        if off is None or off != self.analyzer.tell():
            yield UInt32(name="Reserved", comment="")


class Relocations(Struct):

    def parse(self):
        while True:
            rc = yield RelocChunk(name="Chunk")
            if rc["PageRva"] == 0 or rc["BlockSize"] == 0:
                break

class RelocChunk(Struct):

    def parse(self):
        yield Rva(name="PageRva", comment="base rva of relocs")
        bs = yield UInt32(name="BlockSize", comment="size of reloc chunk")
        if bs < 8:
            raise FatalError("Invalid reloc chunk size")
        yield Array((bs - 8) // 2, UInt16(), name="Relocs", comment="list of relocations")


class Region:

    def __init__(self, rva, vsize, foff, fsize, section):
        self.rva = rva
        self.vsize = vsize
        self.foff = foff
        self.fsize = fsize
        self.section = section


class VersionInfo(Struct):

    def parse(self):
        length = yield UInt16(name="Length", comment="size of VersionInfo structure")
        yield UInt16(name="ValueLength", comment="size of Value member")
        yield UInt16(name="Type", comment="type of data in the version resource")
        key = yield CStringUtf16le(name="Key", comment="the unicode string VS_VERSION_INFO")
        if key != "VS_VERSION_INFO":
            raise FatalError("Invalid VersionInfo key {}".format(repr(key)))
        yield Align(4)
        yield FixedFileInfo()
        yield Align(4)
        # check for stringfileinfo
        while len(self) < length:
            if len(self) + 6 + 14*2 < length and self.look_ahead(6 + 14*2)[6:] == "StringFileInfo".encode("utf-16-le"):
                try:
                    yield VersionStringFileInfo()
                except ParsingError:
                    pass
            # check for varfileinfo
            elif len(self) + 6 + 11*2 < length and self.look_ahead(6 + 11*2)[6:] == "VarFileInfo".encode("utf-16-le"):
                try:
                    yield VersionVarFileInfo()
                except ParsingError:
                    pass
            else:
                break


class VersionString(Struct):

    def parse(self):
        length = yield UInt16(name="Length", comment="size of VersionString structure")
        value_length = yield UInt16(name="ValueLength", comment="size, in words, of the Value member")
        yield UInt16(name="Type", comment="1 if the version resource contains text data and 0 if the version resource contains binary data")
        key = yield CStringUtf16le(name="Key", comment="string name")
        yield Align(4)
        len_words = len(self) + value_length * 2
        len_bytes = len(self) + value_length
        if value_length > 1 and len_words - length > 3 and len_bytes <= length and value_length > 3:
            # some compilers fuck this up and write the length in bytes instead of words
            value_length = value_length // 2
        data = self.look_ahead(value_length * 2)[-2:]
        if data != b"\x00\x00" and len_words < length:
            value = yield CStringUtf16le(name="Value", comment="string value")
        else:
            value = yield StringUtf16le(value_length, name="Value", zero_terminated=True, comment="string value")
        key = key.encode("ascii", errors="ignore").decode("ascii")
        if not key in self.analyzer.metadata["VersionInfo"]:
            self.analyzer.metadata["VersionInfo"][key] = value
        if length - len(self) >= 4:
            yield Unused(length - len(self), name="Overlay", comment="this should not be there")
        yield Align(4)



class VersionStringTable(Struct):

    def parse(self):
        length = yield UInt16(name="Length", comment="size of VersionStringTable structure")
        yield UInt16(name="ValueLength", comment="always equal to zero")
        yield UInt16(name="Type", comment="1 if the version resource contains text data and 0 if the version resource contains binary data")
        key = yield StringUtf16le(9, name="Key", zero_terminated=True, comment="8-digit hexadecimal number stored as a Unicode string. The four most significant digits represent the language identifier. The four least significant digits represent the code page for which the data is formatted")
        yield Align(4)
        while len(self) < length:
            yield VersionString(name="String")


class VersionStringFileInfo(Struct):

    def parse(self):
        length = yield UInt16(name="Length", comment="size of VersionStringFileInfo structure")
        yield UInt16(name="ValueLength", comment="always equal to zero")
        tp = yield UInt16(name="Type", comment="1 if the version resource contains text data and 0 if the version resource contains binary data")
        key = yield CStringUtf16le(name="Key", comment="the unicode string StringFileInfo")
        if key != "StringFileInfo":
            print("Invalid StringFileInfo key {}".format(repr(key)))
            # still continue
        yield Align(4)
        while len(self) < length:
            yield VersionStringTable(name="VersionStringTable")

class VersionVarFileInfo(Struct):

    def parse(self):
        length = yield UInt16(name="Length", comment="size of VersionVarFileInfo structure")
        yield UInt16(name="ValueLength", comment="always equal to zero")
        yield UInt16(name="Type", comment="1 if the version resource contains text data and 0 if the version resource contains binary data")
        key = yield CStringUtf16le(name="Key", comment="the unicode string VarFileInfo")
        if key != "VarFileInfo":
            print("Invalid VarFileInfo key {}".format(repr(key)))
            # still continue
        yield Align(4)
        while len(self) < length:
            yield VersionVar(name="VersionVar")


class VersionVar(Struct):

    def parse(self):
        length = yield UInt16(name="Length", comment="size of VersionVar structure")
        value_length = yield UInt16(name="ValueLength", comment="length, in bytes, of the Value member")
        type = yield UInt16(name="Type", comment="1 if the version resource contains text data and 0 if the version resource contains binary data")
        key = yield CStringUtf16le(name="Key", comment="var name")
        yield Align(4)
        if value_length:
            if type == 1:
                len_words = len(self) + value_length * 2
                len_bytes = len(self) + value_length
                if value_length > 1 and len_words > length and len_bytes <= length:
                    # some compilers fuck this up and write the length in bytes instead of words
                    value_length = value_length // 2
                data = self.look_ahead(value_length * 2)[-2:]
                if data != b"\x00\x00" and len_words < length:
                    value = yield CStringUtf16le(name="Value", comment="var value")
                else:
                    value = yield StringUtf16le(value_length, name="Value", zero_terminated=True, comment="var value")
            else:
                yield Bytes(value_length, name="Value", comment="var value")
                value = None
            if value:
                key = key.encode("ascii", errors="ignore").decode("ascii")
                if not key in self.analyzer.metadata["VersionInfo"]:
                    self.analyzer.metadata["VersionInfo"][key] = value
            yield Align(4)


class FixedFileInfo(Struct):

    def parse(self):
        sig = yield UInt32(name="Signature", comment="the value 0xFEEF04BD")
        if sig is not None and sig != 0xFEEF04BD:
            raise FatalError("Invalid fileinfo signature {:x}".format(sig))
        yield UInt16(name="StrucVersionMinor", comment="binary version number of this structure (minor)")
        yield UInt16(name="StrucVersionMajor", comment="binary version number of this structure (major)")
        yield UInt32(name="FileVersionMS", comment="most significant 32 bits of the file's binary version number")
        yield UInt32(name="FileVersionLS", comment="least significant 32 bits of the file's binary version number")
        yield UInt32(name="ProductVersionMS", comment="most significant 32 bits of the binary version number of the product with which this file was distributed")
        yield UInt32(name="ProductVersionLS", comment="least significant 32 bits of the binary version number of the product with which this file was distributed")
        yield UInt32(name="FileFlagsMask", comment="bitmask that specifies the valid bits in FileFlags")
        yield BitsField(
            Bit(name="VS_FF_DEBUG", comment="file contains debugging information or is compiled with debugging features enabled"),
            Bit(name="VS_FF_PRERELEASE", comment="file is a development version, not a commercially released product"),
            Bit(name="VS_FF_PATCHED", comment="file has been modified and is not identical to the original shipping file of the same version number"),
            Bit(name="VS_FF_PRIVATEBUILD", comment="file was not built using standard release procedures. If this flag is set, the StringFileInfo structure should contain a PrivateBuild entry"),
            Bit(name="VS_FF_INFOINFERRED", comment="file's version structure was created dynamically; therefore, some of the members in this structure may be empty or incorrect. This flag should never be set in a file's VS_VERSIONINFO data"),
            Bit(name="VS_FF_SPECIALBUILD", comment="file was built by the original company using standard release procedures but is a variation of the normal file of the same version number. If this flag is set, the StringFileInfo structure should contain a SpecialBuild entry"),
            NullBits(26), name="FileFlags", comment="bitmask that specifies the Boolean attributes of the file"
        )
        yield UInt32(name="FileOS", comment="operating system for which this file was designed", values=[
            ("VOS_DOS", 0x00010000),
            ("VOS_NT", 0x00040000),
            ("VOS_WINDOWS16", 0x00000001),
            ("VOS_WINDOWS32", 0x00000004),
            ("VOS_OS216", 0x00020000),
            ("VOS_OS232", 0x00030000),
            ("VOS_PM16", 0x00000002),
            ("VOS_PM32", 0x00000003),
            ("VOS_UNKNOWN", 0x00000000),
            ("VOS_DOS_WINDOWS16", 0x00010001),
            ("VOS_DOS_WINDOWS32", 0x00010004),
            ("VOS_NT_WINDOWS32", 0x00040004),
            ("VOS_OS216_PM16", 0x00020002),
            ("VOS_OS232_PM32", 0x00030003),
        ])
        yield UInt32(name="FileType", comment="general type of file", values=[
            ("VFT_APP", 0x00000001),
            ("VFT_DLL", 0x00000002),
            ("VFT_DRV", 0x00000003),
            ("VFT_FONT", 0x00000004),
            ("VFT_STATIC_LIB", 0x00000007),
            ("VFT_VXD", 0x00000005),
        ])
        yield UInt32(name="FileSubtype", comment="function of the file. The possible values depend on the value of FileType")
        yield UInt64BE(name="FileDate", comment="64-bit binary creation date and time stamp")


class CertificateEntry(Struct):

    def parse(self):
        length = yield UInt32(name="Length", comment="size of certifcate entry")
        yield UInt16(name="Revision", comment="certificate version number", values=[
            ("WIN_CERT_REVISION_1_0", 0x100),
            ("WIN_CERT_REVISION_2_0", 0x200),
            ])
        yield UInt16(name="CertificateType", comment="certificate type", values=[
            ("WIN_CERT_TYPE_X509", 1),
            ("WIN_CERT_TYPE_PKCS_SIGNED_DATA", 2),
            ("WIN_CERT_TYPE_RESERVED", 3),
            ("WIN_CERT_TYPE_TS_STACK_SIGNED", 4),
            ])
        todo = length - len(self)
        if todo < 0:
            raise FatalError("Invalid certificate size")
        yield Bytes(todo, name="Data", comment="certificate data")
        yield Align(8)


class DebugDirectory(Struct):

    def parse(self):
        yield UInt32(name="Characteristics", comment="reserved, must be zero")
        yield Timestamp(name="TimeDateStamp", comment="time and date that the debug data was created")
        yield UInt16(name="MajorVersion", comment="major version of the debug data format")
        yield UInt16(name="MinorVersion", comment="minor version of the debug data format")
        yield UInt32(name="Type", comment="certificate type", values=[
            ("IMAGE_DEBUG_TYPE_UNKNOWN", 0),
            ("IMAGE_DEBUG_TYPE_COFF", 1),
            ("IMAGE_DEBUG_TYPE_CODEVIEW", 2),
            ("IMAGE_DEBUG_TYPE_FPO", 3),
            ("IMAGE_DEBUG_TYPE_MISC", 4),
            ("IMAGE_DEBUG_TYPE_EXCEPTION", 5),
            ("IMAGE_DEBUG_TYPE_FIXUP", 6),
            ("IMAGE_DEBUG_TYPE_OMAP_TO_SRC", 7),
            ("IMAGE_DEBUG_TYPE_OMAP_FROM_SRC", 8),
            ("IMAGE_DEBUG_TYPE_BORLAND", 9),
            ("IMAGE_DEBUG_TYPE_RESERVED10", 10),
            ("IMAGE_DEBUG_TYPE_CLSID", 11),
            ("IMAGE_DEBUG_TYPE_VC_FEATURE", 12),
            ("IMAGE_DEBUG_TYPE_POGO", 13),
            ("IMAGE_DEBUG_TYPE_ILTCG", 14),
            ("IMAGE_DEBUG_TYPE_MPX", 15),
            ("IMAGE_DEBUG_TYPE_REPRO", 16),
            ("IMAGE_DEBUG_TYPE_EX_DLLCHARACTERISTICS", 20),
            ])
        yield UInt32(name="SizeOfData", comment="size of the debug data (not including the debug directory itself)")
        yield Rva(name="AddressOfRawData", comment="address of the debug data when loaded, relative to the image base")
        yield Offset32(name="PointerToRawData", comment="file pointer to the debug data")


class CVInfoPdb20(Struct):

    def parse(self):
        yield String(4, name="CvSignature", zero_terminated=False)
        yield UInt32(name="Offset", comment="should be zero")
        yield Timestamp(name="Signature", comment="pdb time")
        yield UInt32(name="Age", comment="always incrementing value")
        yield CString(name="Path", comment="PDB path")


class CVInfoPdb70(Struct):

    def parse(self):
        yield String(4, name="CvSignature", zero_terminated=False)
        yield GUID(name="Signature", comment="unique signature")
        yield UInt32(name="Age", comment="always incrementing value")
        yield CString(name="Path", comment="PDB path")


class TlsDirectory(Struct):

    def parse(self):
        if self.analyzer.is64:
            ptr = Va64
        else:
            ptr = Va32
        yield ptr(name="RawDataStart", comment="starting address of the TLS template")
        yield ptr(name="RawDataEnd", comment="end address of the TLS template")
        yield ptr(name="TlsIndexAddress", comment="location to receive the TLS index")
        yield ptr(name="CallbacksAddress", comment="pointer to an array of TLS callback functions")
        yield UInt32(name="SizeOfZeroFill", comment="size in bytes of the template, beyond the initialized data delimited by the Raw Data Start VA and Raw Data End VA fields")
        yield BitsField(
            NullBits(19),
            Bit(name="ScnAlign1", comment="align data on an 1-byte boundary, valid only for object files"),
            Bit(name="ScnAlign2", comment="align data on an 2-byte boundary, valid only for object files"),
            Bit(name="ScnAlign8", comment="align data on an 8-byte boundary, valid only for object files"),
            Bit(name="ScnAlign128", comment="align data on an 128-byte boundary, valid only for object files"),
            NullBits(9),
            name="Characteristics", comment="TLS array characteristics")


class LoadConfigurationTable(Struct):

    def parse(self):
        if self.analyzer.is64:
            va = Va64
            sz = UInt64
        else:
            va = Va32
            sz = UInt32
        chars = yield UInt32(name="SizeOfStructure", comment="size of structure")
        yield Timestamp(name="TimeDateStamp")
        yield UInt16(name="MajorVersion")
        yield UInt16(name="MinorVersion")
        yield UInt32(name="GlobalFlagsClear", comment="global loader flags to clear for this process as the loader starts the process")
        yield UInt32(name="GlobalFlagsSet", comment="global loader flags to set for this process as the loader starts the process")
        yield UInt32(name="CriticalSectionDefaultTimeout", comment="default timeout value to use for this process's critical sections that are abandoned")
        yield sz(name="DeCommitFreeBlockThreshold", comment="memory that must be freed before it is returned to the system, in bytes")
        yield sz(name="DeCommitTotalFreeThreshold", comment="total amount of free memory, in bytes")
        yield va(name="LockPrefixTable", comment="VA of a list of addresses where the LOCK prefix is used so that they can be replaced with NOP on single processor machines")
        yield sz(name="MaximumAllocationSize", comment="total amount of free memory, in bytes")
        yield sz(name="VirtualMemoryThreshold", comment="maximum virtual memory size, in bytes")
        yield sz(name="ProcessAffinityMask", comment="setting this field to a non-zero value is equivalent to calling SetProcessAffinityMask with this value during process startup (.exe only)")
        yield BitsField(
                Bit(name="HEAP_NO_SERIALIZE", comment="serialized access will not be used for this allocation"),
                NullBits(1),
                Bit(name="HEAP_GENERATE_EXCEPTIONS", comment="system will raise an exception to indicate a function failure, such as an out-of-memory condition, instead of returning NULL"),
                Bit(name="HEAP_ZERO_MEMORY", comment="allocated memory will be initialized to zero"),
                NullBits(28),
                name="ProcessHeapFlags", comment="heap flags that correspond to the first argument of the HeapCreate function. These flags apply to the process heap that is created during process startup")
        yield UInt16(name="CSDVersion", comment="Service Pack identifier")
        yield UInt16(name="Reserved", comment="must be zero")
        yield sz(name="EditList", comment="for use by the system")
        yield va(name="SecurityCookie", comment="pointer to a cookie that is used by Visual C++ or GS implementation")
        yield va(name="SEHandlerTable", comment="VA of the sorted table of RVAs of each valid, unique SE handler in the image")
        yield sz(name="SEHandlerCount", comment="count of unique handlers in the SEHandlerTable")
        if chars > 0x48:
            yield va(name="GuardCFCheckFunctionPointer", comment="VA where Control Flow Guard check-function pointer is stored")
            yield va(name="GuardCFDispatchFunctionPointer", comment="VA where Control Flow Guard dispatch-function pointer is stored")
            yield va(name="GuardCFFunctionTable", comment="VA of the sorted table of RVAs of each Control Flow Guard function in the image")
            yield sz(name="GuardCFFunctionCount", comment="count of unique RVAs in the GuardCFFunctionTable")
            yield BitsField(
                    NullBits(8),
                    Bit(name="CF_INSTRUMENTED", comment="performs control flow integrity checks using system-supplied support"),
                    Bit(name="CFW_INSTRUMENTED", comment="performs control flow and write integrity checks"),
                    Bit(name="CF_FUNCTION_TABLE_PRESENT", comment="contains valid control flow target metadata"),
                    Bit(name="SECURITY_COOKIE_UNUSED", comment="does not make use of the /GS security cookie"),
                    Bit(name="PROTECT_DELAYLOAD_IAT", comment="supports read only delay load IAT"),
                    Bit(name="DELAYLOAD_IAT_IN_ITS_OWN_SECTION", comment="Delayload import table in its own .didat section (with nothing else in it) that can be freely reprotected"),
                    Bit(name="CF_EXPORT_SUPPRESSION_INFO_PRESENT", comment="contains suppressed export information. This also infers that the address taken IAT table is also present in the load config"),
                    Bit(name="CF_ENABLE_EXPORT_SUPPRESSION", comment="enables suppression of exports"),
                    Bit(name="CF_LONGJUMP_TABLE_PRESENT", comment="contains longjmp target information"),
                    NullBits(15),
                    name="GuardFlags", comment="Control Flow Guard related flags")
        if chars > 0x94:
            yield Bytes(12, name="CodeIntegrity", comment="code integrity information")
            yield va(name="GuardAddressTakenIatEntryTable", comment="VA where Control Flow Guard address taken IAT table is stored")
            yield sz(name="GuardAddressTakenIatEntryCount", comment="count of unique RVAs in GuardAddressTakenIatEntryTable")
            yield va(name="GuardLongJumpTargetTable", comment="VA where Control Flow Guard long jump target table is stored")
            yield sz(name="GuardLongJumpTargetCount", comment="count of unique RVAs in GuardLongJumpTargetTable")


class UnitInfo(Struct):

    def __init__(self, sz, *args, **kwargs):
        Struct.__init__(self, *args, **kwargs)
        self.sz = sz

    def parse(self):
        if self.sz < 2:
            raise FatalError
        info = yield UInt16(name="Info")
        if info and self.sz > 2:
            yield CString(name="Name")


class PackageInfo(Struct):

    def __init__(self, sz, *args, **kwargs):
        Struct.__init__(self, *args, **kwargs)
        self.sz = sz


    def parse(self):
        yield BitsField(
            Bit(name="NeverBuild"),
            Bit(name="DesignTimeBuild"),
            Bit(name="RunTimeBuild"),
            Bit(name="IgnoreDup", comment="don't check for duplicate units"),
            NullBits(26),
            Bit(name="PackageDll"),
            Bit(name="LibraryDll"),
            name="BuildFlags", comment="Delphi build flags")
        yield Bytes(8, name="Unknown")
        try:
            while len(self) < self.sz:
                ui = yield UnitInfo(self.sz - len(self))
                if not ui["Info"]:
                    break
        except FatalError:
            pass
    


RSRC_ID = [
    ("CUR",1 ),
    ("BMP",2 ),
    ("ICO",3 ),
    ("MENU",4 ),
    ("DLG",5 ),
    ("STR",6 ),
    ("FNTDIR",7 ),
    ("FNT",8 ),
    ("ACC",9 ),
    ("RCDATA",10 ),
    ("MSG",11 ),
    ("GRPCUR",12 ),
    ("GRPICO",14 ),
    ("VER",16 ),
    ("DLGINC",17 ),
    ("PNP",19 ),
    ("VXD",20 ),
    ("ANICUR",21 ),
    ("ANIICO",22 ),
    ("HTML",23 ),
    ("MANIF",24 ),
]

RSRC_LANGUAGE = [   

    ("unk", 0x0000),
    ("ar", 0x0001),
    ("bg", 0x0002),
    ("ca", 0x0003),
    ("zh-hans", 0x0004),
    ("cs", 0x0005),
    ("da", 0x0006),
    ("de", 0x0007),
    ("el", 0x0008),
    ("en", 0x0009),
    ("es", 0x000a),
    ("fi", 0x000b),
    ("fr", 0x000c),
    ("he", 0x000d),
    ("hu", 0x000e),
    ("is", 0x000f),
    ("it", 0x0010),
    ("ja", 0x0011),
    ("ko", 0x0012),
    ("nl", 0x0013),
    ("no", 0x0014),
    ("pl", 0x0015),
    ("pt", 0x0016),
    ("rm", 0x0017),
    ("ro", 0x0018),
    ("ru", 0x0019),
    ("hr", 0x001a),
    ("sk", 0x001b),
    ("sq", 0x001c),
    ("sv", 0x001d),
    ("th", 0x001e),
    ("tr", 0x001f),
    ("ur", 0x0020),
    ("id", 0x0021),
    ("uk", 0x0022),
    ("be", 0x0023),
    ("sl", 0x0024),
    ("et", 0x0025),
    ("lv", 0x0026),
    ("lt", 0x0027),
    ("tg", 0x0028),
    ("fa", 0x0029),
    ("vi", 0x002a),
    ("hy", 0x002b),
    ("az", 0x002c),
    ("eu", 0x002d),
    ("hsb", 0x002e),
    ("mk", 0x002f),
    ("st", 0x0030),
    ("ts", 0x0031),
    ("tn", 0x0032),
    ("ve", 0x0033),
    ("xh", 0x0034),
    ("zu", 0x0035),
    ("af", 0x0036),
    ("ka", 0x0037),
    ("fo", 0x0038),
    ("hi", 0x0039),
    ("mt", 0x003a),
    ("se", 0x003b),
    ("ga", 0x003c),
    ("yi,", 0x003d),
    ("ms", 0x003e),
    ("kk", 0x003f),
    ("ky", 0x0040),
    ("sw", 0x0041),
    ("tk", 0x0042),
    ("uz", 0x0043),
    ("tt", 0x0044),
    ("bn", 0x0045),
    ("pa", 0x0046),
    ("gu", 0x0047),
    ("or", 0x0048),
    ("ta", 0x0049),
    ("te", 0x004a),
    ("kn", 0x004b),
    ("ml", 0x004c),
    ("as", 0x004d),
    ("mr", 0x004e),
    ("sa", 0x004f),
    ("mn", 0x0050),
    ("bo", 0x0051),
    ("cy", 0x0052),
    ("km", 0x0053),
    ("lo", 0x0054),
    ("my", 0x0055),
    ("gl", 0x0056),
    ("kok", 0x0057),
    ("mni,", 0x0058),
    ("sd", 0x0059),
    ("syr", 0x005a),
    ("si", 0x005b),
    ("chr", 0x005c),
    ("iu", 0x005d),
    ("am", 0x005e),
    ("tzm", 0x005f),
    ("ks", 0x0060),
    ("ne", 0x0061),
    ("fy", 0x0062),
    ("ps", 0x0063),
    ("fil", 0x0064),
    ("dv", 0x0065),
    ("bin,", 0x0066),
    ("ff", 0x0067),
    ("ha", 0x0068),
    ("ibb,", 0x0069),
    ("yo", 0x006a),
    ("quz", 0x006b),
    ("nso", 0x006c),
    ("ba", 0x006d),
    ("lb", 0x006e),
    ("kl", 0x006f),
    ("ig", 0x0070),
    ("kr,", 0x0071),
    ("om", 0x0072),
    ("ti", 0x0073),
    ("gn", 0x0074),
    ("haw", 0x0075),
    ("la,", 0x0076),
    ("so,", 0x0077),
    ("ii", 0x0078),
    ("pap,", 0x0079),
    ("arn", 0x007a),
    ("moh", 0x007c),
    ("br", 0x007e),
    ("ug", 0x0080),
    ("mi", 0x0081),
    ("oc", 0x0082),
    ("co", 0x0083),
    ("gsw", 0x0084),
    ("sah", 0x0085),
    ("qut", 0x0086),
    ("rw", 0x0087),
    ("wo", 0x0088),
    ("prs", 0x008c),
    ("gd", 0x0091),
    ("ku", 0x0092),
    ("quc,", 0x0093),
("default", 0x0400),
("ar-sa", 0x0401),
("bg-bg", 0x0402),
("ca-es", 0x0403),
("zh-tw", 0x0404),
("cs-cz", 0x0405),
("da-dk", 0x0406),
("de-de", 0x0407),
("el-gr", 0x0408),
("en-us", 0x0409),
("es-es_tradnl", 0x040a),
("fi-fi", 0x040b),
("fr-fr", 0x040c),
("he-il", 0x040d),
("hu-hu", 0x040e),
("is-is", 0x040f),
("it-it", 0x0410),
("ja-jp", 0x0411),
("ko-kr", 0x0412),
("nl-nl", 0x0413),
("nb-no", 0x0414),
("pl-pl", 0x0415),
("pt-br", 0x0416),
("rm-ch", 0x0417),
("ro-ro", 0x0418),
("ru-ru", 0x0419),
("hr-hr", 0x041a),
("sk-sk", 0x041b),
("sq-al", 0x041c),
("sv-se", 0x041d),
("th-th", 0x041e),
("tr-tr", 0x041f),
("ur-pk", 0x0420),
("id-id", 0x0421),
("uk-ua", 0x0422),
("be-by", 0x0423),
("sl-si", 0x0424),
("et-ee", 0x0425),
("lv-lv", 0x0426),
("lt-lt", 0x0427),
("tg-cyrl-tj", 0x0428),
("fa-ir", 0x0429),
("vi-vn", 0x042a),
("hy-am", 0x042b),
("az-latn-az", 0x042c),
("eu-es", 0x042d),
("hsb-de", 0x042e),
("mk-mk", 0x042f),
("tn-za", 0x0432),
("xh-za", 0x0434),
("zu-za", 0x0435),
("af-za", 0x0436),
("ka-ge", 0x0437),
("fo-fo", 0x0438),
("hi-in", 0x0439),
("mt-mt", 0x043a),
("se-no", 0x043b),
("ms-my", 0x043e),
("kk-kz", 0x043f),
("ky-kg", 0x0440),
("sw-ke", 0x0441),
("tk-tm", 0x0442),
("uz-latn-uz", 0x0443),
("tt-ru", 0x0444),
("bn-in", 0x0445),
("pa-in", 0x0446),
("gu-in", 0x0447),
("or-in", 0x0448),
("ta-in", 0x0449),
("te-in", 0x044a),
("kn-in", 0x044b),
("ml-in", 0x044c),
("as-in", 0x044d),
("mr-in", 0x044e),
("sa-in", 0x044f),
("mn-mn", 0x0450),
("bo-cn", 0x0451),
("cy-gb", 0x0452),
("km-kh", 0x0453),
("lo-la", 0x0454),
("gl-es", 0x0456),
("kok-in", 0x0457),
("sd-deva-in", 0x0459),
("syr-sy", 0x045a),
("si-lk", 0x045b),
("chr-cher-us", 0x045c),
("iu-cans-ca", 0x045d),
("am-et", 0x045e),
("ne-np", 0x0461),
("fy-nl", 0x0462),
("ps-af", 0x0463),
("fil-ph", 0x0464),
("dv-mv", 0x0465),
("ha-latn-ng", 0x0468),
("yo-ng", 0x046a),
("quz-bo", 0x046b),
("nso-za", 0x046c),
("ba-ru", 0x046d),
("lb-lu", 0x046e),
("kl-gl", 0x046f),
("ig-ng", 0x0470),
("ti-et", 0x0473),
("haw-us", 0x0475),
("ii-cn", 0x0478),
("arn-cl", 0x047a),
("moh-ca", 0x047c),
("br-fr", 0x047e),
("ug-cn", 0x0480),
("mi-nz", 0x0481),
("oc-fr", 0x0482),
("co-fr", 0x0483),
("gsw-fr", 0x0484),
("sah-ru", 0x0485),
("quc-latn-gt", 0x0486),
("rw-rw", 0x0487),
("wo-sn", 0x0488),
("prs-af", 0x048c),
("gd-gb", 0x0491),
("ku-arab-iq", 0x0492),
("ar-iq", 0x0801),
("ca-es-valencia", 0x0803),
("zh-cn", 0x0804),
("de-ch", 0x0807),
("en-gb", 0x0809),
("es-mx", 0x080a),
("fr-be", 0x080c),
("it-ch", 0x0810),
("nl-be", 0x0813),
("nn-no", 0x0814),
("pt-pt", 0x0816),
("sr-latn-cs", 0x081a),
("sv-fi", 0x081d),
("ur-in", 0x0820),
("az-cyrl-az", 0x082c),
("dsb-de", 0x082e),
("tn-bw", 0x0832),
("se-se", 0x083b),
("ga-ie", 0x083c),
("ms-bn", 0x083e),
("uz-cyrl-uz", 0x0843),
("bn-bd", 0x0845),
("pa-arab-pk", 0x0846),
("ta-lk", 0x0849),
("mn-mong-cn", 0x0850),
("sd-arab-pk", 0x0859),
("iu-latn-ca", 0x085d),
("tzm-latn-dz", 0x085f),
("ff-latn-sn", 0x0867),
("quz-ec", 0x086b),
("ti-er", 0x0873),
("ti-er", 0x0873),
("ar-eg", 0x0c01),
("zh-hk", 0x0c04),
("de-at", 0x0c07),
("en-au", 0x0c09),
("es-es", 0x0c0a),
("fr-ca", 0x0c0c),
("sr-cyrl-cs", 0x0c1a),
("se-fi", 0x0c3b),
("quz-pe", 0x0c6b),
("ar-ly", 0x1001),
("zh-sg", 0x1004),
("de-lu", 0x1007),
("en-ca", 0x1009),
("es-gt", 0x100a),
("fr-ch", 0x100c),
("hr-ba", 0x101a),
("smj-no", 0x103b),
("tzm-tfng-ma", 0x105f),
("ar-dz", 0x1401),
("zh-mo", 0x1404),
("de-li", 0x1407),
("en-nz", 0x1409),
("es-cr", 0x140a),
("fr-lu", 0x140c),
("bs-latn-ba", 0x141a),
("smj-se", 0x143b),
("ar-ma", 0x1801),
("en-ie", 0x1809),
("es-pa", 0x180a),
("fr-mc", 0x180c),
("sr-latn-ba", 0x181a),
("sma-no", 0x183b),
("ar-tn", 0x1c01),
("en-za", 0x1c09),
("es-do", 0x1c0a),
("sr-cyrl-ba", 0x1c1a),
("sma-se", 0x1c3b),
("ar-om", 0x2001),
("en-jm", 0x2009),
("es-ve", 0x200a),
("bs-cyrl-ba", 0x201a),
("sms-fi", 0x203b),
("ar-ye", 0x2401),
("en-029", 0x2409),
("es-co", 0x240a),
("sr-latn-rs", 0x241a),
("smn-fi", 0x243b),
("ar-sy", 0x2801),
("en-bz", 0x2809),
("es-pe", 0x280a),
("sr-cyrl-rs", 0x281a),
("ar-jo", 0x2c01),
("en-tt", 0x2c09),
("es-ar", 0x2c0a),
("sr-latn-me", 0x2c1a),
("ar-lb", 0x3001),
("en-zw", 0x3009),
("es-ec", 0x300a),
("sr-cyrl-me", 0x301a),
("ar-kw", 0x3401),
("en-ph", 0x3409),
("es-cl", 0x340a),
("ar-ae", 0x3801),
("es-uy", 0x380a),
("ar-bh", 0x3c01),
("es-py", 0x3c0a),
("ar-qa", 0x4001),
("en-in", 0x4009),
("es-bo", 0x400a),
("en-my", 0x4409),
("es-sv", 0x440a),
("en-sg", 0x4809),
("es-hn", 0x480a),
("es-ni", 0x4c0a),
("es-pr", 0x500a),
("es-us", 0x540a),
("zh-cht", 0x7c04),
        ]


class Resource:
    def __init__(self, type, name, lang, rva, size):
        self.type = type
        self.name = name
        self.lang = lang
        self.rva = rva
        self.size = size


class PEAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.PROGRAM
    name = "PE"
    regexp = r"MZ.{58}+(?!\x00\x00\x00)...\x00"


    def __init__(self):
        FileTypeAnalyzer.__init__(self)
        self.regions = []                       # regions != sections, we may adjust the mapping for memory-mapped PEs
        for cat in ("", "VersionInfo"):
            self.metadata[cat] = OrderedDict()
        self.is64 = False
        self.architecture = bindings.FileType.X86
        self.ordinal_translator = OrdinalTranslator()
        self.resources = {}

    
    def rva2region(self, rva):
        for s in self.regions:
            if rva >= s.rva and rva < s.rva + s.vsize:
                return s

    def rva2off(self, rva):
        if not rva:
            return None
        for s in self.regions:
            if rva >= s.rva and rva < s.rva + s.vsize:
                delta = rva - s.rva
                if delta < s.fsize:
                    return s.foff + delta
        return None

    def off2rva(self, off):
        for s in self.regions:
            if off >= s.foff and off < s.foff + s.fsize:
                delta = off - s.foff
                if delta < s.fsize:
                    return s.rva + delta
        return None

    def va2off(self, va):
        if va < self.imagebase:
            return None
        return self.rva2off(va - self.imagebase)

    def off2va(self, off):
        rva = self.off2rva(off)
        if rva is None:
            return None
        return self.imagebase + rva


    def parse_exports(self, et_foff):
        self.jump(et_foff)
        expdir = yield ExportDirectory(name="ExportDirectory", category=Type.HEADER)
        name_rva = expdir["Name"]
        name_off = self.rva2off(name_rva)
        self.metadata["Exports"] = {}
        names_locations = []
        if name_off:
            name = self.read_cstring_ascii(name_off)
            if name:
                self.metadata["Exports"]["Module name"] = name
                names_locations.append((name_off, name_off + len(name) + 1))
        if int(expdir["TimeDateStamp"].timestamp()) not in (0, 0xffffffff):
            self.metadata["Exports"]["Exports date"] = expdir["TimeDateStamp"].strftime("%Y-%m-%d %H:%M:%S")
        nametable_off = self.rva2off(expdir["NameTable"])
        ordinaltable_off = self.rva2off(expdir["OrdinalTable"])
        addresstable_off = self.rva2off(expdir["AddressTable"])
        names = []
        ordinals = []
        addresses = []
        dd = self["OptionalHeader"]["DataDirectory"]
        if nametable_off:
            self.jump(nametable_off)
            names = yield Array(expdir["NameTableEntries"], Rva(hint=String(0, True)), name="ExportNameTable", category=Type.HEADER, parent=expdir)
        if ordinaltable_off:
            self.jump(ordinaltable_off)
            ordinals = yield Array(expdir["NameTableEntries"], UInt16(), name="OrdinalNameTable", category=Type.HEADER, parent=expdir)
        if addresstable_off:
            self.jump(addresstable_off)
            addresses = yield Array(expdir["AddressTableEntries"], Rva(), name="ExportAddressTable", category=Type.HEADER, parent=expdir)
        for i, name_rva in enumerate(names):
            name_off = self.rva2off(name_rva)
            if not name_off:
                continue
            name = self.read_cstring_ascii(name_off, 256)
            if not name:
                continue
            names_locations.append((name_off, name_off + len(name) + 1))
            if i >= len(ordinals):
                raise FatalError("Ordinal table smaller than export name table")
            ordinal = ordinals[i]
            address = addresses[ordinal]
            if address > dd[0]["Rva"] and address < dd[0]["Rva"] + dd[0]["Size"]:
                # forward
                dll_name_off = self.rva2off(address)
                if dll_name_off:
                    dll_name = self.read_cstring_ascii(dll_name_off)
                    if dll_name:
                        names_locations.append((dll_name_off, dll_name_off + len(dll_name) + 1))
                    self.symbols.append(bindings.FileSymbol(
                        self.imagebase + address,
                        bindings.FileSymbol.EXPORT,
                        "{}->{}".format(name, dll_name)))
            else:
                # add symbol
                self.symbols.append(bindings.FileSymbol(
                    self.imagebase + address,
                    bindings.FileSymbol.EXPORT,
                    name))
        # tag api names
        names_locations.sort()
        if names_locations:
            reported = None
            for i, location in enumerate(names_locations):
                start, end = location
                if i + 1 <len(names_locations) and abs(end - names_locations[i+1][0]) < 4:
                    if reported is None:
                        reported = start
                else:
                    if reported is not None:
                        start = reported
                        reported = None
                    self.jump(start)
                    yield Bytes(end - start, name="ExportNames", category=Type.DATA, comment="API names", parent=expdir)



    def parse_imports(self, iat_foff):
        self.jump(iat_foff)
        import_table = yield DynamicArray(lambda iid, count: iid["Name"] == 0 or iid["FirstThunk"] == 0 or count > MAX_DYNAMIC_STRUCTURE_LENGTH, ImageImportDescriptor(), name="ImportTable", category=Type.HEADER)
        if self.is64:
            rvaclass = Rva64
            ptrsize = 8
        else:
            rvaclass = Rva
            ptrsize = 4

        names_locations = []
        for i in range(import_table.count):
            iid = import_table[i]
            dll_name_foff = self.rva2off(iid["Name"])
            if dll_name_foff is not None:
                dll_name = self.read_cstring_ascii(dll_name_foff, 256).lower()
                names_locations.append((dll_name_foff, dll_name_foff + len(dll_name) + 1))
            else:
                continue
            dll_name = dll_name.split(".")[0].lower()
            if not dll_name: 
                continue
            oft_foff = self.rva2off(iid["OriginalFirstThunk"])
            ft_foff = self.rva2off(iid["FirstThunk"])
            namearray = None
            ptrarray = None
            if iid["OriginalFirstThunk"] and oft_foff is not None:
                self.jump(oft_foff)
                namearray = yield DynamicArray(lambda rva, count: rva == 0 or count > MAX_DYNAMIC_STRUCTURE_LENGTH, rvaclass(), name="{}.OFT".format(dll_name), category=Type.HEADER, parent=import_table)
                ptrarray = namearray
            if ft_foff is not None and ft_foff != oft_foff:
                self.jump(ft_foff)
                if namearray is not None:
                    max_elements = namearray.count
                else: 
                    max_elements = None
                try:
                    ptrarray = yield DynamicArray(lambda rva, count: rva == 0 or count > MAX_DYNAMIC_STRUCTURE_LENGTH, rvaclass(), max_elements=max_elements, name="{}.FT".format(dll_name), category=Type.HEADER, parent=import_table)
                except SuperposingError: pass
                if namearray is None:
                    namearray = ptrarray
            # build symbols
            if namearray is not None:
                for k, rva in enumerate(namearray):
                    if rva == 0:
                        break
                    if self.is64:
                        is_ordinal = (rva & 0x8000000000000000) != 0
                    else:
                        is_ordinal = (rva & 0x80000000) != 0
                    if rva and is_ordinal:
                        ordinal = rva & 0xffff
                        translation = self.ordinal_translator.translate(dll_name, ordinal)
                        if translation:
                            name = "{}.{}".format(dll_name, translation)
                        else:
                            name = "{}.#{}".format(dll_name, ordinal)
                    else:
                        off = self.rva2off(rva)
                        if off is None:
                            continue
                        api_name = self.read_cstring_ascii(off + 2, 256)
                        names_locations.append((off, off + 2 + len(api_name) + 1))
                        name = "{}.{}".format(dll_name, api_name)
                    self.symbols.append(bindings.FileSymbol(
                        self.imagebase + iid["FirstThunk"] + k * ptrsize,
                        bindings.FileSymbol.IMPORT,
                        name))

        # tag api names
        names_locations.sort()
        if names_locations:
            reported = None
            for i, location in enumerate(names_locations):
                start, end = location
                if i + 1 <len(names_locations) and abs(end - names_locations[i+1][0]) < 4:
                    if reported is None:
                        reported = start
                else:
                    if reported is not None:
                        start = reported
                        reported = None
                    self.jump(start)
                    yield Bytes(end - start, name="ImportNames", category=Type.DATA, comment="API names", parent=import_table)





    def parse_version(self, version_off, version_size, parent=None):
        self.jump(version_off)
        start = version_off
        yield VersionInfo(category=Type.META, parent=parent)
        if self.tell() < start + version_size:
            yield Unused(start + version_size - self.tell(), name="VER.Overlay", category=Type.ANOMALY, parent=parent)

    def open_rsrc(self, file):
        rsrc = self.resources[file.path]
        return self.read(self.rva2off(rsrc.rva), rsrc.size)

    def open_rsrc_net(self, file):
        rsrc = self.resources_net["/".join(file.path.split("/")[1:])]
        return self.read(self.rva2off(rsrc.rva), rsrc.size)

    def parse_resources_dir(self, rsrc_foff, lvl=0, rtype="", name="", lang="", parent=None, seen=None):
        if seen is None:
            seen = set()
        if self.tell() in seen:
            return
        # avoid some tricky recrusive resource dirs
        seen.add(self.tell())
        if lvl == 0:
            elem = yield ImageResourceDirectory(ImageResourceDirectoryEntry1, name="Resources", category=Type.HEADER, parent=parent)
        elif lvl == 1:
            elem = yield ImageResourceDirectory(ImageResourceDirectoryEntry2, name="Resources.{}".format(rtype), category=Type.HEADER, parent=parent)
        elif lvl == 2:
            elem = yield ImageResourceDirectory(ImageResourceDirectoryEntry3, name="Resources.{}.{}".format(rtype, name), category=Type.HEADER, parent=parent)
        elif lvl == 3:
            elem = yield ImageResourceDataEntry(name="Resources.{}.{}.{}".format(rtype, name, lang), category=Type.HEADER, parent=parent)
        else:
            return
        if lvl == 3:
            roff = self.rva2off(elem["OffsetToData"])
            rsize = min(elem["Size"], self.size() - (roff or 0))
            dataname = "Resources.{}.{}.{}.Data".format(rtype, name, lang)
            def pp(s):
                if type(s) == int:
                    return "#{:d}".format(s)
                else:
                    return s.replace("/", "\\")
            filename = "/".join(map(pp, [rtype, name, lang]))
            self.resources[filename] = Resource(rtype, name, lang, elem["OffsetToData"], elem["Size"])
            if rsize > 0 and roff is not None and roff + rsize <= self.size():
                self.jump(roff)
                before = self.tell()
                try:
                    if rtype == "VER":
                        yield from self.parse_version(roff, rsize, parent=elem)
                    elif rtype == "MANIF":
                        yield Bytes(rsize, name="Manifest", category=Type.META, parent=elem)
                    elif rtype == "RCDATA" and name == "PACKAGEINFO":
                        pinfo = yield PackageInfo(rsize, name="PackageInfo", category=Type.META, parent=elem)
                        if "UnitInfo" in pinfo:
                            first_unit = pinfo[2]
                            if "Name" in first_unit:
                                self.metadata["Delphi"] = { "ProjectName" : first_unit["Name"] }
                    else:
                        yield Bytes(rsize, name=dataname, category=Type.RESOURCE, parent=elem)
                except SuperposingError: 
                    pass  # some resources are references in more than one directory 
                except ParsingError as e:
                    print(e)
                    if self.tell() - before < rsize:
                        yield Bytes(rsize - (self.tell() - before), name=dataname, category=Type.RESOURCE, parent=elem)
                if self.tell() > before:
                    self.files.append(bindings.VirtualFile(filename, self.tell() - before, "open_rsrc"))
            else:
                pass
        else:
            for sub in elem["DirectoryEntries"]:
                try:
                    if lvl == 0:
                        field = sub.Type
                    elif lvl == 1:
                        field = sub.Name
                    else:
                        field = sub.Language
                    rid = field.value
                    if (rid & 0x80000000) != 0:
                        noff = rsrc_foff + (rid & 0x7fffffff)
                        try:
                            self.jump(noff)
                        except OutOfBoundError:
                            print("Invalid resource name offset: {:x} for {}".format(noff, elem.name))
                            continue
                        irds = yield ImageResourceDirString(name="ResourceName", category=Type.HEADER, parent=elem)
                        strdata = irds["NameString"]
                        sub_name = ""
                        for c in strdata:
                            sub_name += chr(c & 0x7F)
                    else:
                        if field.has_enum and field.enum:
                            sub_name = field.enum
                        else:
                            sub_name = str(field.value)
                    if lvl == 0:
                        rtype = sub_name
                    elif lvl == 1:
                        name = sub_name
                    elif lvl == 2:
                        lang = sub_name
                    data = sub["OffsetToData"]
                    is_subdir = (data & 0x80000000) != 0
                    dataoff = rsrc_foff + (data & 0x7fffffff)
                    if dataoff and dataoff < self.size():
                        self.jump(dataoff)
                        #if is_subdir:
                        yield from self.parse_resources_dir(rsrc_foff, lvl+1, rtype, name, lang, elem, seen)
                    else:
                        print("Invalid resource entry offset: {:x} .. skipping".format(dataoff))
                except SuperposingError:
                    continue


    def parse_certificates(self, cert_foff, cert_size):
        try:
            import pyasn1
            from pyasn1.codec.der.decoder import decode
            from pyasn1_modules import rfc2315, rfc2459, rfc2437
            has_pyasn1 = True
        except ImportError:
            has_pyasn1 = False
            print("pyasn1 not installed: no certificate parsing")

        if has_pyasn1:
            class MemoryDerDecoder(pyasn1.codec.der.decoder.Decoder):
                def __call__(self,*v,**kw):
                    try:
                        parsed,remainder = pyasn1.codec.der.decoder.Decoder.__call__(self,*v,**kw)
                    except Exception as e:
                        raise FatalError(e)
                    parsed._substrate = v[0][:len(v[0])-len(remainder)]
                    return parsed,remainder
            decode = MemoryDerDecoder(pyasn1.codec.der.decoder.tagMap, pyasn1.codec.der.decoder.typeMap)

        certs_meta = []
        self.jump(cert_foff)
        while self.tell() < cert_foff + cert_size:
            cert = yield CertificateEntry(name="Certificate", category=Type.META)
            meta = OrderedDict()
            if cert["CertificateType"] == 2 and has_pyasn1:
                SUPPORTED_ATTRIBUTES = {
                        rfc2459.id_at_countryName: ("Country", rfc2459.X520countryName),
                        rfc2459.id_at_organizationName: ("Organization", rfc2459.X520OrganizationName),
                        rfc2459.id_at_organizationalUnitName: ("Unit", rfc2459.X520OrganizationalUnitName),
                        rfc2459.id_at_commonName: ("CommonName", rfc2459.X520CommonName),
                }
                ALGORITHMS = {
                       "1.2.840.113549.2.5" : "MD5",
                       "1.3.14.3.2.26" : "SHA1",
                       "2.16.840.1.101.3.4.2.1" : "SHA256",
                       "2.16.840.1.101.3.4.2.2" : "SHA384",
                       "2.16.840.1.101.3.4.2.3" : "SHA512",
                       "2.16.840.1.101.3.4.2.4" : "SHA224",
                       "2.16.840.1.101.3.4.2.5" : "SHA512-224",
                       "2.16.840.1.101.3.4.2.6" : "SHA512-256",
                       "1.2.840.113549.1.1.1" : "RSA",
                       "1.2.840.113549.1.1.2" : "MD2/RSA",
                       "1.2.840.113549.1.1.3" : "MD4/RSA",
                       "1.2.840.113549.1.1.4" : "MD5/RSA",
                       "1.2.840.113549.1.1.5" : "SHA1/RSA",
                       "1.2.840.113549.1.1.6" : "OEP/RSA",
                       "1.2.840.113549.1.1.7" : "OEPAES/RSA",
                       "1.2.840.113549.1.1.8" : "MGF1/RSA",
                       "1.2.840.113549.1.1.9" : "PSPEC/RSA",
                       "1.2.840.113549.1.1.10" : "PSS/RSA",
                       "1.2.840.113549.1.1.11" : "SHA256/RSA",
                       "1.2.840.113549.1.1.12" : "SHA384/RSA",
                       "1.2.840.113549.1.1.13" : "SHA512/RSA",
                       "1.2.840.113549.1.1.14" : "SHA224/RSA",
                       "1.2.840.10045.2.1" : "ECDSA",
                       "1.2.840.10045.4.1" : "SHA1/ECDSA",
                       "1.2.840.10045.4.2" : "SHA/ECDSA",
                       "1.2.840.10045.4.3" : "SHA2/ECDSA",
                       "1.2.840.10045.4.3.1" : "SHA224/ECDSA",
                       "1.2.840.10045.4.3.2" : "SHA256/ECDSA",
                       "1.2.840.10045.4.3.3" : "SHA384/ECDSA",
                       "1.2.840.10045.4.3.4" : "SHA512/ECDSA",
                       "1.2.840.10040.4.1" : "DSA",
                       "1.2.840.10040.4.2" : "DSA",
                       "1.2.840.10040.4.3" : "SHA1/DSA",
                }
                contentInfo, rest = decode(cert["Data"], asn1Spec=rfc2315.ContentInfo())
                contentType = contentInfo.getComponentByName('contentType')
                if contentType == rfc2315.signedData:  
                    signedData = decode(contentInfo.getComponentByName('content'), asn1Spec=rfc2315.SignedData())
                    for certificate in signedData:
                        if not certificate:
                            continue
                        signerInfos = certificate.getComponentByName('signerInfos')
                        signer_infos = {}
                        serial = None
                        before = None
                        after = None
                        subject_infos = {}
                        digest_algorithm = None
                        digest_encryption_algorithm = None
                        for si in signerInfos:
                            if not si:
                                continue
                            issuerAndSerial = si.getComponentByName('issuerAndSerialNumber')
                            serial = issuerAndSerial.getComponentByName('serialNumber')._substrate.asOctets()[2:].hex()
                            issuer = issuerAndSerial.getComponentByName('issuer').getComponent()
                            for issuer_info in issuer:
                                for field in issuer_info:
                                    at = field.getComponentByName('type')                       
                                    value = field.getComponentByName('value')                     
                                    sup = SUPPORTED_ATTRIBUTES.get(at, None)
                                    if sup is not None:
                                        name, spec = sup
                                        dec_value = decode(value, asn1Spec=spec())[0]
                                        if hasattr(dec_value, "getComponent"):
                                            dec_value = dec_value.getComponent()
                                        signer_infos[name] = str(dec_value)
                            if "digestAlgorithm" in si:
                                digestAlgorithm = si.getComponentByName('digestAlgorithm')
                                digest_algorithm = str(digestAlgorithm.getComponentByName("algorithm"))
                            if "digestEncryptionAlgorithm" in si:
                                digestAlgorithm = si.getComponentByName('digestEncryptionAlgorithm')
                                digest_encryption_algorithm = str(digestAlgorithm.getComponentByName("algorithm"))
                        chain = certificate.getComponentByName('certificates')
                        for cert in chain:
                            tbs = cert.getComponentByName("certificate").getComponentByName("tbsCertificate")
                            chain_serial = tbs.getComponentByName('serialNumber')._substrate.asOctets()[2:].hex()
                            if chain_serial == serial:
                                # get extra infos about issuer
                                for issuer_info in tbs.getComponentByName('issuer').getComponent():
                                    for field in issuer_info:
                                        at = field.getComponentByName('type')                       
                                        value = field.getComponentByName('value')                     
                                        sup = SUPPORTED_ATTRIBUTES.get(at, None)
                                        if sup is not None:
                                            name, spec = sup
                                            dec_value = decode(value, asn1Spec=spec())[0]
                                            if hasattr(dec_value, "getComponent"):
                                                dec_value = dec_value.getComponent()
                                            signer_infos[name] = str(dec_value)
                                t = tbs.getComponentByName('validity').getComponentByName("notBefore")
                                if t.getName() == "utcTime":
                                    try:
                                        before = datetime.datetime.strptime(str(t.getComponent())[:-1], "%y%m%d%H%M%S")
                                    except:
                                        before = datetime.datetime.strptime(str(t.getComponent())[:-1], "%y%m%d%H%M")
                                t = tbs.getComponentByName('validity').getComponentByName("notAfter")
                                if t.getName() == "utcTime":
                                    try:
                                        after = datetime.datetime.strptime(str(t.getComponent())[:-1], "%y%m%d%H%M%S")
                                    except:
                                        after = datetime.datetime.strptime(str(t.getComponent())[:-1], "%y%m%d%H%M")

                                # get extra infos about subject
                                for info in tbs.getComponentByName("subject")[0]:
                                    info = info[0]
                                    at = info.getComponentByName('type')                       
                                    value = info.getComponentByName('value')                     
                                    sup = SUPPORTED_ATTRIBUTES.get(at, None)
                                    if sup is not None:
                                        name, spec = sup
                                        dec_value = decode(value, asn1Spec=spec())[0]
                                        if hasattr(dec_value, "getComponent"):
                                            dec_value = dec_value.getComponent()
                                        subject_infos[name] = str(dec_value)
                        if signer_infos:
                            meta["Issuer"] = "{} ({} / {} / {})".format(
                                    signer_infos.get("CommonName", "???"), 
                                    signer_infos.get("Organization", "???"), 
                                    signer_infos.get("Unit", "???"), 
                                    signer_infos.get("Country", "???"))
                        if subject_infos:
                            meta["Subject"] = "{} ({} / {} / {})".format(
                                    subject_infos.get("CommonName", "???"), 
                                    subject_infos.get("Organization", "???"), 
                                    subject_infos.get("Unit", "???"), 
                                    subject_infos.get("Country", "???"))
                        if before is not None and after is not None:
                            meta["Validity"] = "from {} to {}".format(before.strftime("%Y-%m-%d"), after.strftime("%Y-%m-%d"))
                        if serial:
                            meta["SerialNumber"] = serial
                        if digest_algorithm in ALGORITHMS:
                            meta["HashAlgorithm"] = ALGORITHMS[digest_algorithm]
                        if digest_encryption_algorithm in ALGORITHMS:
                            meta["CryptAlgorithm"] = ALGORITHMS[digest_encryption_algorithm]
            certs_meta.append(meta)
        if certs_meta:
            if len(certs_meta) == 1:
                self.metadata["Certificate"] = certs_meta[0]
            else:
                self.metadata["Certificates"] = OrderedDict()
                for i, meta in enumerate(certs_meta):
                    for k,v in meta.items():
                        self.metadata["Certificates"]["Cert[{}].{}".format(i, k)] = v
        if self.tell() > cert_foff + cert_size:
            raise FatalError("Invalide certificates size")


    def parse_debug(self, dbg_foff, dbg_size):
        self.jump(dbg_foff)
        dd = yield DebugDirectory(category=Type.DEBUG)
        dbg_meta = OrderedDict()
        if dd["TimeDateStamp"].timestamp() > 0 and dd["TimeDateStamp"].timestamp() < 0xffffffff:
            dbg_meta["Date"] = dd["TimeDateStamp"].strftime("%Y-%m-%d %H:%M:%S")
        if dd["Type"] == 2 and dd["PointerToRawData"]:
            self.jump(dd["PointerToRawData"])
            sig = self.read(dd["PointerToRawData"], 4)
            if sig == b"RSDS":
                # CVINFO_PDB70_CVSIGNATURE
                cv = yield CVInfoPdb70(category=Type.DEBUG)
                dbg_meta["Path"] = cv["Path"]
            elif sig == b"NB10":
                # CVINFO_PDB20_CVSIGNATURE
                cv = yield CVInfoPdb20(category=Type.DEBUG)
                dbg_meta["Path"] = cv["Path"]
        if dbg_meta:
            self.metadata["Debug"] = dbg_meta

    def parse_load_config(self, lc_foff, lc_size):
        self.jump(lc_foff)
        lct = yield LoadConfigurationTable()
        off = self.va2off(lct["SecurityCookie"])
        if off:
            self.jump(off)
            if self.is64:
                yield UInt64(name="SecurityCookie", parent=lct, category=Type.DEBUG)
            else:
                yield UInt32(name="SecurityCookie", parent=lct, category=Type.DEBUG)
        if lct["SEHandlerCount"]:
            off = self.va2off(lct["SEHandlerTable"])
            if off:
                self.jump(off)
                handlers = yield Array(lct["SEHandlerCount"], Rva(), name="SEHandlers", parent=lct, category=Type.HEADER)
                for i, handler in enumerate(filter(None, handlers)):
                    self.symbols.append(bindings.FileSymbol(
                        self.imagebase + handler,
                        bindings.FileSymbol.FUNCTION,
                        "SEH.{}".format(i)))
        for ptr in ("GuardCFCheckFunctionPointer", "GuardCFDispatchFunctionPointer"):
            if ptr in lct and lct[ptr]:
                off = self.va2off(lct[ptr])
                if off:
                    self.jump(off)
                    if self.is64:
                        va = yield Va64(name=ptr, parent=lct, category=Type.HEADER)
                    else:
                        va = yield Va32(name=ptr, parent=lct, category=Type.HEADER)
                    if va:
                        self.symbols.append(bindings.FileSymbol(
                            va,
                            bindings.FileSymbol.FUNCTION,
                            ptr.replace("Pointer", "")))






    def parse_tls(self, tls_foff, tls_size):
        self.jump(tls_foff)
        dd = yield TlsDirectory(category=Type.HEADER)
        arrayoff = self.va2off(dd["RawDataStart"])
        arraysize = dd["RawDataEnd"] - dd["RawDataStart"]
        if arraysize > 0 and arrayoff:
            self.jump(arrayoff)
            yield Bytes(arraysize, name="TLSInitArray", category=Type.FIXUP, parent=dd)
        if dd["CallbacksAddress"]:
            cb_off = self.va2off(dd["CallbacksAddress"])
            if cb_off:
                self.jump(cb_off)
                if self.is64:
                    ptr = Va64
                else:
                    ptr = Va32
                cbs = yield DynamicArray(lambda p, count: p == 0 or count > MAX_DYNAMIC_STRUCTURE_LENGTH, ptr(), name="TlsCallbacks", category=Type.FIXUP, parent=dd)
                for i in range(cbs.count - 1):
                    if cbs[i]:
                        self.symbols.append(bindings.FileSymbol(
                        cbs[i],
                        bindings.FileSymbol.ENTRY,
                        "TLS.{}".format(i)))


    def parse_exception(self, exc_foff, exc_size):
        self.jump(exc_foff)
        it = Array(0, (), name="ExceptionTable", category=Type.FIXUP)
        # todo: check for other arch
        etype = ExceptionEntryX64
        esize = 12
        exception_table = yield Array(exc_size // esize, etype(), name="ExceptionTable", category=Type.DEBUG)
        

                        

    def parse_delay(self, delay_foff, delay_size):
        self.jump(delay_foff)
        use_rva = (self.read(delay_foff, 1)[0] & 1) != 0    # best effort for the GUI: assume all entries have same attributes
        delay_table = yield DynamicArray(lambda iid, count: iid["Name"] == 0 or iid["AddressTable"] == 0 or count > MAX_DYNAMIC_STRUCTURE_LENGTH, DelayImportDescriptor(use_rva), name="DelayImportTable", category=Type.HEADER)
        for delay in delay_table:
            use_rva = delay["Attributes"]["UseRva"]
            name = delay["Name"]
            if self.is64:
                ptr = Va64
            else:
                ptr = Va32
            if not name:
                continue
            if use_rva:
                dll_name_foff = self.rva2off(name)
            else:
                dll_name_foff = self.va2off(name)
            if dll_name_foff is not None:
                dll_name = self.read_cstring_ascii(dll_name_foff, 256).lower()
            else:
                dll_name = "???"
            dll_name = dll_name.split(".")[0].lower()
            address_table = self.rva2off(delay["AddressTable"])
            if use_rva:
                name_table = self.rva2off(delay["NameTable"])
            else:
                name_table = self.va2off(delay["NameTable"])
            if name_table:
                self.jump(name_table)
                names = yield DynamicArray(lambda x, count: x == 0 or count > MAX_DYNAMIC_STRUCTURE_LENGTH, Rva(), name="{}.Names".format(dll_name), parent=delay_table, category=Type.HEADER)
            else:
                names = None
            if address_table:
                self.jump(address_table)
                if names is not None:
                    addresses = yield Array(names.count - 1, ptr(), name="{}.Addresses".format(dll_name), parent=delay_table, category=Type.HEADER)
                else:
                    addresses = yield DynamicArray(lambda x, count: x == 0 or count > MAX_DYNAMIC_STRUCTURE_LENGTH, ptr(), name="{}.Addresses".format(dll_name), parent=delay_table, category=Type.HEADER)
            if name_table and address_table:
                for i, pointer in enumerate(addresses):
                    if i >= names.count or pointer == 0 or pointer == 0xffffffff:
                        continue
                    if names[i] & 0x80000000:
                        ordinal = names[i] & 0xffff
                        translation = self.ordinal_translator.translate(dll_name, ordinal)
                        if translation:
                            apiname = translation
                        else:
                            apiname = "#{}".format(ordinal)
                    else:
                        off = self.rva2off(names[i])
                        if off is None:
                            apiname = "delay#{}".format(i)
                        else:
                            apiname = self.read_cstring_ascii(off + 2, 256)
                    if pointer:
                        self.symbols.append(bindings.FileSymbol(
                            pointer,
                            bindings.FileSymbol.FUNCTION,
                            "{}.{} (delaystub)".format(dll_name, apiname)))
                    va = self.off2va(addresses.at(i).offset)
                    if va:
                        self.symbols.append(bindings.FileSymbol(
                            va,
                            bindings.FileSymbol.IMPORT,
                            "{}.{} (delayed)".format(dll_name, apiname)))


    def parse_rich(self):
        off = self["PE"].offset - 8
        rich_size = 0
        rich_off = None
        while off > 0 and rich_size == 0:
            rich = self.read(off, 4)
            xor, = struct.unpack("<I", self.read(off + 4, 4))
            if rich == b"Rich":
                rich_off = off - 16
                # find "Dans"
                while rich_off > 0 and rich_size == 0:
                    dans, = struct.unpack("<I", self.read(rich_off, 4))
                    dans = dans ^ xor
                    if dans == 0x536e6144:
                        rich_size = off + 8 - rich_off
                        break
                    rich_off -= 8
            off -= 4
        if rich_size:
            self.jump(rich_off)
            yield RichHeader(xor, rich_size, name="Rich", category=Type.META)

    def is_import_table_valid_looking(self):
        # heuristik
        if len(self["OptionalHeader"]["DataDirectory"]) >= 2:
            off = self.rva2off(self["OptionalHeader"]["DataDirectory"][1]["Rva"])
            if off is None:
                return False
            i = 0
            ends_with_dll = 0
            while i < 512:
                oft, tds, fc, name, ft = struct.unpack("<IIIII", self.read(off, 0x14))
                off += 0x14
                if oft == 0 and ft == 0 and name == 0:
                    break
                if oft and self.rva2off(oft) is None:
                    return False
                if ft and self.rva2off(ft) is None:
                    return False
                name_off = self.rva2off(name)
                if name_off is None:
                    return False
                dll_name = self.read_cstring_ascii(name_off)
                if dll_name and dll_name.lower().endswith(".dll"):
                    ends_with_dll += 1
                i += 1
            if not ends_with_dll:
                return False
        return True

    def parse(self, hint):
        # some packers put the PE header inside the MZ header. Since malcat does not 
        # support intricated structure, we just skip the MZ header in this case
        pe_offset, = struct.unpack("<I", self.read(0x3c, 4))
        if pe_offset >= 0x40:
            yield MZ(category=Type.HEADER)
        self.jump(pe_offset)
        pe = yield PE(category=Type.HEADER)
        self.metadata[""]["Compile date"] = pe["TimeDateStamp"].strftime("%Y-%m-%d %H:%M:%S")
        magic, = struct.unpack("<H", self.read(self.tell(), 2))
        self.is64 = magic == 0x020B
        if self.is64:
            optheader = yield OptionalHeader64(name="OptionalHeader", category=Type.HEADER)
            self.architecture = bindings.FileType.X64
        else:
            optheader = yield OptionalHeader32(name="OptionalHeader", category=Type.HEADER)
        self.imagebase = optheader["ImageBase"]
        if optheader["AddressOfEntryPoint"]:
            # handle engative rva done by some memory dumpers
            ep, = struct.unpack("<i", struct.pack("<I",  optheader["AddressOfEntryPoint"]))
            self.symbols.append(bindings.FileSymbol(
                self.imagebase + ep,
                bindings.FileSymbol.ENTRY,
            "EntryPoint"))
        section_table_offset = pe_offset + pe["SizeOfOptionalHeader"] + 0x18
        self.jump(section_table_offset)
        sections = yield Array(pe["NumberOfSections"], Section(), name="Sections", category=Type.HEADER)

        file_align = optheader["FileAlignment"]
        mem_align = optheader["SectionAlignment"]
        imagesize = optheader["SizeOfImage"]

        eof_header = align(self.tell(), mem_align)

        # map regions
        for s in sections:
            phys_start = align(s["PointerToRawData"], min(512, file_align), down=True)
            phys_size = align(s["SizeOfRawData"], file_align)
            rva_start = align(s["VirtualAddress"], mem_align, down=True)
            virt_size = align(s["VirtualSize"], mem_align)
            if (phys_size or virt_size) and phys_start < self.size():
                # handle negative rvas, some memory dumper do this
                srva, = struct.unpack("<i", struct.pack("<I", rva_start))
                r = Region(srva, virt_size, phys_start, phys_size, s)
                self.regions.append(r)
                
        # handle overlapping
        self.regions = sorted(self.regions, key=lambda x: x.foff)
        for i in range(len(self.regions)):
            cur = self.regions[i]
            if cur.foff + cur.fsize > self.size():
                cur.fsize = self.size() - cur.foff
            if i:
                prev = self.regions[i-1]
                if prev.foff + prev.fsize > cur.foff:
                    prev.fsize = cur.foff - prev.foff
        self.regions = sorted(self.regions, key=lambda x: x.rva)
        for i in range(len(self.regions)):
            cur = self.regions[i]
            if cur.rva < imagesize and cur.rva + cur.vsize > imagesize:
                cur.vsize = imagesize - cur.rva
            if i:
                prev = self.regions[i-1]
                if prev.rva + prev.vsize > cur.rva:
                    prev.vsize = cur.rva - prev.rva
        self.regions = [x for x in self.regions if x.fsize or x.vsize]

        # check if memory-mapped PE (stupid heuristic)
        try:
            old_regions = self.regions
            if not self.is_import_table_valid_looking() and optheader["DataDirectory"][1]["Rva"]:
                # try mapping virtual->physical
                old_regions = self.regions
                self.regions = []
                for r in old_regions:
                    self.regions.append(Region(r.rva, r.vsize, r.rva, r.vsize, r.section))
                if not self.is_import_table_valid_looking():
                    self.regions = old_regions
                else:
                    print("Memory-mapped PE")
        except: 
            self.regions = old_regions

        # map regions
        for r in self.regions:
            sname = r.section["Name"]
            si = sname.find("\x00")
            if si >= 0:
                sname = sname[:si]
            self.sections.append(bindings.Section(
                r.foff, r.fsize,
                max(0, self.imagebase + r.rva), r.vsize,
                sname,
                r.section["Characteristics"]["MemRead"],
                r.section["Characteristics"]["MemWrite"],
                r.section["Characteristics"]["MemExecute"],
                r.section["Characteristics"]["MemDiscardable"],
                )
            )
        if sections.count == 0:
            raise FatalError("No section")

        self.confirm()
        
        dd = optheader["DataDirectory"]
        # rsrc
        if dd.count > 2:
            rsrc_foff = self.rva2off(dd[2]["Rva"])
            if rsrc_foff is not None:
                self.jump(rsrc_foff)
                try:
                    yield from self.parse_resources_dir(rsrc_foff)
                except ParsingError as e: print(e)
        # reloc
        if dd.count > 5:
            reloc_foff = self.rva2off(dd[5]["Rva"])
            if reloc_foff is not None:
                self.jump(reloc_foff)
                try:
                    yield Relocations(category=Type.FIXUP)
                except ParsingError: pass
        # imports
        if dd.count > 1:
            iat_foff = self.rva2off(dd[1]["Rva"])
            if iat_foff is not None:
                try:
                    yield from self.parse_imports(iat_foff)
                except ParsingError as e: print(e)
        # exports
        if dd.count > 0:
            et_foff = self.rva2off(dd[0]["Rva"])
            if et_foff is not None:
                try:
                    yield from self.parse_exports(et_foff)
                except ParsingError: pass

        # certificates
        if dd.count > 4:
            cert_foff = dd[4]["Rva"]
            cert_size = dd[4]["Size"]
            if cert_foff and cert_size:
                try:
                    yield from self.parse_certificates(cert_foff, cert_size)
                except ParsingError: pass

        # debug
        if dd.count > 6:
            dbg_foff = self.rva2off(dd[6]["Rva"])
            if dbg_foff is not None:
                try:
                    yield from self.parse_debug(dbg_foff, dd[6]["Size"])
                except ParsingError: pass

        # architecture / copyright
        if dd.count > 7:
            cr_foff = self.rva2off(dd[7]["Rva"])
            cr_size = dd[7]["Size"]
            if cr_foff is not None and cr_size and cr_foff + cr_size < self.size():
                self.jump(cr_foff)
                s = yield String(cr_size, zero_terminated=True, name="Copyright", category=Type.META)
                if s:
                    self.metadata["Copyright"] = s

        # tls
        if dd.count > 9:
            tls_foff = self.rva2off(dd[9]["Rva"])
            if tls_foff is not None:
                try:
                    yield from self.parse_tls(tls_foff, dd[9]["Size"])
                except ParsingError: pass

        # load config
        if dd.count > 10:
            lc_foff = self.rva2off(dd[10]["Rva"])
            if lc_foff is not None:
                try:
                    yield from self.parse_load_config(lc_foff, dd[10]["Size"])
                except IOError: pass                

        # delay
        if dd.count > 13:
            delay_foff = self.rva2off(dd[13]["Rva"])
            if delay_foff is not None:
                try:
                    yield from self.parse_delay(delay_foff, dd[13]["Size"])
                except ParsingError: pass

        # exceptions
        if dd.count > 3:
            exc_foff = self.rva2off(dd[3]["Rva"])
            if exc_foff is not None:
                try:
                    yield from self.parse_exception(exc_foff, dd[3]["Size"])
                except ParsingError: pass

        # rich header
        try:
            yield from self.parse_rich()
        except ParsingError: pass


        self.confirm()
        # vb parsing
        try:
            from filetypes.PE_vb import parse_vb
            yield from parse_vb(self)
        except ParsingError as e: print(e)

        # net parsing
        try:
            from filetypes.PE_net import parse_net
            yield from parse_net(self)
        except ParsingError as e: print(e)

        # golang parsing
        try:
            from filetypes.PE_golang import parse_golang
            yield from parse_golang(self)
        except ParsingError: pass


