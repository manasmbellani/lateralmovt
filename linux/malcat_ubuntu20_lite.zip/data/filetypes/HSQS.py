from filetypes.base import *
import bindings
from transforms import compress


#https://dr-emann.github.io/squashfs/

class SuperBlock(Struct):

    def parse(self):
        yield String(4, zero_terminated=False, name="Magic")
        yield UInt32(name="InodeCount", comment="number of inodes stored in the inode table")
        yield Timestamp(name="ModificationTime", comment="when the archive was created (or last appended to)")
        bs = yield UInt32(name="BlockSize", comment="size of a data block in bytes. Must be a power of two between 4096 and 1048576 (1 MiB)")
        if bs % 4096:
            raise FatalError
        yield UInt32(name="FragmentCount", comment="number of entries in the fragment table")
        yield UInt16(name="Compression", comment="compression method used", values=[
            ("GZIP", 1),
            ("LZMA", 2),
            ("LZO", 3),
            ("XZ", 4),
            ("LZ4", 5),
            ("ZSTD", 6),
            ])
        bl = yield UInt16(name="BlockLog", comment="log2 of block_size. If block_size and block_log do not agree, the archive is considered corrupt")
        if bs != pow(2, bl):
            raise FatalError("Block log and block size do not agree")
        flags = yield BitsField(
            Bit(name="UncompressedInodes", comment="inodes are stored uncompressed. For backward compatibility reasons, UID/GIDs are also stored uncompressed"),
            Bit(name="UncompressedData", comment="data is stored uncompressed"),
            Bit(name="Check", comment="unused in squashfs 4+. Should always be unset"),
            Bit(name="UncompressedFragments", comment="fragments are stored uncompressed"),
            Bit(name="NoFragments", comment="fragments are not used. Files smaller than the block size are stored in a full block"),
            Bit(name="AlwaysFragments", comment="if the last block of a file is smaller than the block size, it will be instead stored as a fragment"),
            Bit(name="Duplicates", comment="identical files are recognized, and stored only once"),
            Bit(name="Exportable", comment="filesystem has support for export via NFS (the export table is populated)"),
            Bit(name="UncompressedXattrs", comment="Xattrs are stored uncompressed"),
            Bit(name="NoXattrs", comment="Xattrs are not stored"),
            Bit(name="CompressorOptions", comment="the compression options section is present"),
            Bit(name="UncompressedIds", comment="UID/GIDs are stored uncompressed. Note that the UNCOMPRESSED_INODES flag also has this effect. If that flag is set, this flag has no effect. This flag is currently only available on master in git, no released version of squashfs yet supports it"),
            name="Flags")
        yield UInt16(name="IdCount", comment="number of entries in the id lookup table")
        m = yield UInt16(name="VersionMajor", comment="major version of the squashfs file format. Should always equal 4")
        if m != 4:
            raise FatalError("Version")
        m = yield UInt16(name="VersionMinor", comment="major version of the squashfs file format. Should always equal 0")
        if m != 0:
            raise FatalError("Version")
        yield UInt64(name="RootInodeRef", comment="reference to the inode of the root directory of the archive")
        yield UInt64(name="BytesUsed", comment="number of bytes used by the archive. Because squashfs archives are often padded to 4KiB, this can often be less than the file size")
        yield Offset64(name="IdTableStart", comment="byte offset at which the id table starts")
        yield Offset64(name="XattrIdTableStart", comment="byte offset at which the xattr id table starts")
        yield Offset64(name="InodeTableStart", comment="byte offset at which the inode table starts")
        yield Offset64(name="DirectoryTableStart", comment="byte offset at which the directory table starts")
        yield Offset64(name="FragmentTableStart", comment="byte offset at which the fragment table starts")
        yield Offset64(name="ExportTableStart", comment="byte offset at which the export table starts")


class MetadataBlock(Struct):

    def parse(self):
        sz = yield UInt16(name="Size")
        sz = sz & 0x7fff
        yield Bytes(sz, name="Data")


class Metadata(Struct):

    def __init__(self, *args, max_size=0, max_blocks=0, **kwargs):
        Struct.__init__(self, *args, **kwargs)
        self.max_size = max_size
        self.max_blocks = max_blocks
        if not (max_size or max_blocks):
            raise ValueError

    def parse(self):
        iblock = 0
        while True:
            mb = yield MetadataBlock(name="Block")
            iblock += 1
            if self.max_blocks and iblock >= self.max_blocks:
                break
            elif self.max_size and len(self) >= self.max_size:
                break



class GzipCompressionOptions(Struct):

    def parse(self):
        yield UInt32(name="CompressionLevel", comment="should be in range [1,9]")
        yield UInt16(name="WindowSize", comment="should be in range [8,15]")
        yield BitsField(
            Bit(name="Default"),
            Bit(name="Filtered"),
            Bit(name="Huffman Only"),
            Bit(name="Run Length Encoded"),
            Bit(name="Fixed"),
            NullBits(9),
            name="Strategies")

class XzCompressionOptions(Struct):

    def parse(self):
        yield UInt32(name="DictionnarySize", comment="should be > 8KiB, and must be either the sum of a power of two, or the sum of two sequential powers of two")
        yield BitsField(
            Bit(name="x86"),
            Bit(name="powerpc"),
            Bit(name="ia64"),
            Bit(name="arm"),
            Bit(name="arthumb"),
            Bit(name="sparc"),
            NullBits(26),
            name="Filters")

class Lz4CompressionOptions(Struct):

    def parse(self):
        yield UInt32(name="Version", comment="only supported value is 1 (LZ4_LEGACY)")
        yield BitsField(
            Bit(name="HighCompressionMode"),
            NullBits(31),
            name="Flags")        

class ZstdCompressionOptions(Struct):

    def parse(self):
        yield UInt32(name="CompressionLevel", comment="should be in range [1,22]")        

class LzoCompressionOptions(Struct):

    def parse(self):
        yield UInt32(name="Algorithm", values=[
            ("lzo1x_1", 0),
            ("lzo1x_1_11", 1),
            ("lzo1x_1_12", 2),
            ("lzo1x_1_15", 3),
            ("lzo1x_999", 4),
            ])              
        yield UInt32(name="CompressionLevel", comment="compression level. For lzo1x_999, this can be a value between 0 and 9 (defaults to 8). Has to be 0 for all other algorithms")              



class NoDecompressor:
    def __init__(self, options=None):
        pass

    def decompress(data):
        return data

class LzmaDecompressor:
    def __init__(self, options=None):
        self.transform = compress.LzmaDecompress()

    def __call__(self, data):
        return self.transform.run(data, raw_mode=True)




class CompressorOptionsAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.DOCUMENT
    name = "HSQS.Comp"

    def parse(self, hint):
        compression = int(hint)
        optcls = {
            1: GzipCompressionOptions,
            3: LzoCompressionOptions,
            4: XzCompressionOptions,
            5: Lz4CompressionOptions,
            6: ZstdCompressionOptions,
        }.get(compression)
        if optcls is None:
            raise FatalError("No known compression option for {}".format(sb.Compression.enum))
        yield optcls(name="CompressionOptions", category=Type.HEADER)


class InodeTableAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.DOCUMENT
    name = "HSQS.InodeTable"

    def parse(self, hint):
        num_inodes = int(hint)
        for i in range(num_inodes):
            pass
        if False:
            yield UInt32()



class SquashFSAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.ARCHIVE
    name = "HSQS"
    regexp = r"hsqs................[\x01-\x06]\x00"

    def __init__(self):
        FileTypeAnalyzer.__init__(self)
        self.filesystem = {}
        self.decompressor = None

    def open_file(self, vfile):
        raise NotImplementedError

    def open_meta(self, vfile):
        return self.read_metadata(self[vfile.path[1:]])


    def read_metadata(self, md):
        res = b""
        for i in range(md.count):
            res += self.read_metadata_block(md[i])
        return res

    def read_metadata_block(self, block):
        sz = block["Size"]
        compressed = (sz & 0x8000) == 0
        res = block["Data"]
        if compressed:
            res = self.decompressor(res)
        return res


    def parse(self, hint):
        sb = yield SuperBlock(category=Type.HEADER)
        self.blocksize = sb["BlockSize"]
        if sb["BytesUsed"] > self.size():
            print("Truncated archive")
        eof = min(sb["BytesUsed"], self.size())
        self.confirm()

        # compression options
        compression = sb["Compression"]
        compression_options = None
        if sb["Flags"]["CompressorOptions"]:
            md = yield Metadata(name="CompressorOptions", max_blocks=1, category=Type.HEADER)
            data = self.read_metadata(md)
            fake_file = bindings.FileBuffer(data, "CompressorOptions")
            parser = CompressorOptionsAnalyzer()
            parsed = parser.run(fake_file, hint=str(compression))
            compression_options = parsed[0]
            self.files.append(bindings.VirtualFile("@CompressorOptions", len(data), "open_meta", "HSQS.Comp"))
            
        decompressorcls = {
            2: LzmaDecompressor,
        }.get(compression)
        if decompressorcls is not None:
            self.decompressor = decompressorcls(compression_options)

        # parse inode table
        self.jump(sb["InodeTableStart"])
        md = yield Metadata(name="InodeTable", category=Type.HEADER, max_size = min(eof, sb["DirectoryTableStart"]) - self.tell())
        self.files.append(bindings.VirtualFile("@InodeTable", md.size, "open_meta", "HSQS.InodeTable", str(sb["InodeCount"])))
    
