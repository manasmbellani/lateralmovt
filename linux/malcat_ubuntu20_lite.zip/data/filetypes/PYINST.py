from filetypes.base import *
from filetypes.PYC import MAGIC_TO_VERSION
import bindings
import zlib
import struct




class PyinstHeader(Struct):

    def parse(self):
        yield String(8, zero_terminated=True, name="Signature")
        yield UInt32BE(name="PackageSize", comment="size of package")
        yield UInt32BE(name="TableOfContentOffset", comment="toc offset")
        yield UInt32BE(name="TableOfContentSize", comment="toc size")
        yield UInt32BE(name="PythonVersion", comment="python version")


class PyinstEntry(Struct):

    def parse(self):
        sz = yield UInt32BE(name="Size", comment="size of entry")
        yield UInt32BE(name="Offset", comment="offset of entry")
        yield UInt32BE(name="CompressedSize", comment="size of entry compressed")
        yield UInt32BE(name="UncompressedSize", comment="size of entry uncompressed")
        yield UInt8(name="CompressionFlags", comment="")
        yield UInt8(name="Type", comment="type of entry")
        rest = sz - len(self)
        if rest > 0:
            yield String(rest, name="Name", zero_terminated=True, comment="entry name")
        

class PyinstAnalyzer(FileTypeAnalyzer):
    category = bindings.FileType.ARCHIVE
    name = "PYINST"
    regexp = r"MEI\x0C\x0B\n\x0B\x0E\x00"

    @classmethod
    def start_of_file(cls, curfile, offset_magic, parent_filetype):
        if parent_filetype is None:
            return 0
        if parent_filetype.name == "PE":
            max_fend = 0
            for section in parent_filetype["Sections"]:
                # pyinst exe: archive should start at overlay
                max_fend = max(max_fend, section["PointerToRawData"] + section["SizeOfRawData"])
            if max_fend < offset_magic:
                return max_fend
        return None

    def __init__(self):
        FileTypeAnalyzer.__init__(self)
        self.architecture = bindings.FileType.PY36
        self.filesystem = {}

    def open(self, vfile):
        entry = self.filesystem[vfile.path]
        data = self.read(entry["Offset"], entry["CompressedSize"])
        if entry["CompressedSize"] == entry["UncompressedSize"] or entry["CompressionFlags"] == 0:
            pass
        else:
            data = zlib.decompress(data)
        if entry["Type"] == 115:
            # we need to prepend python header
            pyversion = self["PyinstHeader"]["PythonVersion"]
            if pyversion > 100:
                pyversion = (pyversion//100, pyversion % 100)
            else:
                pyversion = (pyversion//10, pyversion % 10)
            MAGIC_TO_VERSION_INV = {v: k for k, v in MAGIC_TO_VERSION.items()}
            magic = MAGIC_TO_VERSION_INV.get(pyversion, MAGIC_TO_VERSION_INV[(3, 6)])
            header = struct.pack("<I", magic)
            header += b"\x00\x00\x00\x00"
            if pyversion >= (3, 7):
                header += b"\x00\x00\x00\x00"
            if pyversion >= (3, 3):
                header += struct.pack("<I", len(data))
            data = header + data

        return bytearray(data)


    def parse(self, hint):
        magic_off, _ = self.search(r"MEI\x0C\x0B\n\x0B\x0E\x00")
        if magic_off is None:
            raise FatalError

        # pyinst
        self.jump(magic_off)
        pyinst = yield PyinstHeader(category=Type.HEADER)
        # pyinst table of content
        toc = pyinst["TableOfContentOffset"]
        toc_end = toc + pyinst["TableOfContentSize"]
        self.jump(toc)
        while self.tell() < toc_end:
            e = yield PyinstEntry(parent=pyinst)
            ename = "Name" in e and e["Name"].strip() or ""
            self.sections.append(bindings.Section(
                e["Offset"], e["CompressedSize"],
                e["Offset"], e["CompressedSize"],
                ename, True
                ))
            if ename:
                ename = ename.replace("\\", "/")
                self.filesystem[ename] = e
                self.files.append(bindings.VirtualFile(ename, e["UncompressedSize"], "open"))
            if e["Offset"] + e["CompressedSize"] > self.size(): 
                raise OutOfBoundError
            if e["Type"] == ord('z') and self.read(e["Offset"], 3) != b"PYZ":
                raise FatalError
            if e["CompressionFlags"] == 1 and self.read(e["Offset"], 1) != b"\x78":
                raise FatalError

            
