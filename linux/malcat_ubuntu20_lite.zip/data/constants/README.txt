You can add your own user-defined constants by adding yara files (*.yar) in this directory. Rules should consist of a list of string and have the condition "any of them". Any matching string will be reported as a constant. Example:

rule CryptoMurmur3 {
    meta:
        name = "murmur3 hash"
        category = "hash"
    strings:
        $ = {512D9ECC}
        $ = {9335871B}
        $ = {6BCAEB85}
        $ = {35AEB2C2}
    condition:
        any of them
}

Note that every *.yar file in this directory will be imported separately. So if your yara rules are split into several files and include each other, the correct way to store your rules is:
- put a single *.yar file in this directory that will include all your rules(in the correct order
- create a subdirectory (e.g. myrules/) that contains all the rules to be included. Subdirectories are not scanned by malcat, so these .yar won't be imported twice.

The csig format is a (very simple) proprietary format specific for bytes signatures, which has the advantage of being way more compact than compiled yara rules (for instances the guids constants as compiled yara rules needs more than 100MB on disk). If you need to include a lot of constant contact me, I may distribute the csig "compiler" too.


