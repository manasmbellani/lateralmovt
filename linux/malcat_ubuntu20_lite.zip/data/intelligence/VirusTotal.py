from intelligence.base import *
import requests
import json

URL = "https://www.virustotal.com/api/v3/"



class VirusTotal(OnlineChecker):

    name = "VirusTotal"
    
    def check(self, malcat):
        detections = { }
        key = self.options.get("key")
        if not key:
            raise KeyError("No API key")
        message = ""
        session = requests.Session( )
        session.headers.update({'x-apikey': key})
        response = session.get(URL + "files/{}".format(malcat.entropy.sha256))
        if response.status_code == 404:
            return None
        elif response.status_code == 401:
            return KeyError("Bad API key")
        elif not response.ok:
            raise response.raise_for_status()
        data = response.json()
        infos = data.get("data", {}).get("attributes", {})
        for av, result in infos.get("last_analysis_results", {}).items():
            category = result.get("category", "")
            if category == "timeout":
                continue
            name = result.get("result", "")
            if name is None:
                name = ""
            detections[av] = OnlineDetection(level=DetectionLevel.from_text(category), name=name.strip())
        return OnlineResult(detections=detections, 
            url="https://www.virustotal.com/gui/file/{}/detection".format(malcat.entropy.sha256), 
            message=message
        )

    
