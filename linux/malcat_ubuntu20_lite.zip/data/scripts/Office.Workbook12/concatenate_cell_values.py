## This is a sample script to show how to use the pyhon bindings in malcat
##
## Feel free to edit it (but you won't be able to save it)
import bindings
import itertools
import datetime

res = bytearray()
for cell, val in malcat.analyzer.values.items():
    if type(val) == float and val:
        res.append(int(val))
gui.open_after(bytes(res), "cell values")