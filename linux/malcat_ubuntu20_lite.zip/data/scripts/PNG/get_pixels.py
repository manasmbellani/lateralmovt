"""
Uncompress zlib-encoded png pixels. Not really useful unless you know what you are doing
"""
import zlib

hdr = malcat.struct["IHDR"]
if hdr["Compression"] != 0:
    raise ValueError("Unsupported compression method")

obj = zlib.decompressobj()
done = b""
for s in malcat.struct:
    if s.name == "IDAT":
        done += obj.decompress(s["Data"])
done += obj.flush()
gui.open_after(done, "pixels")
