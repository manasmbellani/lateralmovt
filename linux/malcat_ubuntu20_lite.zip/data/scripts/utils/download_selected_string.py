import requests

if not len(malcat.sel):
    raise ValueError("Nothing selected")

url = ""

# is it a know string ?
if malcat.sel.start in malcat.strings:
    string = malcat.strings[malcat.sel.start]
    if string.text.startswith("http"):
        url = string.text

# if not look at selected bytes
if not url:
    offset = malcat.map.to_phys(malcat.sel.start)
    if offset is not None:
        data = malcat.file.read(offset, len(malcat.sel))
        if len(data) > 1 and data[1] == 0:
            url = data.decode("utf-16-le", errors="ignore")
        else:
            url = data.decode("ascii", errors="ignore")

if not url.startswith("http"):
    raise ValueError("No string starting with http found in selection")

headers = {'User-Agent': 'Mozilla/5.0'}
print("Downloading content at '{}' as 'Mozilla/5.0' with a timeout of 30s ...".format(url))
r = requests.get(url, headers=headers, verify=False, timeout=30)
r.raise_for_status()

gui.open_after(r.content, url)



