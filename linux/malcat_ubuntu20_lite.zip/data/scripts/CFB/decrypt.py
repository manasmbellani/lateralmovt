import bindings
import struct
from io import BytesIO

import msoffcrypto

"""
NOTE: for this script to work, you will have to install msoffcrypto:
    pip3 install msoffcrypto-tool

If you're under windows, be sure to use the system python (Options->Analysis setup->Use system python)
"""

passwords = ['VelvetSweatshop', '123', '1234', '12345', '123456', '4321']

for password in passwords:
    print("Trying password {} ...".format(password))
    try:
        inp = BytesIO(malcat.file.read(0, malcat.file.size))
        f = msoffcrypto.OfficeFile(inp)
        f.load_key(password=password)
        outp = BytesIO()
        f.decrypt(outp)
        gui.open_after(outp.getvalue(), "Decrypted")
        break
    except BaseException as e:
        print(e)
