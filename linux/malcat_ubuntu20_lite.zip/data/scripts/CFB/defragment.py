import bindings
import struct

rewrite = []
sector_size = 512
fh = malcat.struct["FileHeader"]
ss = pow(2, fh["SectorShift"])
print(ss)
mss = pow(2, fh["MiniSectorShift"])
cfb = malcat.analyzer


def sector2offset(s):
    return (s+1) * ss

def alloc(old):
    rewrite.append(old)
    return len(rewrite) - 1

def defragment_difat():
    prev_ptr = fh.FirstDIFATSector
    while prev_ptr.value < 0xFFFFFFFE:
        nextdifat = prev_ptr.value
        prev_ptr = alloc(nextdifat)
        difat = malcat.struct[sector2offset(nextdifat)]
        assert(difat.count == sector_size // 4)
        prev_ptr = difat.at(difat.count - 1)


def defragment_fat():
    for difat in analyzer.difats:
        for i, fat_sector in enumerate(difat):
            pass


