# malcat features extractor for CAPA
# only works for x86-x64 !
import sys
import types

import capa
import capa.features.extractors.helpers
import capa.features.extractors.strings
from capa.features.extractors.base_extractor import FeatureExtractor
from capa.features.common import String, Characteristic, MAX_BYTES_FEATURE_SIZE, Bytes
from capa.features.file import Export, Import, Section
from capa.features.extractors.helpers import MIN_STACKSTRING_LEN
from capa.features.insn import Number, Offset, Mnemonic, API
from capa.features.common import OS, FORMAT_PE, FORMAT_ELF, Arch, Format, String, BITNESS_X32, BITNESS_X64, ARCH_I386, ARCH_AMD64, OS_WINDOWS, OS_LINUX

from bindings import Symbol, FileType, BasicBlockEdge, Instruction, InstructionOperand


class MergedBasicBlock:

    def __init__(self, first, last):
        self.first = first
        self.last = last

    @property
    def address(self):
        return self.first.address

    @property
    def code(self):
        return self.first.code

    @property
    def is_loop(self):
        return self.first.is_loop

    @property
    def incoming(self):
        return self.first.incoming

    @property
    def outgoing(self):
        return self.last.outgoing

    @property
    def start(self):
        return self.first.start

    @property
    def end(self):
        return self.last.end




class MalcatFeatureExtractor(FeatureExtractor):
    def __init__(self, malcat):
        super(MalcatFeatureExtractor, self).__init__()
        self.malcat = malcat

        # pre-compute these because we'll yield them at *every* scope.
        self.__global_features = list(self.__extract_global_features())

        # malcat does not support multi-bitness, so precompute it there:
        if malcat.architecture in (FileType.X64,):
            self.bitness = BITNESS_X64
        else:
            self.bitness = BITNESS_X32

    def get_base_address(self):
        return self.malcat.imagebase

################################# GLOBAL FEATURES

    def extract_global_features(self):
        yield from self.__global_features
    
    def __extract_global_features(self):
        arch = {
            FileType.X86: ARCH_I386,
            FileType.X64: ARCH_AMD64,
        }.get(self.malcat.architecture, ARCH_I386)
        if arch:
            yield Arch(arch), 0x0
        # I don't really get this feature tbh ...
        if self.malcat.type == "ELF":
            yield OS(OS_LINUX), 0x0
        else:
            yield OS(OS_WINDOWS), 0x0

################################# FILE FEATURES

    def extract_file_features(self):
        for extractor_fn in (self.extract_symbols, self.extract_sections, self.extract_strings, self.extract_embedded_pe, self.extract_format):
            yield from extractor_fn()

    def extract_symbols(self):
        for s in self.malcat.syms:
            if s.type == Symbol.Type.IMPORT:
                yield Import(s.name.replace(":", ".")), s.address
                if not "#" in s.name and ":" in s.name:
                    yield Import(s.name.split(":")[1]), s.address
            elif s.type == Symbol.Type.EXPORT:
                yield Export(s.name), s.address

    def extract_sections(self):
        for region in self.malcat.map:
            yield Section(region.name), region.address

    def extract_strings(self):
        for string in self.malcat.strings:
            yield String(string.text), string.address

    def extract_embedded_pe(self):
        for sf in self.malcat.subfiles:
            if sf.type == "PE":
                yield Characteristic("embedded pe"), sf.address

    def extract_format(self):
        file_format = {
                "PE": FORMAT_PE,
                "ELF": FORMAT_ELF,
        }.get(self.malcat.type, self.malcat.type.lower())
        yield Format(file_format), 0x0
        
            
################################# FUNCTION FEATURES

    def is_library_function(self, ea: int) -> bool:
        # TODO
        return False

    def get_function_name(self, ea: int) -> str:
        # TODO
        raise KeyError(va)

    def get_functions(self):
        yield from self.malcat.fns

    def extract_function_features(self, f):
        for extractor_fn in (self.extract_function_switch, self.extract_function_recursive, self.extract_function_loop, 
                self.extract_function_calls_to):
            yield from extractor_fn(f)

    def extract_function_switch(self, f):
        for bb in self.malcat.cfg[f.address:f.end]:
            if len(bb.outgoing) > 2:
                yield Characteristic("switch"), self.malcat.cfg.align(bb.end - 1, bb)

    def extract_function_loop(self, f):
        for bb in self.malcat.loops[f.address:f.end]:
            yield Characteristic("loop"), f.address
            break

    def extract_function_recursive(self, f):
        bb = self.malcat.cfg[f.address]
        for edge in bb.incoming:
            if edge.address == f.address:
                # this is not correct, we should check for the presence of a call to the function's body, anywhere inside the function
                # but ida's extractor works this way so let's be consistent ...
                yield Characteristic("recursive call"), f.address

    def extract_function_calls_to(self, f):
        bb = self.malcat.cfg[f.address]
        for edge in bb.incoming:
            if edge.type == BasicBlockEdge.Type.CALL:
                yield Characteristic("calls to"), edge.address


################################# BASIC BLOCKS FEATURES

    def get_basic_blocks(self, f):
        first = None
        last = None
        for bb in self.malcat.cfg[f.address:f.end]:
            if first is None:
                first = bb
            last = bb
            if not bb.exotic:
                yield MergedBasicBlock(first, last)
                first = None

    def extract_basic_block_features(self, f, bb):
        for extractor_fn in (self.extract_bb_tigh_loop, self.extract_bb_stack_string):
            yield from extractor_fn(f, bb)

    def extract_bb_tigh_loop(self, f, bb):
        if bb.is_loop:
            yield Characteristic("tight loop"), bb.address

    def extract_bb_stack_string(self, f, bb):
        if self.malcat.architecture in (FileType.Architecture.X86, FileType.Architecture.X64):
            num_im_to_stack = 0
            for insn in self.malcat.asm[bb.start:bb.end]:
                if len(insn) == 2 and insn[0].type == InstructionOperand.Type.LOCAL and insn[1].type == InstructionOperand.Type.CONSTANT:
                    num_im_to_stack += 1
                    if num_im_to_stack > MIN_STACKSTRING_LEN:
                        yield Characteristic("stack string"), bb.address
                        break


################################# INSTRUCTION FEATURES

    def get_instructions(self, f, bb):
        yield from self.malcat.asm[bb.start:bb.end]

    def extract_insn_features(self, f, bb, insn):
        for extractor_fn in (
                self.extract_insn_number_features, 
                self.extract_insn_api_features, 
                self.extract_insn_bytes_features, 
                self.extract_insn_strings_features, 
                self.extract_insn_offset_features, 
                self.extract_insn_nzxor_characteristic_features,
                self.extract_insn_mnemonic_features, 
                self.extract_insn_peb_access_characteristic_features,
                self.extract_insn_segment_access_features, 
                self.extract_insn_cross_section_cflow, 
                self.extract_function_calls_from,
                self.extract_function_indirect_call_characteristic_features,
                self.extract_insn_obfs_call_plus_5_characteristic_features,
                ):
            
            yield from extractor_fn(f, bb, insn)

    def extract_insn_number_features(self, f, bb, insn):
        if insn.type in (Instruction.Type.RETURN, Instruction.Type.STACK):
            return
        for op in insn:
            if op.type == InstructionOperand.Type.CONSTANT:
                if op.immediate is not None and self.malcat.map.from_virt(op.immediate) is None:
                    yield Number(op.immediate), insn.address
                    yield Number(op.immediate, bitness=self.bitness), insn.address

    def extract_insn_bytes_features(self, f, bb, insn):
        if insn.type in (Instruction.Type.CALL,):
            return
        for op in insn:
            if op.immediate:
                ea = self.malcat.map.from_virt(op.immediate)
                if ea and not self.malcat.cfg[ea].code:
                    off = self.malcat.map.to_phys(ea)
                    if off:
                        extracted_bytes = self.malcat.file.read(off, MAX_BYTES_FEATURE_SIZE)
                        if extracted_bytes and not capa.features.extractors.helpers.all_zeros(extracted_bytes):
                            yield Bytes(extracted_bytes), insn.address

    def extract_insn_strings_features(self, f, bb, insn):
        for op in insn:
            if op.immediate:
                ea = self.malcat.map.from_virt(op.immediate)
                if ea and ea in self.malcat.strings:
                    yield String(self.malcat.strings[ea].text), insn.address

    def extract_insn_offset_features(self, f, bb, insn):
        for op in insn:
            if op.type == InstructionOperand.Type.OBJECT and op.immediate:
                ea = self.malcat.map.from_virt(op.immediate)
                if ea is not None:
                    yield Offset(op.immediate), insn.address
                    yield Offset(op.immediate, bitness=self.bitness), insn.address

    def extract_insn_api_features(self, f, bb, insn):
        api = None
        if insn.type == Instruction.Type.CALL and len(insn) > 0 and insn[0].type in (InstructionOperand.Type.GLOBAL, InstructionOperand.Type.SYMBOL, InstructionOperand.Type.CONSTANT):
            if insn[0].immediate:
                address = self.malcat.map.from_virt(insn[0].immediate)
            else:
                address = None
            api = insn[0].symbol
            if not api and address:
                for symbol in self.malcat.syms[address]:
                    if symbol.type == Symbol.Type.IMPORT:
                        api = symbol.name
                        break

            if not api and address is not None:
                # is it a call to jmp api ?
                bb2 = self.malcat.cfg[address]
                insn2 = self.malcat.asm[address]
                if bb2.code and insn2.type == Instruction.Type.JUMP and len(insn2) > 0 and insn2[0].type in (InstructionOperand.Type.GLOBAL, InstructionOperand.Type.SYMBOL):
                    if insn2[0].immediate:
                        address = self.malcat.map.from_virt(insn2[0].immediate)
                    else:
                        address = None
                    api = insn2[0].symbol
                    if not api and address:
                        for symbol in self.malcat.syms[address]:
                            if symbol.type == Symbol.Type.IMPORT:
                                api = symbol.name
                                break
        elif insn.type == Instruction.Type.ASSIGN and len(insn) == 2 and insn[0].type == InstructionOperand.Type.REGISTER and insn[1].type == InstructionOperand.Type.GLOBAL:
            if insn[1].immediate:
                address = self.malcat.map.from_virt(insn[1].immediate)
            else:
                address = None
            api = insn[1].symbol
            outgoing = bb.outgoing
            if not api and address and len(outgoing) == 1:
                for symbol in self.malcat.syms[address]:
                    if symbol.type == Symbol.Type.IMPORT:
                        api = symbol.name
                        break
            try:
                next_insn = self.malcat.asm[insn.address + insn.size]
            except:
                next_insn = None
            if next_insn is not None and next_insn.type == Instruction.Type.CALL and next_insn[0].type == InstructionOperand.Type.REGISTER and next_insn[0].slot == insn[0].slot:
                pass
            else:
                api = None
        if api:
            dll, _, symbol = api.rpartition(".")
            for name in capa.features.extractors.helpers.generate_symbols(dll, symbol):
                yield API(name), insn.address

    def extract_insn_nzxor_characteristic_features(self, f, bb, insn):
        if insn.type == Instruction.Type.XOR:   # malcat already checks that it is not a zero-xor or a stack-cookie xor
            yield Characteristic("nzxor"), insn.address

    def extract_insn_mnemonic_features(self, f, bb, insn):
        yield Mnemonic(insn.mnemonic), insn.address

    def extract_insn_obfs_call_plus_5_characteristic_features(self, f, bb, insn):
        if insn.type != Instruction.Type.CALL or insn.address + insn.size != bb.end:
            return
        for edge in bb.outgoing:
            if edge.type == BasicBlockEdge.Type.CALL and edge.address == bb.end:
                yield Characteristic("call $+5"), insn.address

    def extract_insn_peb_access_characteristic_features(self, f, bb, insn):
        if insn.type not in ((Instruction.Type.ASSIGN, Instruction.Type.PUSH)):
            return
        if all(map(lambda op: op.type != InstructionOperand.Type.GLOBAL or op.immediate not in (0x30, 0x60), insn)):
            return
        disasm = str(insn)
        if "fs:[0x30]" in disasm or "gs:[0x60]" in disasm:
            yield Characteristic("peb access"), insn.address

    def extract_insn_segment_access_features(self, f, bb, insn):
        if all(map(lambda op: op.type != InstructionOperand.Type.GLOBAL, insn)):
            return
        disasm = str(insn)
        if "fs:[" in disasm:
            yield Characteristic("fs access"), insn.address
        if "gs:[" in disasm:
            yield Characteristic("gs access"), insn.address

    def extract_insn_cross_section_cflow(self, f, bb, insn):
        if insn.address + insn.size != bb.end:
            return
        region = self.malcat.map[insn.address]
        if region is None:
            return
        for edge in bb.outgoing:
            if edge.address not in region:
                yield Characteristic("cross section flow"), insn.address


    def extract_function_calls_from(self, f, bb, insn):
        if insn.address + insn.size != bb.end:
            return
        for edge in bb.outgoing:
            if edge.type == BasicBlockEdge.Type.CALL:
                yield Characteristic("calls from"), edge.address


    def extract_function_indirect_call_characteristic_features(self, f, bb, insn):
        if insn.type == Instruction.Type.CALL and len(insn) >= 1 and insn[0].immediate:
            # ignore call [import]
            target = self.malcat.map.from_virt(insn[0].immediate)
            if target and target in self.malcat.syms:
                return
            real_bb = self.malcat.cfg[insn.address]
            if len(real_bb.outgoing) <= 1:
                yield Characteristic("indirect call"), insn.address
