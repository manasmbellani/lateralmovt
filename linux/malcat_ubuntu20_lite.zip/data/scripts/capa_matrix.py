import os
import capa
import capa.rules
import capa.engine
import capa.features
import capa.features.extractors.malcat
import importlib
import itertools
import logging
import collections
import json
import numbers
import zipfile
importlib.reload(capa.features.extractors.malcat)
from tabulate import tabulate

logger = logging.getLogger("capa")

def width(s, character_count):
    """pad the given string to at least `character_count`"""
    if len(s) < character_count:
        return s + " " * (character_count - len(s))
    else:
        return s

def get_rules(rule_path):
    if not os.path.exists(rule_path):
        raise IOError("rule path %s does not exist or cannot be accessed" % rule_path)

    rule_paths = []
    if os.path.isfile(rule_path) and rule_path.endswith(".zip"):
        logger.debug("reading rules from zip %s", rule_path)
        rule_paths.append(rule_path)
    elif os.path.isdir(rule_path):
        logger.debug("reading rules from directory %s", rule_path)
        for root, dirs, files in os.walk(rule_path):
            if ".github" in root:
                continue
            for file in files:
                if not file.endswith(".yml"):
                    if not (file.endswith(".md") or file.endswith(".git") or file.endswith(".txt")):
                        logger.warning("skipping non-.yml file: %s", file)
                    continue

                rule_path = os.path.join(root, file)
                rule_paths.append(rule_path)

    rules = []
    for rule_path in rule_paths:
        if rule_path.endswith(".zip"):
            with zipfile.ZipFile(rule_path, "r") as zo:
                for elem in zo.infolist():
                    if not elem.filename.endswith(".yml"):
                        continue
                    with zo.open(elem.filename, mode='r') as f:
                        yaml_content = f.read().decode("utf8")
                        try:
                            rule = capa.rules.Rule.from_yaml(yaml_content, use_ruamel=True)
                        except capa.rules.InvalidRule:
                            raise
                        else:
                            rule.meta["capa/path"] = os.path.join(rule_path, elem.filename)
                            if "nursery" in rule_path:
                                rule.meta["capa/nursery"] = True
                            rules.append(rule)
                            logger.debug("loaded rule: '%s' with scope: %s", rule.name, rule.scope)
        else:
            try:
                rule = capa.rules.Rule.from_yaml_file(rule_path, use_ruamel=True)
            except capa.rules.InvalidRule:
                raise
            else:
                rule.meta["capa/path"] = rule_path
                if "nursery" in rule_path:
                    rule.meta["capa/nursery"] = True
                rules.append(rule)
                logger.debug("loaded rule: '%s' with scope: %s", rule.name, rule.scope)
    return rules

def is_interesting_rule(rule):
    for meta in ("lib", "capa/subscope", "maec/analysis-conclusion", "maec/malware-category", "maec/analysis-conclusion-ov",
            "maec/malware-category-ov", "capa/nursery"):
        if rule.meta.get(meta, None):
            return False
    return True

def render_rules_summary(capabilities):
    table = []
    for rule, match in capabilities.items():
        name = rule.name
        if len(match) > 1:
            name += " ({})".format(len([x for x in match if x[1].success]))
        table.append((name, rule.meta.get("namespace", "")))
    table = tabulate(table, headers=[width("CAPABILITY", 50), width("NAMESPACE", 50)], tablefmt="psql")
    table_width = len(table.splitlines()[0])
    gui.print("[block1]{}[/block1]".format("{} capabilities found".format(len(capabilities)).center(table_width)), format=True)
    print(table)

def render_attack(capabilities):
    tactics = collections.defaultdict(set)
    for rule in capabilities:
        if not rule.meta.get("att&ck"):
            continue

        for attack in rule.meta["att&ck"]:
            tactic, _, rest = attack.partition("::")
            if "::" in rest:
                technique, _, rest = rest.partition("::")
                subtechnique, _, id = rest.rpartition(" ")
                tactics[tactic].add((technique, subtechnique, id))
            else:
                technique, _, id = rest.rpartition(" ")
                tactics[tactic].add((technique, id))

    rows = []
    for tactic, techniques in sorted(tactics.items()):
        inner_rows = []
        for spec in sorted(techniques):
            if len(spec) == 2:
                technique, id = spec
                inner_rows.append("{} {}".format(technique, id))
            elif len(spec) == 3:
                technique, subtechnique, id = spec
                inner_rows.append("{}::{} {}".format(technique, subtechnique, id))
            else:
                raise RuntimeError("unexpected ATT&CK spec format")
        rows.append(("{}".format(tactic.upper()), "\n".join(inner_rows),))

    if rows:
        table = tabulate(rows, headers=[width("ATT&CK Tactic", 20), width("ATT&CK Technique", 80)], tablefmt="psql")
        table_width = len(table.splitlines()[0])
        gui.print("[block1]{}[/block1]".format("ATT&CK information".center(table_width)), format=True)
        print(table)


def render_mbc(capabilities):
    objectives = collections.defaultdict(set)
    for rule in capabilities:
        if not rule.meta.get("mbc"):
            continue

        for mbc in rule.meta["mbc"]:
            objective = mbc.split("::")[0]
            objectives[objective].add("::".join(mbc.split("::")[1:]))

    rows = []
    for objective, behaviors in sorted(objectives.items()):
        inner_rows = []
        for behavior in sorted(behaviors):
            inner_rows.append(behavior)
        rows.append((objective.upper(), "\n".join(inner_rows),))

    if rows:
        table = tabulate(rows, headers=[width("MBC Objective", 25), width("MBC Behavior", 75)], tablefmt="psql")
        table_width = len(table.splitlines()[0])
        gui.print("[block1]{}[/block1]".format("Malware Behavior Catalog".center(table_width)), format=True)
        print(table)
    


def render_statement(match, statement, indent=0):
    print("  " * indent, end="")
    if isinstance(statement, capa.engine.Or) or \
        isinstance(statement, capa.engine.And) or \
        isinstance(statement, capa.engine.Subscope) or \
        isinstance(statement, capa.engine.Not):
        gui.print("{}:".format(statement.__class__.__name__.lower()))
    elif isinstance(statement, capa.engine.Some):
        if not statement.count:
            gui.print("optional:")
        else: 
            gui.print("{} or more:".format(statement.count))
    elif isinstance(statement, capa.engine.Range):
        child = statement.child
        name = child.__class__.__name__.lower()
        if hasattr(child, "value"):
            if hasattr(child, "description") and child.description:
                gui.print("[color4]count[/color4]([color2]{}[/color2]({} = {})): ".format(name, render_value(child.value), child.description), end="", format=True)
            else:
                gui.print("[color4]count[/color4]([color2]{}[/color2]({})): ".format(name, render_value(child.value)), end="", format=True)
        else:
            gui.print("[color4]count[/color4]([color2]{}[/color2]): ".format(name), end="", format=True)

        if statement.max == statement.min:
            print("{}".format(statement.min), end="")
        elif statement.min == 0:
            print("{} or fewer".format(statement.max), end="")
        elif statement.max == (1 << 64 - 1):
            print("{} or more".format(statement.min), end="")
        else:
            print("between {} and {}".format(statement.min, statement.max), end="")

        render_locations(match)
        print()
    else:
        raise RuntimeError("unexpected match statement type: " + str(statement))


def render_feature(match, feature, indent=0):
    print("  " * indent, end="")
    key = feature.__class__.__name__
    value = feature.value
    if key == "regex":
        key = "string"  # render string for regex to mirror the rule source
        value = feature.match  # the match provides more information than the value for regex
    gui.print("[color2]{}[/color2]: ".format(key), end="", format=True)
    if value:
        gui.print("[color3]{}[/color3]".format(render_value(value).replace("[", "\\[")), end="", format=True)

        if feature.description:
            print(capa.rules.DESCRIPTION_SEPARATOR + feature.description, end="")
    if key not in ("OS", "arch"):
        render_locations(match)
    print()


def render_address(ea):
    va = malcat.map.to_virt(ea)
    if va is not None:
        return "[va]0x{:08x}[/va]".format(va)
    fa = malcat.map.to_phys(ea)
    if fa is not None:
        return "[fa]#{:x}[/fa]".format(fa)
    return "[ea]${:x}[/ea]".format(ea)

def render_value(val):
    if isinstance(val, numbers.Number):
        return "0x{:x}".format(val)
    else:
        return str(val)

def render_locations(match):
    locations = list(sorted(match.locations))
    if len(locations) == 1:
        va = malcat.map.to_virt
        gui.print(" [color1]@[/color1] {}".format(render_address(locations[0])), format=True, end="")
    elif len(locations) > 1:
        gui.print(" [color1]@[/color1] ", end="", format=True)
        gui.print(", ".join(map(render_address, locations[:4])), format=True, end="")
        if len(locations) > 4:
            gui.print(", and {} more...".format(len(locations) - 4), end="")


def render_node(match, node, indent=0):
    if isinstance(node, capa.engine.Statement):
        render_statement(match, node, indent=indent)
    elif isinstance(node, capa.features.common.Feature):
        render_feature(match, node, indent=indent)
    else:
        raise RuntimeError("unexpected node type: " + str(node))


def render_match(match, indent=0, invert=False):
    child_mode = invert
    if match.success == invert:
        return
    elif isinstance(match.statement, capa.engine.Not):
        child_mode = not invert
    elif isinstance(match.statement, capa.engine.Some) and match.statement.count == 0:
        if not invert and not any(map(lambda m: m.success, match.children)):
            return
        elif invert and any(map(lambda m: m.success, match.children)):
            return
    render_node(match, match.statement, indent=indent)
    for child in match.children:
        render_match(child, indent=indent + 1, invert=child_mode)








if __name__ == "__main__":
    gui.print("[error]{}[/error]".format("CAPA script".center(111)), format=True)
    datadir = os.path.join(malcat.datadir, "scripts", "capa", "all_rules.zip")
    userdir = os.path.join(malcat.userdir, "scripts", "capa", "all_rules")
    gui.print("""
CAPA framework by mandiant ([url]https://github.com/mandiant/capa[/url]) using bindings for [color1]Malcat[/color1].
Everything except the bindings comes from the github repository. 
Mandiant rules can be found in [color3]<MALCAT DATA DIR>/scripts/capa/rules.zip[/color3]. 
You can add your own as .yml files in [color3]<USER DATA DIR>/scripts/capa/all_rules/*.yml[/color3].
    """, format=True)

    ex =  capa.features.extractors.malcat.MalcatFeatureExtractor(malcat)
    gui.progress(2)

    # load rules
    rules = get_rules(datadir)
    if malcat.datadir != malcat.userdir and os.path.exists(userdir):
        rules += get_rules(userdir)

    ruleset = capa.rules.RuleSet(rules)
    gui.progress(10)

    # extract function, bb and instruction features
    capabilities = collections.defaultdict(list)
    all_function_matches = collections.defaultdict(list)
    all_bb_matches = collections.defaultdict(list)

    for i, fn in enumerate(ex.get_functions()):
        gui.progress(10 + (80 * i) // len(malcat.fns))

        if ex.is_library_function(fn.address):
            function_name = ex.get_function_name(fn.address)
            print("skipping library function 0x%x (%s)", macat.map.to_virt(fn.address), function_name)
            continue

        function_features = collections.defaultdict(set)
        bb_matches = collections.defaultdict(list)

        for feature, ea in itertools.chain(ex.extract_function_features(fn), ex.extract_global_features()):
            function_features[feature].add(ea)
        for bb in ex.get_basic_blocks(fn):
            bb_features = collections.defaultdict(set)
            for feature, ea in itertools.chain(ex.extract_basic_block_features(fn, bb), ex.extract_global_features()):
                bb_features[feature].add(ea)
                function_features[feature].add(ea)

            for insn in ex.get_instructions(fn, bb):
                for feature, ea in itertools.chain(ex.extract_insn_features(fn, bb, insn), ex.extract_global_features()):
                    bb_features[feature].add(ea)
                    function_features[feature].add(ea)
            _, matches = capa.engine.match(ruleset.basic_block_rules, bb_features, bb.address)
            for rule_name, res in matches.items():
                bb_matches[rule_name].extend(res)
                capabilities[rule_name].extend(res)
                for ea, _ in res:
                    function_features[capa.features.common.MatchedRule(rule_name)].add(ea)
        _, function_matches = capa.engine.match(ruleset.function_rules, function_features, fn.address)
        for k, v in function_matches.items():
            capabilities[k].extend(v)

    function_features = {
        capa.features.MatchedRule(rule_name): set(map(lambda p: p[0], results))
        for rule_name, results in all_function_matches.items()
    }
    
    # extract file features
    file_features = collections.defaultdict(set)
    for feature, ea in itertools.chain(ex.extract_file_features(), ex.extract_global_features()):
        if ea:
            file_features[feature].add(ea)
    else:
        if feature not in file_features:
            file_features[feature] = set()
    file_features.update(function_features)
    _, file_matches = capa.engine.match(ruleset.file_rules, file_features, 0x0)
    capabilities.update(file_matches)

    # rule lookup and sorting
    capabilities = collections.OrderedDict(
            sorted([(ruleset[k], v) for k,v in capabilities.items() if is_interesting_rule(ruleset[k])],
                key=lambda x: (x[0].meta.get("namespace", ""), x[0].name))
            )

    # display
    print()
    render_attack(capabilities)
    print("\n")
    render_mbc(capabilities)
    print("\n")
    render_rules_summary(capabilities)
    print("\n")
    for rule, matches in capabilities.items():
        gui.print("[block2]{}[/block2]".format(rule.name.center(80).replace("[", "\\[")), format=True)
        gui.print("namespace:  [color4]{}[/color4]".format(rule.meta.get("namespace", "")), format=True)
        for key in ("att&ck", "mbc"):
            if key in rule.meta:
                gui.print("{:12s}{}".format(key + ":", ",".join(["[color3]{}[/color3]".format(x.replace("[", "\\[")) for x in rule.meta[key]])), format=True)
        gui.print("rule scope: [color3]{}[/color3]".format(rule.scope), format=True)
        authors = rule.meta.get("author", [])
        if type(authors) == str:
            authors = [authors]
        gui.print("author:     [color3]{}[/color3]".format(", ".join(authors)), format=True)
        
        if rule.scope == "file":
            if len(matches) == 1:
                render_match(matches[0][1], indent=0)
        else:
            for location, match in sorted(matches):
                if match.success:
                    gui.print("{} [color1]@[/color1] {}".format(rule.scope, render_address(location)), format=True)
                    render_match(match, indent=1)
        print()
        
