## This is a sample script to show how to use the pyhon bindings in malcat
##
## Feel free to edit it (but you won't be able to save it)
import bindings
import itertools
import datetime

res = bytearray()
for sheet in malcat.analyzer.sheets[1:]:
    for cell, val in sheet.values.items():
        if type(val) == float:
            res.append(int(val))
gui.open_after(bytes(res), "cell values")