import struct 

BITMAP_FILE_HEADER_SIZE = 0xe
data = malcat.file[:]
fake_header = struct.pack("<2sIII", b"BM", len(data) + BITMAP_FILE_HEADER_SIZE, 0, BITMAP_FILE_HEADER_SIZE + malcat.struct.at("biImageData").offset )

gui.open_after(fake_header + data, "bmp")