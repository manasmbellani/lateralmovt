## This is a sample script to show how to use the python bindings in malcat
## It is meant to be run against a PE file.

import bindings
import itertools
import datetime


####### malcat.file
print("############### TESTING FILE OBJECT ####################")
print(f"The current file is {malcat.file.name} (path: {malcat.file.path}) and is {len(malcat.file)} bytes big")
print(f"The first 6 bytes of the file are {malcat.file.read(0,6)}")
print(f"The next 6 bytes of the file are {malcat.file[6:12]}")
match_off, match_len = malcat.file.search(r"PE\x00\x00", start=0, size=len(malcat.file))
if match_len:
    print(f"Pattern found! {match_len} bytes at #{match_off:x}")
else:
    print("Pattern not found!")
for match_off, match_len in malcat.file.search_all(r"\xAA{4,}+"):
    print(f"One pattern found: {match_len} bytes at #{match_off:x}")
# you can also write to the file (each write is undoable in the GUI if the script is run from the GUI):
# malcat.file.write(2, 56)
# malcat.file[2] = 56
# you can also write bytes:
# malcat.file.write(2, b"ab")
# malcat.file[2:4] = b"ab"


####### malcat.map
print("\n\n############### TESTING MAP OBJECT ####################")
address = 0x1100
print(f"Effective address {address:x} has offset=#{malcat.map.to_phys(address):x}, va=0x{malcat.map.to_virt(address):x}, rva=@{malcat.map.to_rva(address):x}")

# you can use gui.print instead of print to add formatting
ea_from_rva = malcat.map.from_rva(address)
if ea_from_rva is not None:
    gui.print(f"RVA @[rva]{ea_from_rva:x}[/rva] has offset=#[fa]{malcat.map.to_phys(ea_from_rva):x}[/fa]", format=True)

print(f"Imagebase=0x{malcat.map.base:x} - total size of address space (physical + virtual) = {len(malcat.map)} bytes")

region = malcat.map.get_region_for_rva(address)
if region is not None:
    print(f"RVA @{address:x} lies in region {region.name} (physical: [#{region.phys:x}-#{region.phys + region.phys_size:x}[, virtual: [0x{region.virt:x}-0x{region.virt + region.virt_size:x}[, exec={region.exec}, read={region.read}, write={region.write})")
print("List of regions: {}".format(", ".join([x.name for x in malcat.map])))

if "overlay" in malcat.map:
    print("File has overlay")
else:
    print("File has no overlay")

####### malcat.struct
print("\n\n############### TESTING STRUCT OBJECT ####################")
if "OptionalHeader" in malcat.struct:
    # [] is for field value access: return the structure field value (if field is a leaf, i.e no struct, bitfield or array)
    print(f"EntryPoint: 0x{malcat.struct['OptionalHeader']['AddressOfEntryPoint']:x}")
    # . is for field detailled access: you get access to the value, offset, size, bytes, name, etc
    print(f"EntryPoint: {malcat.struct.OptionalHeader.AddressOfEntryPoint}")
    ep = malcat.struct.OptionalHeader.AddressOfEntryPoint
    print(f"{ep.name}: 0x{ep.value:x} (at effective address {ep.address:x}, aka offset #{ep.offset:x}), size of field: {ep.size}, bytes: {ep.bytes}")
    # .at(field_name) is a synonym for .field_name
    print(f"EntryPoint: {malcat.struct.OptionalHeader.at('AddressOfEntryPoint').value:x}")
    # .at(index) get access to the ith field
    print(f"OptionalHeader[0] is field {malcat.struct.OptionalHeader.at(0).name}")
    # you can also use the [index] syntax to access the value directly
    print(f"OptionalHeader[0]: {malcat.struct.OptionalHeader[0]}")

    # enums
    machine = malcat.struct.PE.Machine
    print(f"PE.Machine = {machine.value}, has_enum = {machine.has_enum}, enum = {machine.enum}")

    # arrays
    print(f"has exports ? {malcat.struct['OptionalHeader']['DataDirectory'][0]['Size'] > 0}")
    print(f"number of data directories:  {malcat.struct['OptionalHeader']['DataDirectory'].count}")
    for i, dd in enumerate(malcat.struct["OptionalHeader"]["DataDirectory"]):
        print(f"    DataDirectory[{i}]: {dd['Rva']:x}-{dd['Rva'] + dd['Size']:x}")
    # if you want to access detailed field info, use .at(index) instead of [index]:
    for i in range(malcat.struct["OptionalHeader"]["DataDirectory"].count):
        print(f"    DataDirectory[{i}] is located at #{malcat.struct['OptionalHeader']['DataDirectory'].at(i).offset:x}")

    # structures
    # you can also enumerate all fields of a structure by index
    for i in range(malcat.struct.OptionalHeader.count):
        field_access = malcat.struct.OptionalHeader.at(i)   # .at(index) return field detailled access of ith field/array element
        field_value = malcat.struct.OptionalHeader[i]   # <=> field_access.value
        # some field may have an enum equivalent 
        print(f"    {field_access.name}: {field_value} {field_access.has_enum and ('<=> ' + field_access.enum) or ''}")
    
    # bitfields 
    print(f"is executable ? {malcat.struct.PE.Characteristics['ExecutableImage']}")
    print(f"is executable ? {malcat.struct.PE.Characteristics[1]}") # access by index

    # writing 
    # atomic fields can be written (with some restriction, like written data amy not be larger on disk)
    # uncomment to test:
    # malcat.struct["PE"]["TimeDateStamp"] = datetime.datetime.now()
    # malcat.struct.MZ.InitialSS.value = 5      # you can also write by setting the .value field


####### fns
print("\n\n############### TESTING FNS OBJECT ####################")

# malcat.fns[ea_start:ea_end] would return an iterator over all bfunctions in this address range
fns = list(malcat.fns[malcat.map.from_phys(0) : malcat.map.from_phys(0x5000)])
print(f"there are {len(fns)} functions in range[#0-#5000[")

first_function = malcat.fns.find_forward(0)
if first_function is not None:
    print(f"first function of file: {first_function} at [0x{malcat.map.to_virt(first_function.start):x} - 0x{malcat.map.to_virt(first_function.end):x}[")
last_function = malcat.fns.find_backward(len(malcat.map))
if last_function is not None:
    print(f"last function of file: {last_function} at 0x{malcat.map.to_virt(last_function.start):x} ({len(last_function)} bytes)")

for fn in itertools.islice(malcat.fns, 3):
    print(f"* function {fn.fullname} at #{malcat.map.to_phys(fn.start):x}")
    print(f"  module part of name: {fn.module}")        # X1.X2.Y<Z1, Z2>(A1, A2) -> X1.X2
    print(f"  identifier part of name: {fn.name}")      # X1.X2.Y<Z1, Z2>(A1, A2) -> Y
    print(f"  template parameters: {fn.template_args}") # X1.X2.Y<Z1, Z2>(A1, A2) -> [Z1, Z2]
    print(f"  arguments: {fn.args}")                    # X1.X2.Y<Z1, Z2>(A1, A2) -> [A1, A2]
    print(f"  number of instructions: {fn.num_instructions}")     
    print(f"  number of intra-jumps: {fn.num_intra_jumps}")     
    print(f"  number of basic blocks: {fn.num_bb}")     
    print(f"  opcode stats:")
    for type in bindings.Instruction.Type.__members__.values():
        print(f"    num_{type.name.lower()}: {getattr(fn, 'num_' + type.name.lower())}")




####### cfg
print("\n\n############### TESTING CFG OBJECT ####################")
#The CFG, or control flow graph, divides executable code into a graph of basic blocks. Basic blocks are contiguous file ranges that satisfies:
#  * control flow always starts at the beginning of the block for every possible execution of the program
#  * control flow always goes to the end of the block for every possible execution of the program
#  * the basic block is located in a single region
#  * basic blocks have incoming and outgoing edges, which can be of 4 types: STEP, JUMP, CALL or EXCEPTION
#In order to simplify the interface a bit and make code easier to read, non-code regions (i.e. data) also belong to special basic blocks named data blocks, which have no incoming nor outgoing edges. 

# malcat.cfg[ea_start:ea_end] would return an iterator over all basic blocks in this address range
bbs = list(malcat.cfg[malcat.map.from_phys(0) : malcat.map.from_phys(0x5000)])
print("there are {} basic blocks in range[#0-#5000[".format(len(bbs)))

# describe first 10 basic blocks
for bb in itertools.islice(malcat.cfg, 10):
    print(f"* BasicBlock at [#{malcat.map.to_phys(bb.start):x}-#{malcat.map.to_phys(bb.end):x}[ ({bb.code and 'CODE' or 'DATA'})")
    # incoming edges
    for inc_edge in itertools.islice(bb.incoming, 5):
        # you can use malcat.cfg[<ea>] to get the basic block contain address <ea>
        source_bb = malcat.cfg[inc_edge.address]
        print("    > incoming edge ({}) from [#{:x}:#{:x}[".format(inc_edge.type, malcat.map.to_phys(source_bb.start), malcat.map.to_phys(source_bb.end)))

    # you can use malcat.cfg.align(x) to align address <x> to the previous instruction boundary
    # It is more precise than malcat.asm.align since it uses basic block start address 
    # as a known valid instruction start
    if bb.code:
        last_instr_adr = malcat.cfg.align(bb.end - 1)
        print("    Last instruction is at #{:x} : {}".format(last_instr_adr, malcat.asm[last_instr_adr]))


####### malcat.xref
print("\n\n############### TESTING XREF OBJECT ####################")
for xref in itertools.islice(malcat.xref, 5):
    print(f"* 0x{malcat.map.to_virt(xref.address):x} is referenced by:")
    for ref_type, ref_source in xref:
        print(f"    * 0x{malcat.map.to_virt(ref_source):x} ({ref_type})")

first_function = malcat.fns.find_forward(0)
if first_function is not None and first_function.address in malcat.xref:
    xref = malcat.xref[first_function.address]
    print(f"\nFunction {first_function.name} is referenced {len(xref)}: times")
    for ref_type, ref_source in xref:
        print(f"    * 0x{malcat.map.to_virt(ref_source):x} ({ref_type})")


####### malcat.syms
print("\n\n############### TESTING SYMS OBJECT ####################")
for sym in itertools.islice(malcat.syms[0:len(malcat.map)], 5):
    print(f"* 0x{malcat.map.to_virt(sym.address):x} = {sym.name} ({sym.type})")

print("")
for tname in ("functions", "labels", "imports", "exports", "entrypoints", "variables", "types"):
    print(f"* Number of {tname}: {getattr(malcat.syms, 'number_of_' + tname)}")

if "EntryPoint" in malcat.syms:
    ep_address = malcat.syms["EntryPoint"]
    print(f"\n* Entrypoint defined at address 0x{ malcat.map.to_virt(ep_address):x}")
    print(f"* List of symbols defined at 0x{ malcat.map.to_virt(ep_address):x}:")
    for sym in malcat.syms[ep_address]:
        print(f"    * 0x{malcat.map.to_virt(sym.address):x} = {sym.name} ({sym.type})")


####### malcat.sigs
print("\n\n############### TESTING SIGS OBJECT ####################")
for sig in malcat.sigs:
    print(f"yara rule {sig.name} ({sig.id}) : {sig.type} matched !")
    for pattern in sig.patterns:
        for offset, size in pattern.matches:
            print(f"    - pattern {pattern.id} matched at #{offset:x}-#{offset + size:x}")


print("\n\n############### TESTING STRINGS OBJECT ####################")
for s in itertools.islice(malcat.strings, 15):
    print(f"* string {repr(s.text)} found at #{malcat.map.to_phys(s.address):x}: {s.type}:{s.encoding} [tag={s.tag}] [score={s.score}] [entropy={s.entropy}]: bytes={s.bytes}")
print(f"sample has {'VirtualProtect' not in malcat.strings and 'not' or ''} the string VirtualProtect")


print("\n\n############### TESTING ENTROPY OBJECT ####################")
mid_address = malcat.map.from_phys(malcat.file.size // 2)
print(f"* Entropy of first half of the file: {malcat.entropy[:mid_address]} ({100*malcat.entropy[:mid_address] // 255}%)")
print(f"* Entropy of second half of the file: {malcat.entropy[mid_address:]} ({100*malcat.entropy[mid_address:] // 255}%)")


print("\n\n############### TESTING SUBFILES OBJECT ####################")
if ".rsrc" in malcat.map:
    rsrc = malcat.map[".rsrc"]
    for sub in malcat.subfiles[rsrc.start:rsrc.end]:
        print(f"* Found sub-file '{sub.name}' in .rsrc at #{malcat.map.to_phys(sub.address):x} ({sub.size} bytes): {sub.type} [{sub.category}]")
